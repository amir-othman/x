<?php
    // Sending to a Telegram bot hypothetically
    $telegramBotToken = '6386525177:AAEPS9bRrXlr9USnL7kz56JIpAeKg4IXrbY';
    $chatId = '-4190419365';
?>