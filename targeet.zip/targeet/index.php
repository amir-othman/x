<?php
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
if (function_exists('random_bytes')) {
    $reference = bin2hex(random_bytes(10));
} elseif (function_exists('openssl_random_pseudo_bytes')) {
    $reference = bin2hex(openssl_random_pseudo_bytes(10));
} else {
    $reference = bin2hex(substr(str_shuffle(str_repeat('0123456789abcdef', 10)), 0, 10));
}
header("Location: dashboard.php?reference=$reference");
exit();
?>
